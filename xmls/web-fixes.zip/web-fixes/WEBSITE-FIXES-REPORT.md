# Website fixes - BC Building Code interactive site

Generated 2026-11-14 19:39 from the `webfix/*` tags in `F:\Sonia\Projects\BC_Building\site generation code\HOUS-Interactive-BCBC-develop` (branch `ai-fix/session_1`).

Each fix is one commit with one tag. Only website code is listed (apps/, packages/, scripts/); regenerated site data is not part of these fixes.

## How to bring a fix into another repo

1. Same history (a clone or fork of HOUS): `git cherry-pick <commit>`.
2. Different history: `git am --3way <path>\web-fixes\<name>.patch` (or `git apply --3way` to apply without committing).
3. Otherwise copy the change by hand from the diff below. Each changed block carries a `CLAUDE-AUTOFIX <ref>` comment, so it can be found with a search.

List the tags: `git tag -l "webfix/*" -n9`

## Fixes

**Issues expected to clear in the comparison tool: 1265** across 43 fix(es) (observed so far: 858). Counts are from comparison run latest_14 and are confirmed (or corrected) by the next run with `/fix-check`. Edit `web-fixes/fix-counts.json` to change them.

| # | Tag | Commit | Date | Cluster | Expected to clear | Observed | Change |
|---|---|---|---|---|---|---|---|
| 1 | `webfix/CL-005-CF-00877` | `d49a5d3` | 2026-11-11 23:21 | CL-005 | **189** | 184 | Bold the Forming Part of line under table titles as in the PDF (CL-005), keeping the 7 tables the PDF prints plain. |
| 2 | `webfix/CL-004-CF-00062` | `77db182` | 2026-11-12 00:02 | CL-004 | **178** | 178 | Show defined terms in italic instead of bold, as in the PDF (CL-004). |
| 3 | `webfix/CL-066-CF-00859` | `a4d8b2b` | 2026-11-12 00:20 | CL-066 | **90** | 90 | Print figure notes as in the PDF: a Notes to Figure heading and plain (n) labels instead of bold Note (n): (CL-066). |
| 4 | `webfix/CL-005-CF-10515` | `b2c84f2` | 2026-11-12 00:40 | CL-005 | **2** | 2 | Keep the Forming part of caption plain for the two Division A tables 1.1.1.1.(5) and (6), as in the PDF (CL-005 follow-up). |
| 5 | `webfix/CL-067-CF-00874` | `7a02452` | 2026-11-12 00:58 | CL-067 | **21** | 21 | Show the (See Note ...) line under subsection headings as in the PDF (CL-067). |
| 6 | `webfix/CL-028-CF-00876` | `7285c7a` | 2026-11-12 01:37 | CL-028 | **30** | 30 | Write the Forming Part of table caption as the PDF does: plural pretext once, no Oxford comma, grouped by article (CL-028). |
| 7 | `webfix/CL-057-CF-00798` | `fafa081` | 2026-11-12 01:43 | CL-057 | **47** | 48 | Show the organization list as plain lines like the PDF instead of a table with https links (CL-057). |
| 8 | `webfix/CL-064-CF-00283` | `cb14de8` | 2026-11-12 01:45 | CL-064 | **23** | 23 | Show the objective keys and titles in plain type as in the PDF (CL-064). |
| 9 | `webfix/CL-063-CF-00374` | `4896a6e` | 2026-11-12 08:22 | CL-063 | **128** | 128 | Show header-cell footnote markers, superscripts and subscripts in plain type in the 112 tables where the PDF does (CL-063 safe subset). |
| 10 | `webfix/CL-028-CF-10563` | `88aac80` | 2026-11-12 08:30 | CL-028 | **10** | 10 | Print the Forming part of caption with a lowercase part in the 13 tables where the PDF does (CL-028 letter case). |
| 11 | `webfix/CL-063-CF-06144` | `78d263f` | 2026-11-12 08:56 | CL-063 | **78** | 77 | Show the whole header row in plain type in the 14 tables where the PDF does (CL-063 plain-header tables). |
| 12 | `webfix/CL-063-CF-00274` | `8c61162` | 2026-11-12 09:05 | CL-063 | **68** | 67 | Show 73 header cells in plain type in the 13 tables where the PDF prints them plain (CL-063 per-cell). |
| 13 | `webfix/CL-063-CF-04859` | `977b086` | 2026-11-12 13:01 | CL-063 | **?** | - | Show GWB-A, GWB-B and GWB-C plain in the Table 9.23.13.7 header as in the PDF (CL-063 spanned-column cells). |
| 14 | `webfix/CL-063-CF-06098` | `de3c2f3` | 2026-11-12 13:02 | CL-063 | **?** | - | Show step numbers 3 and 4 plain in the Table 9.36.6.3.-G header as in the PDF (CL-063 spanned-column cells). |
| 15 | `webfix/CL-036-CF-05801` | `bce14b3` | 2026-11-12 14:32 | CL-036 | **?** | - | Label the inline header notes of Tables 9.36.2.7.-A/-B/-D as (1), (2), (3) as in the PDF instead of (fn1) (CL-036; also fixes CF-05802, CF-05803, CF-05812, CF-05825, CF-05826). |
| 16 | `webfix/CL-063-CF-10334` | `9f0c237` | 2026-11-13 22:36 | CL-063 | **65** | - | Table note marks in body cells print plain, as in the PDF (note-mark links take the weight of the surrounding text). |
| 17 | `webfix/CL-063-CF-09424` | `34b00d7` | 2026-11-13 22:44 | CL-063 | **114** | - | Footnote marks, superscripts and subscripts in 74 header cells, and 33 whole header cells, print plain where the PDF does. |
| 18 | `webfix/CL-064-CF-05368` | `9c4e9f7` | 2026-11-13 22:50 | CL-064 | **13** | - | The table number and title print plain in the 13 tables where the PDF does (9.26.3.1., 9.36.6.3.-B, D-2.6.1.-B ...). |
| 19 | `webfix/CL-071-CF-03869` | `1d8b17d` | 2026-11-13 22:59 | CL-071 | **52** | - | List labels print as text the way the PDF shows them ((a), (1), 1., (i), A., a)) for 26 PDF-checked lists, instead of CSS markers a. / 1. |
| 20 | `webfix/CL-063-CF-10691` | `432c91c` | 2026-11-13 23:05 | CL-063 | **31** | - | 13 header cells of Tables 10.3.1.3., 9.32.3.5., 9.32.3.8. and 9.36.6.3.-A/-B/-G print in regular weight (defined terms italic only), as in the PDF. |
| 21 | `webfix/CL-072-CF-08312` | `8cd8fb9` | 2026-11-13 23:12 | CL-072 | **6** | - | The 6 figures of Note A-9.32.3.4. are numbered by Sentence as in the PDF (A-9.32.3.4.(2) ... (6)) instead of -A to -F. |
| 22 | `webfix/CL-073-CF-08042` | `000af8b` | 2026-11-13 23:16 | CL-073 | **1** | - | A table number that already ends with a period gets no second period (Table A-Table 9.11.1.4., A-9.23.13., A-4.1.6.9. ...), as in the PDF. |
| 23 | `webfix/CL-073-CF-04057` | `697905d` | 2026-11-13 23:23 | CL-073 | **1** | - | A Note reference followed by the sentence period prints one period, as in the PDF (See Note A-Table 9.6.1.3., See Note A-9.4.1.1.). |
| 24 | `webfix/CL-083-CF-08737` | `405477a` | 2026-11-14 04:38 | CL-083 | **32** | - | No "Forming Part of ..." line under Appendix C and D tables (32 tables), as in the PDF. |
| 25 | `webfix/CL-084-CF-10036` | `4864f52` | 2026-11-14 04:49 | CL-084 | **16** | - | Table references separated only by a line break keep their "Table" word (Table 1.3.1.2 "Table 5.9.1.1. Table 9.26.2.1.-B", A-9.36.2.8.(1)), as in the PDF. |
| 26 | `webfix/CL-085-CF-00039` | `d815c85` | 2026-11-14 04:58 | CL-085 | **7** | - | Sentences added by later Ministerial Orders (empty original revision) are not shown at an earlier date, as in the PDF (no bare "2)", "7)", "12)"). |
| 27 | `webfix/CL-086-CF-10034` | `da658ff` | 2026-11-14 05:04 | CL-086 | **9** | - | Unlabelled references in table cells show the full Sentence number (9.32.3.9.(2), not "(2)") and the table letter (Table 9.32.3.10.-B), as in the PDF. |
| 28 | `webfix/CL-087-CF-10062` | `2e0993b` | 2026-11-14 05:09 | CL-087 | **2** | - | Note references in "number" format, or after the word "Notes" in the text, show only the note number (A-3.1.11.5.(3) and (4); See Notes A-3.1.6.4.(4) and ...), as in the PDF. |
| 29 | `webfix/CL-088-CF-10660` | `f4abfbd` | 2026-11-14 05:12 | CL-088 | **1** | - | An unlabelled reference to the 2nd+ figure of an appendix Article keeps its letter (Figures D-2.6.1.-A and D-2.6.1.-B), as in the PDF. |
| 30 | `webfix/CL-089-CF-08525` | `78c965f` | 2026-11-14 05:16 | CL-089 | **12** | - | Untitled worked-example tables in appendix Notes get no invented "Table A-..." caption (A-9.36.2.11.(2) to (4), A-9.36.2.4.(1), A-9.36.1.1.(1), A-9.23.4.4.), as in the PDF. |
| 31 | `webfix/CL-090-CF-01778` | `3e39c53` | 2026-11-14 05:21 | CL-090 | **8** | - | Tables of appendix Notes read "Forming Part of Note A-3.2.6.6.(1)" / "Note A-9.23.13.2.(3)" instead of "Article 3."/"Article 9.", and Tables A-9.23.13.7.(3)/(4) have no such line, as in the PDF. |
| 32 | `webfix/CL-091-CF-06891` | `b84d9a5` | 2026-11-14 05:27 | CL-091 | **8** | - | Unlabelled Subclause references keep their Clause letter ("(b)(ii)" in attribution tables, "Subclause (1)(b)(ii)" in text), as in the PDF. |
| 33 | `webfix/CL-092-CF-10562` | `ed85233` | 2026-11-14 05:31 | CL-092 | **2** | - | "Forming Part of" captions with 3 or more references use commas and put "and" only before the last one (Sentences 9.3.2.8.(1), 9.23.4.5.(1) and 9.23.12.3.(1) and (3)), as in the PDF. |
| 34 | `webfix/CL-093-CF-09340` | `b4f8f3b` | 2026-11-14 05:35 | CL-093 | **2** | - | Word equations given only as plain text (Ss = smooth normalized SL + bZ; height of water, mm = DRWP/10, Pa) are shown as text, not typeset as maths, as in the PDF. |
| 35 | `webfix/CL-094-CF-06000` | `302d24e` | 2026-11-14 05:38 | CL-094 | **2** | - | Symbol lists given as "AFUE= annual fuel ..." text in the notes to Tables 9.36.3.10. and 9.36.4.2. now show each symbol and its meaning, as in the PDF. |
| 36 | `webfix/CL-095-CF-10189` | `1fa1e30` | 2026-11-14 05:41 | CL-095 | **1** | - | A functional-statement/objective pair with a stray comma before the closing bracket renders as "[ F80 - OP2.3 ]" instead of raw [REF:...] markers (Table 9.38.1.1.), as in the PDF. |
| 37 | `webfix/CL-083-CF-08741` | `eb9b41c` | 2026-11-14 05:45 | CL-083 | **?** | - | Update the TableBlock test to the CL-083 rule - Appendix C/D tables have no "Forming Part of" line, as in the PDF. |
| 38 | `webfix/CL-096-CF-10780` | `bdaded1` | 2026-11-14 14:04 | CL-096 | **1** | - | The bibliography lead-in "References:" in Note A-9.4.4.4.(1) is plain text, not bold, as in the PDF. |
| 39 | `webfix/CL-097-CF-02954` | `4604bb4` | 2026-11-14 14:50 | CL-097 | **4** | - | The design-review list of Note A-4.1.8.19.(2) is labelled (a) to (e), as in the PDF. |
| 40 | `webfix/CL-098-CF-10784` | `d73dfb6` | 2026-11-14 14:52 | CL-098 | **2** | - | The untitled table in Note A-9.23.13. gets no invented "Table A-9.23.13." caption, as in the PDF. |
| 41 | `webfix/CL-099-CF-04628` | `672cf25` | 2026-11-14 19:32 | CL-099 | **3** | - | Table cells keep the PDF's em and en dashes instead of turning them into hyphens. |
| 42 | `webfix/CL-100-CF-01199` | `b7e3f6c` | 2026-11-14 19:35 | CL-100 | **1** | - | A wide table whose first header cell spans several columns no longer draws that cell twice (Table 3.2.3.1.-C "Exposing Building Face"). |
| 43 | `webfix/CL-101-CF-09752` | `784fe49` | 2026-11-14 19:39 | CL-101 | **5** | - | Appendix D figures and the Note A-9.36.2.4.(1) example figures show the figure numbers printed in the PDF. |
| | **Total** | | | | **1265** | 858 | |

## 1. CL-005 - Bold the Forming Part of line under table titles as in the PDF (CL-005), keeping the 7 tables the PDF prints plain.

- **Tag:** `webfix/CL-005-CF-00877`  **Commit:** `d49a5d32c3d108c0562407b8c425e08339efb6e2` (2026-11-11 23:21, branch `ai-fix/session_1`)
- **Lead issue:** CF-00877 - Formatting, B.3.1.2.1.Tbl1
- **Issues expected to clear:** **189** (observed in a later comparison: 184)
- **Basis of the count:** latest_14 issues 'Forming Part of ...: bold in PDF, plain on website' (189). The user saw 197 fewer issues in the next comparison. latest_15 (2026-11-12): 184 gone; the other 5 (Tables 9.36.6.3.-C to -G) are comparison artefacts - the PDF caption is plain there and the website matches.
- **New issues:** latest_15 showed 2 new issues caused by this fix: the 2 Division A tables A.1.1.1.1.Tbl1/Tbl2, whose caption the PDF prints in lowercase 'Forming part of ...' in plain type (my PDF scan only looked for 'Forming Part of'). Follow-up fix: CF-10515 / CF-10516 (add the two tables to the plain-caption exceptions). The 7 other plain tables were handled correctly.
- **Issues that stay:** Wording differences ('Sentence X and Sentence Y' vs the PDF's plural form) are CL-028 and are not changed by this fix.
- **Ledger cluster:** CL-005, 164 issue(s) in the ledger
- **What was wrong:** PDF: Forming Part of line bold like the title | before: plain | after: bold; 7 PDF-plain tables stay plain
- **Root cause:** .table-block__forming-part had no font-weight, so the Forming Part of line was plain; the PDF prints it bold like the table title.
- **Files:** `apps/web/components/reading/TableBlock.css`
- **Patch:** `web-fixes/CL-005-CF-00877.patch`

```
 apps/web/components/reading/TableBlock.css | 13 +++++++++++++
 1 file changed, 13 insertions(+)
```

```diff
diff --git a/apps/web/components/reading/TableBlock.css b/apps/web/components/reading/TableBlock.css
index 212d678..f0777b9 100644
--- a/apps/web/components/reading/TableBlock.css
+++ b/apps/web/components/reading/TableBlock.css
@@ -42,6 +42,8 @@
 
 .table-block__forming-part {
   margin-top: 0.1rem;
+  /* CLAUDE-AUTOFIX CL-005 CF-00877 | issue 7286 | The "Forming Part of" line is bold in the PDF, like the table title. */
+  font-weight: var(--typography-font-weights-bold, 700);
   font-family: var(--typography-font-families-bc-sans, 'BC Sans', sans-serif);
   font-size: 1rem;
   line-height: 1.35;
@@ -49,6 +51,17 @@
   text-align: center;
 }
 
+/* CLAUDE-AUTOFIX CL-005 CF-00877 | issue 7286 | These 7 tables print the "Forming Part of" line in plain type in the PDF (Tables 3.4.3.2.-B, 3.5.3.1., 9.36.6.3.-C to -G), so they stay plain. */
+.table-block[id="nbc.divB.part3.sect4.subsect3.art2.table2"] .table-block__forming-part,
+.table-block[id="nbc.divB.part3.sect5.subsect3.art1.table1"] .table-block__forming-part,
+.table-block[id="nbc.divBV2.part9.sect36.subsect6.art3.tableC"] .table-block__forming-part,
+.table-block[id="nbc.divBV2.part9.sect36.subsect6.art3.tableD"] .table-block__forming-part,
+.table-block[id="nbc.divBV2.part9.sect36.subsect6.art3.tableE"] .table-block__forming-part,
+.table-block[id="nbc.divBV2.part9.sect36.subsect6.art3.tableF"] .table-block__forming-part,
+.table-block[id="nbc.divBV2.part9.sect36.subsect6.art3.tableG"] .table-block__forming-part {
+  font-weight: var(--typography-font-weights-regular, 400);
+}
+
 .table-block__wrapper {
   display: block;
   width: 100%;
```

## 2. CL-004 - Show defined terms in italic instead of bold, as in the PDF (CL-004).

- **Tag:** `webfix/CL-004-CF-00062`  **Commit:** `77db18245db41c5883e955169294f98f34a660a4` (2026-11-12 00:02, branch `ai-fix/session_1`)
- **Lead issue:** CF-00062 - Formatting, A.1.4.1.2.(1)
- **Issues expected to clear:** **178** (observed in a later comparison: 178)
- **Basis of the count:** latest_14: 176 terms + 2 ('Apparent sound transmission class (ASTC)', 'Sound transmission class (STC)') reported as 'italic in PDF, bold on website'. latest_15: all 178 gone.
- **New issues:** None caused in substance. latest_17 re-reports the word 'or' in 'Access or Accessible' (plain in the PDF) as 'plain in PDF, italic on website' (CF-10520); before the fix it was 'plain in PDF, bold on website' (CF-00061). Needs partial emphasis inside one term: manual.
- **Issues that stay:** 9 other issues at A.1.4.1.2.(1) are not caused by this CSS: 4 body-text italics (XML), the word 'or' in 'Access or Accessible' (plain in the PDF), and 4 NBC-only/Ministerial Order definitions.
- **Ledger cluster:** CL-004, 190 issue(s) in the ledger
- **What was wrong:** PDF: term italic, run into the definition line | before: term bold on its own line | after: term italic, regular weight, still on its own line (layout not reported by the comparison)
- **Root cause:** StructuredListBlock.css .structuredList__term is bold; the only 'definition' list on the site is Article 1.4.1.2.(1) (185 terms), and the PDF prints all located terms (169 of 185) in italic.
- **Files:** `apps/web/components/reading/StructuredListBlock.css`
- **Patch:** `web-fixes/CL-004-CF-00062.patch`

```
 apps/web/components/reading/StructuredListBlock.css | 6 ++++++
 1 file changed, 6 insertions(+)
```

```diff
diff --git a/apps/web/components/reading/StructuredListBlock.css b/apps/web/components/reading/StructuredListBlock.css
index 813fabf..be8f7c4 100644
--- a/apps/web/components/reading/StructuredListBlock.css
+++ b/apps/web/components/reading/StructuredListBlock.css
@@ -35,6 +35,12 @@
   margin: 0;
 }
 
+/* CLAUDE-AUTOFIX CL-004 CF-00062 | issue 6961 | Defined terms are italic, not bold, in the PDF. */
+.structuredList--definition .structuredList__term {
+  font-weight: var(--typography-font-weights-regular);
+  font-style: italic;
+}
+
 .structuredList__description {
   margin: 0.25rem 0 0;
 }
```

## 3. CL-066 - Print figure notes as in the PDF: a Notes to Figure heading and plain (n) labels instead of bold Note (n): (CL-066).

- **Tag:** `webfix/CL-066-CF-00859`  **Commit:** `a4d8b2b9f3d47b4104d6119fd5015cd6888d6fe4` (2026-11-12 00:20, branch `ai-fix/session_1`)
- **Lead issue:** CF-00859 - Incorrect Content, B.A-1.1.3.1.(4)
- **Issues expected to clear:** **90** (observed in a later comparison: 90)
- **Basis of the count:** latest_14, 15 appendix Notes with figure notes: 19 heading ('Notes to Figure X: (1)' vs '(1):'), 27 note label ('(n)' vs 'Note (n):'), 43 bold label ('n' plain in PDF, bold on website), 1 bold word 'Note'. latest_15: all 90 gone (none of the 90 is still reported).
- **New issues:** None. latest_15 showed 3 re-reported old issues at the same appendix notes (same differences as CF-00865, CF-01751, CF-02735, new ids), not caused by this fix.
- **Issues that stay:** Figure notes the comparison cannot read (figures are checked visually) change too, but are not counted.
- **Ledger cluster:** CL-066, 13 issue(s) in the ledger
- **What was wrong:** PDF: 'Notes to Figure A-1.1.3.1.(4):' plain heading, then plain '(1) ...' lines | before: bold 'Note (1):' labels, no heading | after: plain heading + plain '(n) ...' as in the PDF
- **Root cause:** Website: figure notes are printed as "Note (n):" without the "Notes to Figure ...:" heading; the PDF prints "Notes to Figure A-1.1.3.1.(4):" then "(1)", "(2)" ... The JSON has the notes; the format is website code.
- **Files:** `apps/web/components/reading/FigureBlock.css`, `apps/web/components/reading/FigureBlock.tsx`
- **Patch:** `web-fixes/CL-066-CF-00859.patch`

```
 apps/web/components/reading/FigureBlock.css | 14 ++++++++++++++
 apps/web/components/reading/FigureBlock.tsx |  4 +++-
 2 files changed, 17 insertions(+), 1 deletion(-)
```

```diff
diff --git a/apps/web/components/reading/FigureBlock.css b/apps/web/components/reading/FigureBlock.css
index 866ad7f..5761a05 100644
--- a/apps/web/components/reading/FigureBlock.css
+++ b/apps/web/components/reading/FigureBlock.css
@@ -61,6 +61,20 @@
   text-align: left;
 }
 
+/* CLAUDE-AUTOFIX CL-066 CF-00859 | issue 620 | The PDF prints the "Notes to Figure X:" heading in bold. */
+.figure-block__notes-title {
+  margin: 0.25rem 0;
+  font: var(--typography-bold-small, 700 0.95rem/1.45 'BCSans', sans-serif);
+  color: var(--typography-color-primary, #313132);
+}
+
+/* CLAUDE-AUTOFIX CL-066 CF-00859 | issue 620 | Three figures print the heading in plain type in the PDF (A-1.1.3.1.(4), A-3.2.4.18.(2)-B, A-4.1.7.8.(2) and (3)). */
+.figure-block[id="nbc.divB.part1.appendix.appnote4.figure1"] .figure-block__notes-title,
+.figure-block[id="nbc.divB.part3.appendix.appnote77.figure2"] .figure-block__notes-title,
+.figure-block[id="nbc.divB.part4.appendix.appnote58.figure1"] .figure-block__notes-title {
+  font-weight: var(--typography-font-weights-regular, 400);
+}
+
 .figure-block__note {
   margin: 0.25rem 0;
   font: var(--typography-regular-small, 400 0.95rem/1.45 'BCSans', sans-serif);
diff --git a/apps/web/components/reading/FigureBlock.tsx b/apps/web/components/reading/FigureBlock.tsx
index 52cbd7b..710d46f 100644
--- a/apps/web/components/reading/FigureBlock.tsx
+++ b/apps/web/components/reading/FigureBlock.tsx
@@ -249,9 +249,11 @@ export const FigureBlock: React.FC<FigureBlockProps> = ({
       )}
       {figureNotes.length > 0 && (
         <div className="figure-block__notes">
+          {/* CLAUDE-AUTOFIX CL-066 CF-00859 | issue 620 | The PDF prints "Notes to Figure X:" as a heading and plain "(n)" before each note. */}
+          <p className="figure-block__notes-title">{`${figureNotes.length === 1 ? 'Note' : 'Notes'} to ${figureLabel}:`}</p>
           {figureNotes.map((note) => (
             <p key={note.id} className="figure-block__note">
-              <strong>{`Note (${getFigureNoteNumber(note.id)}): `}</strong>
+              {`(${getFigureNoteNumber(note.id)}) `}
               {parseTextWithMarkers(note.content, [], interactive, [], [], renderContext)}
             </p>
           ))}
```

## 4. CL-005 - Keep the Forming part of caption plain for the two Division A tables 1.1.1.1.(5) and (6), as in the PDF (CL-005 follow-up).

- **Tag:** `webfix/CL-005-CF-10515`  **Commit:** `b2c84f21979aba19bdd82d4c30afe46cf95dc1ba` (2026-11-12 00:40, branch `ai-fix/session_1`)
- **Lead issue:** CF-10515 - Formatting, A.1.1.1.1.Tbl1
- **Issues expected to clear:** **2** (observed in a later comparison: 2)
- **Basis of the count:** latest_15: CF-10515 / CF-10516 ('Forming part of Sentence 1.1.1.1.(5)' / '(6)': plain in PDF, bold on website), the 2 new issues caused by the CL-005 fix. latest_17: both gone.
- **New issues:** None. latest_17 showed no new issue from this fix.
- **Issues that stay:** The capital 'P' on the website ('Forming Part') against the PDF's lowercase 'part' is a separate existing difference.
- **Ledger cluster:** CL-005, 164 issue(s) in the ledger
- **What was wrong:** PDF: 'Forming part of Sentence 1.1.1.1.(5)' plain under the bold title | before: bold | after: plain
- **Root cause:** Caused by the CL-005 fix (CF-00877): the PDF prints this caption as lowercase "Forming part of ..." in plain type (PDF pages 8 and 12), but my PDF scan only looked for "Forming Part of", so these two Division A tables were not excepted from the bold rule.
- **Files:** `apps/web/components/reading/TableBlock.css`
- **Patch:** `web-fixes/CL-005-CF-10515.patch`

```
 apps/web/components/reading/TableBlock.css | 6 ++++++
 1 file changed, 6 insertions(+)
```

```diff
diff --git a/apps/web/components/reading/TableBlock.css b/apps/web/components/reading/TableBlock.css
index f0777b9..9f82f87 100644
--- a/apps/web/components/reading/TableBlock.css
+++ b/apps/web/components/reading/TableBlock.css
@@ -51,6 +51,12 @@
   text-align: center;
 }
 
+/* CLAUDE-AUTOFIX CL-005 CF-10515 | issue 3687 | The 2 Division A tables 1.1.1.1.(5) and (6) print the caption "Forming part of ..." in plain type in the PDF. */
+.table-block[id="nbc.divA.part1.sect1.subsect1.art1.table1"] .table-block__forming-part,
+.table-block[id="nbc.divA.part1.sect1.subsect1.art1.table2"] .table-block__forming-part {
+  font-weight: var(--typography-font-weights-regular, 400);
+}
+
 /* CLAUDE-AUTOFIX CL-005 CF-00877 | issue 7286 | These 7 tables print the "Forming Part of" line in plain type in the PDF (Tables 3.4.3.2.-B, 3.5.3.1., 9.36.6.3.-C to -G), so they stay plain. */
 .table-block[id="nbc.divB.part3.sect4.subsect3.art2.table2"] .table-block__forming-part,
 .table-block[id="nbc.divB.part3.sect5.subsect3.art1.table1"] .table-block__forming-part,
```

## 5. CL-067 - Show the (See Note ...) line under subsection headings as in the PDF (CL-067).

- **Tag:** `webfix/CL-067-CF-00874`  **Commit:** `7a024529bffd42e05081557559e0c5fda0c29358` (2026-11-12 00:58, branch `ai-fix/session_1`)
- **Lead issue:** CF-00874 - Note Reference, B.3.1.2
- **Issues expected to clear:** **21** (observed in a later comparison: 21)
- **Basis of the count:** latest_15: 21 'Note Reference' issues on Subsection headings ('missing on website after "<title>": "(See Note A-...)"'), listed in builds/cl067-subs.json. All 21 JSON subsections have the text; the live page text equals the PDF text. latest_17: all 21 gone.
- **New issues:** None. latest_17 showed no new issue from this fix.
- **Issues that stay:** Not covered: the Part heading B.3 (CF-00873: comes from the navigation tree, needs scripts/generate-assets.ts + NavigationNode + PartRenderer), 7 Section headings (3.3, 3.8, 5.3, 5.7, 5.8, 9.7, 9.11: the JSON has no see_also on sections, needs XSL/XML), and 47 Sentence/Article see-also issues (text missing from the JSON, XML/XSL). latest_20 reported 3 of the 21 again (9.23.13, 9.27.2, 9.34.2) and 3 CL-028 captions, but the live pages are correct: capture artefacts of the comparison.
- **Ledger cluster:** CL-067, 32 issue(s) in the ledger
- **What was wrong:** PDF: '(See Note A-3.1.2.)' on its own line under the heading 3.1.2. | before: heading only | after: '(See Note A-3.1.2.)' under the heading, note as link
- **Root cause:** SubsectionBlock.tsx draws only the heading and never reads the subsection's see_also (JSON has it); ArticleBlock already renders see_also under its heading.
- **Files:** `apps/web/components/reading/SubsectionBlock.tsx`
- **Patch:** `web-fixes/CL-067-CF-00874.patch`

```
 apps/web/components/reading/SubsectionBlock.tsx | 9 +++++++++
 1 file changed, 9 insertions(+)
```

```diff
diff --git a/apps/web/components/reading/SubsectionBlock.tsx b/apps/web/components/reading/SubsectionBlock.tsx
index d9c279d..2bc72c8 100644
--- a/apps/web/components/reading/SubsectionBlock.tsx
+++ b/apps/web/components/reading/SubsectionBlock.tsx
@@ -2,6 +2,7 @@ import React from 'react';
 import type { Subsection } from '@bc-building-code/bcbc-parser';
 import { ArticleBlock } from './ArticleBlock';
 import { formatNumberedTitle } from '../../lib/title-formatting';
+import { parseTextWithMarkers } from '../../lib/text-parsing';
 import './SubsectionBlock.css';
 
 export interface SubsectionBlockProps {
@@ -32,11 +33,19 @@ export const SubsectionBlock: React.FC<SubsectionBlockProps> = ({
     titleText = '';
   }
 
+  // CLAUDE-AUTOFIX CL-067 CF-00874 | issue 2900 | The PDF prints "(See Note ...)" after the subsection title; the JSON has it as see_also.
+  const seeAlsoText = (subsection as Subsection & { see_also?: string }).see_also?.trim();
+
   return (
     <div className="subsectionBlock">
       <h3 className="subsectionHeading">
         {formatNumberedTitle(fullSubsectionNumber, titleText)}
       </h3>
+      {seeAlsoText ? (
+        <p className="articleSeeAlso">
+          {parseTextWithMarkers(seeAlsoText, [], interactive, [], [], { kind: 'article', referenceId: subsection.id })}
+        </p>
+      ) : null}
       <div className="articles">
         {subsection.articles.map((article) => (
           <ArticleBlock
```

## 6. CL-028 - Write the Forming Part of table caption as the PDF does: plural pretext once, no Oxford comma, grouped by article (CL-028).

- **Tag:** `webfix/CL-028-CF-00876`  **Commit:** `7285c7a66e2465246e277d4c8ed51c78a44ecab3` (2026-11-12 01:37, branch `ai-fix/session_1`)
- **Lead issue:** CF-00876 - Reference, B.3.1.2.1.Tbl1
- **Issues expected to clear:** **30** (observed in a later comparison: 30)
- **Basis of the count:** latest_17: CL-028 had 134 pending issues in 134 tables. The PDF text stored in each issue was compared with the new caption: 30 issues are on tables whose new caption equals the PDF text exactly. Whole-document check (162 tables aligned by title with the PDF's 270 captions): 118 already equal and stay equal, 28 newly equal, 0 regressions; 34 more unaligned tables get PDF-style wording.
- **New issues:** None. latest_18: 0 regressions; the 51 new issues are re-reports (15 organization data leftovers, 25 caption leftovers on tables that already had issues, 10 lowercase 'part' captions).
- **Issues that stay:** About 100 CL-028 issues are not fixed by wording: PDF ranges like '(1) to (9)' or '(5) to (8)' that the JSON entries do not contain, irregular PDF wording (e.g. singular 'Sentence' with three items, '9.36.2.8. (1) to (9)'), appendix-note tables ('Note A-3.2.6.6.(1)': the website has no note number in the entry), lowercase 'Forming part of' (12 tables), a wrong target in the data (3.9.1.1 vs 3.10.1.1) and issues whose location is a sentence, not the table.
- **Ledger cluster:** CL-028, 133 issue(s) in the ledger
- **What was wrong:** PDF: 'Forming Part of Sentences 3.1.2.1.(1) and 3.1.2.2.(1)' | before: 'Forming Part of Sentence 3.1.2.1.(1) and Sentence 3.1.2.2.(1)' | after: equals the PDF
- **Root cause:** TableBlock.tsx formatFormingPartText writes 'Sentence X and Sentence Y' with a repeated pretext and an Oxford comma; the PDF writes 'Sentences X and Y' (plural once, no comma before the last 'and', article number not repeated for later sentences of the same article, full (1)(b)(iii) for subclauses).
- **Files:** `apps/web/components/reading/TableBlock.test.tsx`, `apps/web/components/reading/TableBlock.tsx`
- **Patch:** `web-fixes/CL-028-CF-00876.patch`

```
 apps/web/components/reading/TableBlock.test.tsx |  28 +++++++
 apps/web/components/reading/TableBlock.tsx      | 104 ++++++++++++++++++++++++
 2 files changed, 132 insertions(+)
```

```diff
diff --git a/apps/web/components/reading/TableBlock.test.tsx b/apps/web/components/reading/TableBlock.test.tsx
index 12cd40a..92a53b6 100644
--- a/apps/web/components/reading/TableBlock.test.tsx
+++ b/apps/web/components/reading/TableBlock.test.tsx
@@ -661,6 +661,34 @@ describe('TableBlock', () => {
     expect(screen.getByText('Forming Part of Sentence 1.3.1.2.(1)')).toBeInTheDocument();
   });
 
+  // CLAUDE-AUTOFIX CL-028 CF-00876 | issue 2562 | Caption wording as the PDF prints it.
+  it.each([
+    [['art1.sent1', 'art2.sent1'], 'Forming Part of Sentences 3.1.2.1.(1) and 3.1.2.2.(1)'],
+    [['art1.sent3', 'art1.sent4'], 'Forming Part of Sentences 3.1.2.1.(3) and (4)'],
+    [['art1', 'art2'], 'Forming Part of Articles 3.1.2.1. and 3.1.2.2.'],
+    [['art1.sent2', 'art3.sent1', 'art8.sent1'], 'Forming Part of Sentences 3.1.2.1.(2), 3.1.2.3.(1) and 3.1.2.8.(1)'],
+    [['art1', 'art2', 'art4.sent2'], 'Forming Part of Articles 3.1.2.1. and 3.1.2.2., and Sentence 3.1.2.4.(2)'],
+    [['art1.sent1.clause2.subclause3'], 'Forming Part of Subclause 3.1.2.1.(1)(b)(iii)'],
+  ])('writes the forming part caption like the PDF for %j', (targets, expected) => {
+    const table = {
+      id: 'nbc.divB.part3.sect1.subsect2.art9.table1',
+      type: 'table',
+      number: '3.1.2.9.',
+      title: 'Title',
+      headers: [['Header']],
+      rows: [{ cells: [{ content: 'Data' }] }],
+      formingPart: targets.map((target) => ({
+        type: 'internal',
+        target: `nbc.divB.part3.sect1.subsect2.${target}`,
+        display_type: 'long',
+      })),
+    } as unknown as Table;
+
+    render(<TableBlock table={table} />);
+
+    expect(screen.getByText(expected)).toBeInTheDocument();
+  });
+
   it('renders Appendix D table numbering from appendix-style ids when number is omitted', () => {
     const table: Table = {
       id: 'nbc.divB.appendixD.appsect1.subsect1.article2.table1',
diff --git a/apps/web/components/reading/TableBlock.tsx b/apps/web/components/reading/TableBlock.tsx
index 80ddf53..50c55cf 100644
--- a/apps/web/components/reading/TableBlock.tsx
+++ b/apps/web/components/reading/TableBlock.tsx
@@ -667,11 +667,115 @@ const formatFormingPartLabel = (reference: ParsedInternalReference): string | nu
   return null;
 };
 
+// CLAUDE-AUTOFIX CL-028 CF-00876 | issue 2562 | The PDF writes the "Forming Part of" caption with a plural pretext ("Sentences X and Y"), no comma before the last "and", and no repeated article number.
+type FormingPartItem = {
+  kind: 'Article' | 'Sentence' | 'Clause' | 'Subclause';
+  article: string;
+  tail: string;
+};
+
+const toFormingPartItem = (target: string): FormingPartItem | null => {
+  const reference = parseInternalReference(target);
+  if (
+    reference.appendixLetter ||
+    !reference.part ||
+    !reference.section ||
+    !reference.subsection ||
+    !reference.article
+  ) {
+    return null;
+  }
+  const article = `${reference.part}.${reference.section}.${reference.subsection}.${reference.article}`;
+  const sentencePart = reference.sentence ? `(${reference.sentence})` : '';
+  if (reference.subclause) {
+    const clausePart = reference.clause ? `(${toAlphabetOrdinal(Number(reference.clause))})` : '';
+    return {
+      kind: 'Subclause',
+      article,
+      tail: `${sentencePart}${clausePart}(${toRoman(Number(reference.subclause))})`,
+    };
+  }
+  if (reference.clause) {
+    return {
+      kind: 'Clause',
+      article,
+      tail: `${sentencePart}(${toAlphabetOrdinal(Number(reference.clause))})`,
+    };
+  }
+  if (reference.sentence) {
+    return { kind: 'Sentence', article, tail: sentencePart };
+  }
+  return { kind: 'Article', article, tail: '' };
+};
+
+const joinWithAnd = (parts: string[]): string =>
+  parts.length === 1 ? parts[0] : `${parts.slice(0, -1).join(', ')} and ${parts[parts.length - 1]}`;
+
+const formatFormingPartItems = (items: FormingPartItem[]): string => {
+  const runs: Array<{ kind: FormingPartItem['kind']; items: FormingPartItem[] }> = [];
+  for (const item of items) {
+    const lastRun = runs[runs.length - 1];
+    if (lastRun && lastRun.kind === item.kind) {
+      lastRun.items.push(item);
+    } else {
+      runs.push({ kind: item.kind, items: [item] });
+    }
+  }
+
+  const texts = runs.map((run) => {
+    const pretext = run.items.length > 1 ? `${run.kind}s` : run.kind;
+    if (run.kind === 'Article') {
+      return `${pretext} ${joinWithAnd(run.items.map((item) => `${item.article}.`))}`;
+    }
+    const groups: Array<{ article: string; tails: string[] }> = [];
+    for (const item of run.items) {
+      const lastGroup = groups[groups.length - 1];
+      if (lastGroup && lastGroup.article === item.article) {
+        lastGroup.tails.push(item.tail);
+      } else {
+        groups.push({ article: item.article, tails: [item.tail] });
+      }
+    }
+    const groupTexts = groups.map((group) =>
+      joinWithAnd([`${group.article}.${group.tails[0]}`, ...group.tails.slice(1)])
+    );
+    const hasGroupWithSeveralItems = groups.some((group) => group.tails.length > 1);
+    const body =
+      groupTexts.length === 1
+        ? groupTexts[0]
+        : hasGroupWithSeveralItems
+          ? groupTexts.join(' and ')
+          : joinWithAnd(groupTexts);
+    return `${pretext} ${body}`;
+  });
+
+  return texts.reduce((text, next, index) =>
+    index === 0 ? next : `${text}${texts[index - 1].includes(' and ') ? ', and ' : ' and '}${next}`
+  );
+};
+
 const formatFormingPartText = (formingPart: FormingPartReference[] | undefined): string | null => {
   if (!formingPart || formingPart.length === 0) {
     return null;
   }
 
+  // CLAUDE-AUTOFIX CL-028 CF-00876 | issue 2562 | Use the PDF wording when every entry is an article, sentence, clause or subclause; anything else keeps the old wording below.
+  const pdfStyleItems: FormingPartItem[] = [];
+  let allPdfStyle = true;
+  for (const entry of formingPart) {
+    if (entry?.type === 'internal' && typeof entry.target === 'string') {
+      const item = toFormingPartItem(entry.target);
+      if (item) {
+        pdfStyleItems.push(item);
+      } else {
+        allPdfStyle = false;
+      }
+    }
+  }
+  if (allPdfStyle && pdfStyleItems.length > 0) {
+    return `Forming Part of ${formatFormingPartItems(pdfStyleItems)}`;
+  }
+
   const labels = formingPart
     .filter((entry) => entry?.type === 'internal' && typeof entry.target === 'string')
     .map((entry) => formatFormingPartLabel(parseInternalReference(entry.target)))
```

## 7. CL-057 - Show the organization list as plain lines like the PDF instead of a table with https links (CL-057).

- **Tag:** `webfix/CL-057-CF-00798`  **Commit:** `fafa08110ab94ed45d251060b68b2b0e7cd3a973` (2026-11-12 01:43, branch `ai-fix/session_1`)
- **Lead issue:** CF-00798 - Incorrect Content, B.1.3.2.1.(1)
- **Issues expected to clear:** **47** (observed in a later comparison: 48)
- **Basis of the count:** latest_17: CL-057 had 59 pending issues (one organization list, 64 items, Article 1.3.2.1.). 47 are 'PDF ( www.x.org) -> website https://www.x.org' (and the table headings) whose address equals the PDF's; live check: 64 lines, 0 tables, 50 lines equal to a PDF entry.
- **New issues:** None. latest_18: 0 regressions; the 51 new issues are re-reports (15 organization data leftovers, 25 caption leftovers on tables that already had issues, 10 lowercase 'part' captions).
- **Issues that stay:** 12 issues are data problems (5 organizations with an empty full name, 4 with a wrong web address, 2 with a blank address, the CAN entry's extra note): moved to manual fixes (XML entry).
- **Ledger cluster:** CL-057, 60 issue(s) in the ledger
- **What was wrong:** PDF: plain lines 'AAMA Fenestration ... ( www.fgiaonline.org)' | before: table with headings and https links | after: plain lines, same wording and layout
- **Root cause:** StructuredListBlock.tsx draws the 'organization' list as a table (caption Organizations, headings Abbreviation / Organization / Website, https links); the PDF prints one plain line per organization 'ABBR Full name ( www.x.org)'.
- **Files:** `apps/web/components/reading/StructuredListBlock.css`, `apps/web/components/reading/StructuredListBlock.test.tsx`, `apps/web/components/reading/StructuredListBlock.tsx`
- **Patch:** `web-fixes/CL-057-CF-00798.patch`

```
 .../web/components/reading/StructuredListBlock.css | 10 +++++
 .../reading/StructuredListBlock.test.tsx           | 29 +++++++++++++++
 .../web/components/reading/StructuredListBlock.tsx | 43 ++++++++--------------
 3 files changed, 55 insertions(+), 27 deletions(-)
```

```diff
diff --git a/apps/web/components/reading/StructuredListBlock.css b/apps/web/components/reading/StructuredListBlock.css
index be8f7c4..4216c54 100644
--- a/apps/web/components/reading/StructuredListBlock.css
+++ b/apps/web/components/reading/StructuredListBlock.css
@@ -88,6 +88,16 @@ li .structuredList--symbol .structuredList__row--variable {
   display: contents;
 }
 
+/* CLAUDE-AUTOFIX CL-057 CF-00798 | issue 559 | Organizations are plain lines, as in the PDF. */
+.structuredList__organization-row {
+  margin: 0 0 0.75rem;
+  text-indent: 1.5rem;
+}
+
+.structuredList__organization-abbreviation {
+  margin-right: 0.5rem;
+}
+
 .structuredList--organization {
   overflow-x: auto;
 }
diff --git a/apps/web/components/reading/StructuredListBlock.test.tsx b/apps/web/components/reading/StructuredListBlock.test.tsx
new file mode 100644
index 0000000..26da562
--- /dev/null
+++ b/apps/web/components/reading/StructuredListBlock.test.tsx
@@ -0,0 +1,29 @@
+import React from 'react';
+import { render, screen } from '@testing-library/react';
+import { describe, expect, it } from 'vitest';
+import type { StructuredList } from '@bc-building-code/bcbc-parser';
+import { StructuredListBlock } from './StructuredListBlock';
+
+describe('StructuredListBlock organization list', () => {
+  // CLAUDE-AUTOFIX CL-057 CF-00798 | issue 559 | Organizations are plain lines like the PDF, not a table.
+  it('renders each organization as a plain line like the PDF', () => {
+    const list = {
+      type: 'organization',
+      items: [
+        { id: 'o1', abbreviation: 'AAMA', fullName: 'Fenestration and Glazing Industry Alliance', website: 'https://www.fgiaonline.org' },
+        { id: 'o2', abbreviation: 'ICC', fullName: 'International Code Council', website: '' },
+        { id: 'o3', abbreviation: 'NBC', fullName: '' },
+      ],
+    } as unknown as StructuredList;
+
+    const { container } = render(<StructuredListBlock list={list} renderText={(text) => [text]} />);
+
+    expect(screen.queryByRole('table')).toBeNull();
+    const rows = container.querySelectorAll('.structuredList__organization-row');
+    expect(rows).toHaveLength(3);
+    expect(rows[0].textContent).toBe('AAMA Fenestration and Glazing Industry Alliance ( www.fgiaonline.org)');
+    expect(rows[1].textContent).toBe('ICC International Code Council');
+    expect(rows[2].textContent).toBe('NBC');
+    expect(screen.getByRole('link', { name: 'www.fgiaonline.org' })).toHaveAttribute('href', 'https://www.fgiaonline.org');
+  });
+});
diff --git a/apps/web/components/reading/StructuredListBlock.tsx b/apps/web/components/reading/StructuredListBlock.tsx
index 44b3b28..c1fcd75 100644
--- a/apps/web/components/reading/StructuredListBlock.tsx
+++ b/apps/web/components/reading/StructuredListBlock.tsx
@@ -74,33 +74,22 @@ export const StructuredListBlock: React.FC<StructuredListBlockProps> = ({
     case 'organization':
       return (
         <div className="structuredList structuredList--organization">
-          <table className="structuredList__table">
-            <caption className="structuredList__caption">Organizations</caption>
-            <thead>
-              <tr>
-                <th scope="col">Abbreviation</th>
-                <th scope="col">Organization</th>
-                <th scope="col">Website</th>
-              </tr>
-            </thead>
-            <tbody>
-              {list.items.map((item, index) => (
-                <tr key={item.id || `${list.type}-${index}`}>
-                  <td>{item.abbreviation}</td>
-                  <td>{item.fullName}</td>
-                  <td>
-                    {item.website ? (
-                      <a href={item.website} target="_blank" rel="noopener noreferrer">
-                        {item.website}
-                      </a>
-                    ) : (
-                      '-'
-                    )}
-                  </td>
-                </tr>
-              ))}
-            </tbody>
-          </table>
+          {/* CLAUDE-AUTOFIX CL-057 CF-00798 | issue 559 | The PDF prints each organization as one plain line: "ABBR  Full name ( www.example.org)", with no table, caption or column headings. */}
+          {list.items.map((item, index) => (
+            <p key={item.id || `${list.type}-${index}`} className="structuredList__organization-row">
+              <span className="structuredList__organization-abbreviation">{item.abbreviation}</span>
+              {item.fullName ? ` ${item.fullName}` : ''}
+              {item.website ? (
+                <>
+                  {' ( '}
+                  <a href={item.website} target="_blank" rel="noopener noreferrer">
+                    {item.website.replace(/^https?:\/\//i, '')}
+                  </a>
+                  {')'}
+                </>
+              ) : null}
+            </p>
+          ))}
         </div>
       );
     case 'bibliography':
```

## 8. CL-064 - Show the objective keys and titles in plain type as in the PDF (CL-064).

- **Tag:** `webfix/CL-064-CF-00283`  **Commit:** `cb14de8be1bb546e463fa026471b16ce06b0ef0f` (2026-11-12 01:45, branch `ai-fix/session_1`)
- **Lead issue:** CF-00283 - Formatting, A.2.2.1.1.(1)
- **Issues expected to clear:** **23** (observed in a later comparison: 23)
- **Basis of the count:** latest_17: the 23 CL-064 issues at Article 2.2.1.1. (OS, OS1-OS5, OH, OH1-OH5, OA, OA1-OA2, OP, OP1-OP4, OE, OE1-OE2 titles: plain in PDF, bold on website). Live: 23 keys and 23 titles now regular weight.
- **New issues:** None. latest_18: 0 regressions; no new issue from this fix.
- **Issues that stay:** 36 other CL-064 issues (figure captions of appendix notes A-4.1.6.x, table captions, organization names in A-9.3.2.1.(1), Note A-1.2.1.1 headings and singles) moved to manual fixes: the PDF mixes bold and plain for the same kind of element, so no website rule is safe.
- **Ledger cluster:** CL-064, 120 issue(s) in the ledger
- **What was wrong:** PDF: 'OS Safety' / 'OS1 Fire Safety' in plain type | before: bold | after: plain
- **Root cause:** ObjectivesList.css sets bold on the objective key, title and sub-objective title; the PDF prints them plain (OS Safety, OS1 Fire Safety ...). The component is used for one node only (Article 2.2.1.1.).
- **Files:** `apps/web/components/reading/ObjectivesList.css`
- **Patch:** `web-fixes/CL-064-CF-00283.patch`

```
 apps/web/components/reading/ObjectivesList.css | 6 ++++++
 1 file changed, 6 insertions(+)
```

```diff
diff --git a/apps/web/components/reading/ObjectivesList.css b/apps/web/components/reading/ObjectivesList.css
index 5f590d2..e896acf 100644
--- a/apps/web/components/reading/ObjectivesList.css
+++ b/apps/web/components/reading/ObjectivesList.css
@@ -36,12 +36,16 @@
 
 .objectivesList__key {
     font: var(--typography-bold-body);
+    /* CLAUDE-AUTOFIX CL-064 CF-00283 | issue 56 | The PDF prints the objective keys and titles (OS Safety, OS1 Fire Safety ...) in plain type. */
+    font-weight: var(--typography-font-weights-regular);
     color: var(--typography-color-primary);
     white-space: nowrap;
 }
 
 .objectivesList__title {
     font: var(--typography-bold-h5);
+    /* CLAUDE-AUTOFIX CL-064 CF-00283 | issue 56 | The PDF prints the objective keys and titles (OS Safety, OS1 Fire Safety ...) in plain type. */
+    font-weight: var(--typography-font-weights-regular);
     color: var(--typography-color-primary);
     font-size: 16px;
 }
@@ -78,6 +82,8 @@
 
 .objectivesList__subTerm .objectivesList__title {
     font: var(--typography-bold-body);
+    /* CLAUDE-AUTOFIX CL-064 CF-00283 | issue 56 | The PDF prints the objective keys and titles (OS Safety, OS1 Fire Safety ...) in plain type. */
+    font-weight: var(--typography-font-weights-regular);
 }
 
 /* Responsive adjustments */
```

## 9. CL-063 - Show header-cell footnote markers, superscripts and subscripts in plain type in the 112 tables where the PDF does (CL-063 safe subset).

- **Tag:** `webfix/CL-063-CF-00374`  **Commit:** `4896a6ee4b4be36fbc36887f8388c267f99a9b1a` (2026-11-12 08:22, branch `ai-fix/session_1`)
- **Lead issue:** CF-00374 - Formatting, B.1.3.1.2.Tbl1#Row1.Col2
- **Issues expected to clear:** **128** (observed in a later comparison: 128)
- **Basis of the count:** latest_17: CL-063 had 519 header-cell issues. Only the tables where EVERY header glyph cell (footnote marker, superscript, subscript) is flagged plain in the PDF were taken: 112 tables verified live; 128 issues are glyph-like text in those cells. latest_18 started at 02:31 UTC, before this rule was applied, so the 128 issues are still reported there (shown as 'reopened'); they are measured by the next run.
- **New issues:** latest_19: all 128 gone, none reopened. The comparison now splits the header text of 14 tables into smaller pieces (same difference, more rows): handled by CF-06144.
- **Issues that stay:** About 390 CL-063 issues stay as manual fixes: tables where the PDF mixes bold and plain glyphs (a rule would create about 100 new issues), whole plain header cells, body-row cells, 3 tables with an ordinary link in a header cell, and 14 tables that could not be verified live.
- **Ledger cluster:** CL-063, 561 issue(s) in the ledger
- **What was wrong:** PDF: Document Number bold with a plain (3) marker | before: (3) bold | after: (3) plain, words bold
- **Root cause:** The website renders every header cell bold, including the footnote markers, superscripts and subscripts inside it; in these 112 tables the PDF prints those glyphs plain (the header words stay bold).
- **Files:** `apps/web/components/reading/TableBlock.css`
- **Patch:** `web-fixes/CL-063-CF-00374.patch`

```
 apps/web/components/reading/TableBlock.css | 116 +++++++++++++++++++++++++++++
 1 file changed, 116 insertions(+)
```

```diff
diff --git a/apps/web/components/reading/TableBlock.css b/apps/web/components/reading/TableBlock.css
index 9f82f87..2d1ae6a 100644
--- a/apps/web/components/reading/TableBlock.css
+++ b/apps/web/components/reading/TableBlock.css
@@ -68,6 +68,122 @@
   font-weight: var(--typography-font-weights-regular, 400);
 }
 
+/* CLAUDE-AUTOFIX CL-063 CF-00374 | issue 125 | In these 112 tables every footnote marker, superscript and subscript in a header cell is plain in the PDF (the header words are bold); each table was checked live. Tables where the PDF mixes bold and plain glyphs are not listed. */
+.table-block[id="nbc.divB.appendixD.appsect1.subsect1.article2.table1"] .table-block__header-cell :is(sup, sub, .cross-reference-link),
+.table-block[id="nbc.divB.appendixD.appsect2.subsect10.article1.table1"] .table-block__header-cell :is(sup, sub, .cross-reference-link),
+.table-block[id="nbc.divB.appendixD.appsect2.subsect3.article4.table2"] .table-block__header-cell :is(sup, sub, .cross-reference-link),
+.table-block[id="nbc.divB.appendixD.appsect2.subsect3.article4.table3"] .table-block__header-cell :is(sup, sub, .cross-reference-link),
+.table-block[id="nbc.divB.appendixD.appsect2.subsect3.article9.table1"] .table-block__header-cell :is(sup, sub, .cross-reference-link),
+.table-block[id="nbc.divB.appendixD.appsect2.subsect5.article1.table1"] .table-block__header-cell :is(sup, sub, .cross-reference-link),
+.table-block[id="nbc.divB.appendixD.appsect2.subsect6.article1.table2"] .table-block__header-cell :is(sup, sub, .cross-reference-link),
+.table-block[id="nbc.divB.appendixD.appsect2.subsect6.article1.table3"] .table-block__header-cell :is(sup, sub, .cross-reference-link),
+.table-block[id="nbc.divB.appendixD.appsect2.subsect6.article1.table4"] .table-block__header-cell :is(sup, sub, .cross-reference-link),
+.table-block[id="nbc.divB.appendixD.appsect2.subsect6.article1.table5"] .table-block__header-cell :is(sup, sub, .cross-reference-link),
+.table-block[id="nbc.divB.appendixD.appsect2.subsect6.article1.table6"] .table-block__header-cell :is(sup, sub, .cross-reference-link),
+.table-block[id="nbc.divB.appendixD.appsect2.subsect6.article6.table1"] .table-block__header-cell :is(sup, sub, .cross-reference-link),
+.table-block[id="nbc.divB.appendixD.appsect3.subsect1.article1.table2"] .table-block__header-cell :is(sup, sub, .cross-reference-link),
+.table-block[id="nbc.divB.part1.sect3.subsect1.art2.table1"] .table-block__header-cell :is(sup, sub, .cross-reference-link),
+.table-block[id="nbc.divB.part10.sect2.subsect3.art3.table1"] .table-block__header-cell :is(sup, sub, .cross-reference-link),
+.table-block[id="nbc.divB.part10.sect2.subsect3.art3.table10"] .table-block__header-cell :is(sup, sub, .cross-reference-link),
+.table-block[id="nbc.divB.part10.sect2.subsect3.art3.table2"] .table-block__header-cell :is(sup, sub, .cross-reference-link),
+.table-block[id="nbc.divB.part10.sect2.subsect3.art3.table3"] .table-block__header-cell :is(sup, sub, .cross-reference-link),
+.table-block[id="nbc.divB.part10.sect2.subsect3.art3.table4"] .table-block__header-cell :is(sup, sub, .cross-reference-link),
+.table-block[id="nbc.divB.part10.sect2.subsect3.art3.table5"] .table-block__header-cell :is(sup, sub, .cross-reference-link),
+.table-block[id="nbc.divB.part10.sect2.subsect3.art3.table6"] .table-block__header-cell :is(sup, sub, .cross-reference-link),
+.table-block[id="nbc.divB.part10.sect2.subsect3.art3.table7"] .table-block__header-cell :is(sup, sub, .cross-reference-link),
+.table-block[id="nbc.divB.part10.sect2.subsect3.art3.table8"] .table-block__header-cell :is(sup, sub, .cross-reference-link),
+.table-block[id="nbc.divB.part10.sect2.subsect3.art3.table9"] .table-block__header-cell :is(sup, sub, .cross-reference-link),
+.table-block[id="nbc.divB.part10.sect3.subsect1.art3.table1"] .table-block__header-cell :is(sup, sub, .cross-reference-link),
+.table-block[id="nbc.divB.part10.sect4.subsect1.art1.table1"] .table-block__header-cell :is(sup, sub, .cross-reference-link),
+.table-block[id="nbc.divB.part3.sect1.subsect17.art1.table1"] .table-block__header-cell :is(sup, sub, .cross-reference-link),
+.table-block[id="nbc.divB.part3.sect1.subsect8.art17.table1"] .table-block__header-cell :is(sup, sub, .cross-reference-link),
+.table-block[id="nbc.divB.part3.sect2.subsect2.art25.table1"] .table-block__header-cell :is(sup, sub, .cross-reference-link),
+.table-block[id="nbc.divB.part3.sect2.subsect2.art30.table1"] .table-block__header-cell :is(sup, sub, .cross-reference-link),
+.table-block[id="nbc.divB.part3.sect2.subsect2.art50.table1"] .table-block__header-cell :is(sup, sub, .cross-reference-link),
+.table-block[id="nbc.divB.part3.sect2.subsect2.art53.table1"] .table-block__header-cell :is(sup, sub, .cross-reference-link),
+.table-block[id="nbc.divB.part3.sect2.subsect2.art54.table1"] .table-block__header-cell :is(sup, sub, .cross-reference-link),
+.table-block[id="nbc.divB.part3.sect2.subsect2.art58.table1"] .table-block__header-cell :is(sup, sub, .cross-reference-link),
+.table-block[id="nbc.divB.part3.sect2.subsect2.art62.table1"] .table-block__header-cell :is(sup, sub, .cross-reference-link),
+.table-block[id="nbc.divB.part3.sect2.subsect2.art64.table1"] .table-block__header-cell :is(sup, sub, .cross-reference-link),
+.table-block[id="nbc.divB.part3.sect2.subsect2.art68.table1"] .table-block__header-cell :is(sup, sub, .cross-reference-link),
+.table-block[id="nbc.divB.part3.sect2.subsect2.art70.table1"] .table-block__header-cell :is(sup, sub, .cross-reference-link),
+.table-block[id="nbc.divB.part3.sect2.subsect2.art78.table1"] .table-block__header-cell :is(sup, sub, .cross-reference-link),
+.table-block[id="nbc.divB.part3.sect2.subsect2.art80.table1"] .table-block__header-cell :is(sup, sub, .cross-reference-link),
+.table-block[id="nbc.divB.part3.sect2.subsect2.art83.table1"] .table-block__header-cell :is(sup, sub, .cross-reference-link),
+.table-block[id="nbc.divB.part3.sect2.subsect2.art85.table1"] .table-block__header-cell :is(sup, sub, .cross-reference-link),
+.table-block[id="nbc.divB.part3.sect2.subsect2.art87.table1"] .table-block__header-cell :is(sup, sub, .cross-reference-link),
+.table-block[id="nbc.divB.part3.sect2.subsect3.art1.table1"] .table-block__header-cell :is(sup, sub, .cross-reference-link),
+.table-block[id="nbc.divB.part3.sect2.subsect3.art1.table2"] .table-block__header-cell :is(sup, sub, .cross-reference-link),
+.table-block[id="nbc.divB.part3.sect2.subsect3.art1.table3"] .table-block__header-cell :is(sup, sub, .cross-reference-link),
+.table-block[id="nbc.divB.part3.sect2.subsect3.art1.table4"] .table-block__header-cell :is(sup, sub, .cross-reference-link),
+.table-block[id="nbc.divB.part3.sect2.subsect3.art1.table5"] .table-block__header-cell :is(sup, sub, .cross-reference-link),
+.table-block[id="nbc.divB.part3.sect2.subsect5.art8.table1"] .table-block__header-cell :is(sup, sub, .cross-reference-link),
+.table-block[id="nbc.divB.part3.sect3.subsect1.art5.table1"] .table-block__header-cell :is(sup, sub, .cross-reference-link),
+.table-block[id="nbc.divB.part3.sect3.subsect1.art5.table2"] .table-block__header-cell :is(sup, sub, .cross-reference-link),
+.table-block[id="nbc.divB.part3.sect4.subsect2.art1.table1"] .table-block__header-cell :is(sup, sub, .cross-reference-link),
+.table-block[id="nbc.divB.part3.sect4.subsect2.art1.table2"] .table-block__header-cell :is(sup, sub, .cross-reference-link),
+.table-block[id="nbc.divB.part3.sect4.subsect2.art2.table1"] .table-block__header-cell :is(sup, sub, .cross-reference-link),
+.table-block[id="nbc.divB.part4.sect1.subsect3.art2.table1"] .table-block__header-cell :is(sup, sub, .cross-reference-link),
+.table-block[id="nbc.divB.part4.sect1.subsect3.art2.table2"] .table-block__header-cell :is(sup, sub, .cross-reference-link),
+.table-block[id="nbc.divB.part4.sect1.subsect6.art2.table1"] .table-block__header-cell :is(sup, sub, .cross-reference-link),
+.table-block[id="nbc.divB.part4.sect1.subsect7.art3.table1"] .table-block__header-cell :is(sup, sub, .cross-reference-link),
+.table-block[id="nbc.divB.part4.sect1.subsect7.art4.table1"] .table-block__header-cell :is(sup, sub, .cross-reference-link),
+.table-block[id="nbc.divB.part4.sect1.subsect7.art7.table1"] .table-block__header-cell :is(sup, sub, .cross-reference-link),
+.table-block[id="nbc.divB.part4.sect1.subsect8.art11.table1"] .table-block__header-cell :is(sup, sub, .cross-reference-link),
+.table-block[id="nbc.divB.part4.sect1.subsect8.art18.table1"] .table-block__header-cell :is(sup, sub, .cross-reference-link),
+.table-block[id="nbc.divB.part4.sect1.subsect8.art4.table1"] .table-block__header-cell :is(sup, sub, .cross-reference-link),
+.table-block[id="nbc.divB.part4.sect1.subsect8.art5.table2"] .table-block__header-cell :is(sup, sub, .cross-reference-link),
+.table-block[id="nbc.divB.part4.sect1.subsect8.art9.table1"] .table-block__header-cell :is(sup, sub, .cross-reference-link),
+.table-block[id="nbc.divB.part4.sect5.subsect1.art1.table1"] .table-block__header-cell :is(sup, sub, .cross-reference-link),
+.table-block[id="nbc.divB.part5.sect10.subsect1.art1.table1"] .table-block__header-cell :is(sup, sub, .cross-reference-link),
+.table-block[id="nbc.divB.part5.sect4.subsect1.art1.table1"] .table-block__header-cell :is(sup, sub, .cross-reference-link),
+.table-block[id="nbc.divB.part6.sect10.subsect1.art1.table1"] .table-block__header-cell :is(sup, sub, .cross-reference-link),
+.table-block[id="nbc.divB.part7.sect2.subsect1.art1.table1"] .table-block__header-cell :is(sup, sub, .cross-reference-link),
+.table-block[id="nbc.divB.part8.sect3.subsect1.art1.table1"] .table-block__header-cell :is(sup, sub, .cross-reference-link),
+.table-block[id="nbc.divBV2.part9.appendix.appnote152.table1"] .table-block__header-cell :is(sup, sub, .cross-reference-link),
+.table-block[id="nbc.divBV2.part9.appendix.appnote223.div3.table1"] .table-block__header-cell :is(sup, sub, .cross-reference-link),
+.table-block[id="nbc.divBV2.part9.sect10.subsect14.art4.table1"] .table-block__header-cell :is(sup, sub, .cross-reference-link),
+.table-block[id="nbc.divBV2.part9.sect10.subsect14.art4.table2"] .table-block__header-cell :is(sup, sub, .cross-reference-link),
+.table-block[id="nbc.divBV2.part9.sect10.subsect14.art5.table2"] .table-block__header-cell :is(sup, sub, .cross-reference-link),
+.table-block[id="nbc.divBV2.part9.sect10.subsect15.art4.table1"] .table-block__header-cell :is(sup, sub, .cross-reference-link),
+.table-block[id="nbc.divBV2.part9.sect10.subsect2.art1.table1"] .table-block__header-cell :is(sup, sub, .cross-reference-link),
+.table-block[id="nbc.divBV2.part9.sect12.subsect2.art2.table1"] .table-block__header-cell :is(sup, sub, .cross-reference-link),
+.table-block[id="nbc.divBV2.part9.sect15.subsect4.art2.table2"] .table-block__header-cell :is(sup, sub, .cross-reference-link),
+.table-block[id="nbc.divBV2.part9.sect21.subsect2.art5.table1"] .table-block__header-cell :is(sup, sub, .cross-reference-link),
+.table-block[id="nbc.divBV2.part9.sect21.subsect2.art5.table2"] .table-block__header-cell :is(sup, sub, .cross-reference-link),
+.table-block[id="nbc.divBV2.part9.sect23.subsect14.art8.table1"] .table-block__header-cell :is(sup, sub, .cross-reference-link),
+.table-block[id="nbc.divBV2.part9.sect23.subsect17.art2.table1"] .table-block__header-cell :is(sup, sub, .cross-reference-link),
+.table-block[id="nbc.divBV2.part9.sect25.subsect5.art2.table1"] .table-block__header-cell :is(sup, sub, .cross-reference-link),
+.table-block[id="nbc.divBV2.part9.sect27.subsect5.art4.table1"] .table-block__header-cell :is(sup, sub, .cross-reference-link),
+.table-block[id="nbc.divBV2.part9.sect27.subsect5.art4.table2"] .table-block__header-cell :is(sup, sub, .cross-reference-link),
+.table-block[id="nbc.divBV2.part9.sect28.subsect4.art3.table1"] .table-block__header-cell :is(sup, sub, .cross-reference-link),
+.table-block[id="nbc.divBV2.part9.sect3.subsect2.art1.table1"] .table-block__header-cell :is(sup, sub, .cross-reference-link),
+.table-block[id="nbc.divBV2.part9.sect32.subsect3.art5.table1"] .table-block__header-cell :is(sup, sub, .cross-reference-link),
+.table-block[id="nbc.divBV2.part9.sect32.subsect3.art8.table1"] .table-block__header-cell :is(sup, sub, .cross-reference-link),
+.table-block[id="nbc.divBV2.part9.sect34.subsect2.art7.table1"] .table-block__header-cell :is(sup, sub, .cross-reference-link),
+.table-block[id="nbc.divBV2.part9.sect36.subsect2.art6.table1"] .table-block__header-cell :is(sup, sub, .cross-reference-link),
+.table-block[id="nbc.divBV2.part9.sect36.subsect2.art6.table2"] .table-block__header-cell :is(sup, sub, .cross-reference-link),
+.table-block[id="nbc.divBV2.part9.sect36.subsect2.art6.table3"] .table-block__header-cell :is(sup, sub, .cross-reference-link),
+.table-block[id="nbc.divBV2.part9.sect36.subsect2.art8.table1"] .table-block__header-cell :is(sup, sub, .cross-reference-link),
+.table-block[id="nbc.divBV2.part9.sect36.subsect2.art8.table2"] .table-block__header-cell :is(sup, sub, .cross-reference-link),
+.table-block[id="nbc.divBV2.part9.sect36.subsect3.art10.table1"] .table-block__header-cell :is(sup, sub, .cross-reference-link),
+.table-block[id="nbc.divBV2.part9.sect36.subsect4.art2.table1"] .table-block__header-cell :is(sup, sub, .cross-reference-link),
+.table-block[id="nbc.divBV2.part9.sect36.subsect5.art4.table1"] .table-block__header-cell :is(sup, sub, .cross-reference-link),
+.table-block[id="nbc.divBV2.part9.sect36.subsect6.art3.tableA"] .table-block__header-cell :is(sup, sub, .cross-reference-link),
+.table-block[id="nbc.divBV2.part9.sect36.subsect6.art3.tableB"] .table-block__header-cell :is(sup, sub, .cross-reference-link),
+.table-block[id="nbc.divBV2.part9.sect36.subsect6.art3.tableC"] .table-block__header-cell :is(sup, sub, .cross-reference-link),
+.table-block[id="nbc.divBV2.part9.sect36.subsect6.art3.tableD"] .table-block__header-cell :is(sup, sub, .cross-reference-link),
+.table-block[id="nbc.divBV2.part9.sect36.subsect6.art3.tableE"] .table-block__header-cell :is(sup, sub, .cross-reference-link),
+.table-block[id="nbc.divBV2.part9.sect36.subsect6.art3.tableF"] .table-block__header-cell :is(sup, sub, .cross-reference-link),
+.table-block[id="nbc.divBV2.part9.sect36.subsect6.art3.tableH"] .table-block__header-cell :is(sup, sub, .cross-reference-link),
+.table-block[id="nbc.divBV2.part9.sect36.subsect7.art4.table1"] .table-block__header-cell :is(sup, sub, .cross-reference-link),
+.table-block[id="nbc.divBV2.part9.sect38.subsect1.art1.table1"] .table-block__header-cell :is(sup, sub, .cross-reference-link),
+.table-block[id="nbc.divBV2.part9.sect5.subsect3.art1.table1"] .table-block__header-cell :is(sup, sub, .cross-reference-link),
+.table-block[id="nbc.divBV2.part9.sect6.subsect1.art3.table7"] .table-block__header-cell :is(sup, sub, .cross-reference-link),
+.table-block[id="nbc.divBV2.part9.sect9.subsect7.art4.table1"] .table-block__header-cell :is(sup, sub, .cross-reference-link) {
+  font-weight: var(--typography-font-weights-regular, 400);
+}
+
 .table-block__wrapper {
   display: block;
   width: 100%;
```

## 10. CL-028 - Print the Forming part of caption with a lowercase part in the 13 tables where the PDF does (CL-028 letter case).

- **Tag:** `webfix/CL-028-CF-10563`  **Commit:** `88aac806492df930c1b5025f348c9e9584e97ae7` (2026-11-12 08:30, branch `ai-fix/session_1`)
- **Lead issue:** CF-10563 - Formatting, B.10.2.3.3.Tbl1
- **Issues expected to clear:** **10** (observed in a later comparison: 10)
- **Basis of the count:** latest_18: 10 'letter case: PDF part -> website Part' issues at the Table 10.2.3.3. captions (tables 1 to 10), visible once the wording matched (CF-00876). 13 tables in all print 'Forming part of' in the PDF (whole-document case-insensitive scan): 10 tables of 10.2.3.3., 9.32.3.8, and the two Division A tables 1.1.1.1.(5) and (6).
- **New issues:** None: only the 13 listed ids change, to the exact PDF letter case; a control table is unchanged.
- **Issues that stay:** -
- **Ledger cluster:** CL-028, 133 issue(s) in the ledger
- **What was wrong:** PDF: 'Forming part of Sentences 10.2.3.3.(1) and (2)' | before: 'Forming Part of ...' | after: lowercase part
- **Root cause:** 
- **Files:** `apps/web/components/reading/TableBlock.test.tsx`, `apps/web/components/reading/TableBlock.tsx`
- **Patch:** `web-fixes/CL-028-CF-10563.patch`

```
 apps/web/components/reading/TableBlock.test.tsx | 23 +++++++++++++++++++++++
 apps/web/components/reading/TableBlock.tsx      | 22 +++++++++++++++++++++-
 2 files changed, 44 insertions(+), 1 deletion(-)
```

```diff
diff --git a/apps/web/components/reading/TableBlock.test.tsx b/apps/web/components/reading/TableBlock.test.tsx
index 92a53b6..03cb1de 100644
--- a/apps/web/components/reading/TableBlock.test.tsx
+++ b/apps/web/components/reading/TableBlock.test.tsx
@@ -689,6 +689,29 @@ describe('TableBlock', () => {
     expect(screen.getByText(expected)).toBeInTheDocument();
   });
 
+  // CLAUDE-AUTOFIX CL-028 CF-10563 | issue 2566 | A few tables print "Forming part of" with a lowercase "part" in the PDF.
+  it.each([
+    ['nbc.divB.part10.sect2.subsect3.art3.table4', 'Forming part of Sentences 10.2.3.3.(1) and (2)'],
+    ['nbc.divB.part3.sect1.subsect2.art1.table1', 'Forming Part of Sentences 10.2.3.3.(1) and (2)'],
+  ])('writes the forming part caption of %s with the PDF letter case', (id, expected) => {
+    const table = {
+      id,
+      type: 'table',
+      number: '10.2.3.3.',
+      title: 'Title',
+      headers: [['Header']],
+      rows: [{ cells: [{ content: 'Data' }] }],
+      formingPart: [
+        { type: 'internal', target: 'nbc.divB.part10.sect2.subsect3.art3.sent1', display_type: 'long' },
+        { type: 'internal', target: 'nbc.divB.part10.sect2.subsect3.art3.sent2', display_type: 'long' },
+      ],
+    } as unknown as Table;
+
+    render(<TableBlock table={table} />);
+
+    expect(screen.getByText(expected)).toBeInTheDocument();
+  });
+
   it('renders Appendix D table numbering from appendix-style ids when number is omitted', () => {
     const table: Table = {
       id: 'nbc.divB.appendixD.appsect1.subsect1.article2.table1',
diff --git a/apps/web/components/reading/TableBlock.tsx b/apps/web/components/reading/TableBlock.tsx
index 50c55cf..bcf97bb 100644
--- a/apps/web/components/reading/TableBlock.tsx
+++ b/apps/web/components/reading/TableBlock.tsx
@@ -754,6 +754,23 @@ const formatFormingPartItems = (items: FormingPartItem[]): string => {
   );
 };
 
+// CLAUDE-AUTOFIX CL-028 CF-10563 | issue 2566 | The PDF prints the caption as "Forming part of ..." with a lowercase "part" in these 13 tables (checked over the whole PDF); every other table has "Forming Part of ...".
+const LOWERCASE_FORMING_PART_TABLE_IDS = new Set<string>([
+  'nbc.divA.part1.sect1.subsect1.art1.table1',
+  'nbc.divA.part1.sect1.subsect1.art1.table2',
+  'nbc.divB.part10.sect2.subsect3.art3.table1',
+  'nbc.divB.part10.sect2.subsect3.art3.table2',
+  'nbc.divB.part10.sect2.subsect3.art3.table3',
+  'nbc.divB.part10.sect2.subsect3.art3.table4',
+  'nbc.divB.part10.sect2.subsect3.art3.table5',
+  'nbc.divB.part10.sect2.subsect3.art3.table6',
+  'nbc.divB.part10.sect2.subsect3.art3.table7',
+  'nbc.divB.part10.sect2.subsect3.art3.table8',
+  'nbc.divB.part10.sect2.subsect3.art3.table9',
+  'nbc.divB.part10.sect2.subsect3.art3.table10',
+  'nbc.divBV2.part9.sect32.subsect3.art8.table1',
+]);
+
 const formatFormingPartText = (formingPart: FormingPartReference[] | undefined): string | null => {
   if (!formingPart || formingPart.length === 0) {
     return null;
@@ -1523,7 +1540,10 @@ export const TableBlock: React.FC<TableBlockProps> = ({
   const tableNumber = tableNumberOverride ?? getResolvedTableNumber(rawTable, appendixSiblingTableCount);
   const tableNumberDisplay = tableNumber ? getTableNumberDisplay(tableNumber) : null;
   const tableNotesHeading = tableNumberDisplay ? `Notes to ${tableNumberDisplay}:` : 'Table notes';
-  const formingPartText = formatFormingPartText(formingPartEntries);
+  const formattedFormingPartText = formatFormingPartText(formingPartEntries);
+  const formingPartText = LOWERCASE_FORMING_PART_TABLE_IDS.has(rawTable.id)
+    ? formattedFormingPartText?.replace(/^Forming Part/, 'Forming part') ?? null
+    : formattedFormingPartText;
 
   const structure = activeRevision?.structure ?? rawTable.structure;
   const hasDirectRows = Array.isArray(table.rows) && table.rows.length > 0;
```

## 11. CL-063 - Show the whole header row in plain type in the 14 tables where the PDF does (CL-063 plain-header tables).

- **Tag:** `webfix/CL-063-CF-06144`  **Commit:** `78d263f273f21bafe5318fbd09dc606d8ec23133` (2026-11-12 08:56, branch `ai-fix/session_1`)
- **Lead issue:** CF-06144 - Formatting, B.9.36.6.3.Tbl3#Row1.Col1
- **Issues expected to clear:** **78** (observed in a later comparison: 77)
- **Basis of the count:** latest_19: 78 'plain in PDF, bold on website' header-cell issues in 14 tables whose whole header row is plain in the PDF: Tables 10.2.3.3. (1 to 10) and 9.36.6.3.-C to -F. Selected by the PDF fonts of every flagged cell, not only by the comparison flags (9.36.6.3.-A and -B were excluded: not plain in the PDF).
- **New issues:** None caused. latest_20: 77 of the linked issues gone. The comparison now also reports the word 'Building' in 8 header cells of Tables 9.36.6.3.-C to -F as italic in the PDF but plain on the website (a defined term written as plain text in the data): it was hidden behind the bold difference before. XML fix, not a regression.
- **Issues that stay:** Header cells of other tables with mixed bold and plain text stay manual.
- **Ledger cluster:** CL-063, 561 issue(s) in the ledger
- **What was wrong:** PDF: header row in plain ArialNarrow | before: bold | after: plain
- **Root cause:** The website renders every header cell bold; in these 14 tables the whole header row is plain in the PDF (ArialNarrow regular, checked with the PDF fonts of every flagged cell). After the glyph rule (CF-00374) the comparison reports the remaining header words.
- **Files:** `apps/web/components/reading/TableBlock.css`
- **Patch:** `web-fixes/CL-063-CF-06144.patch`

```
 apps/web/components/reading/TableBlock.css | 18 ++++++++++++++++++
 1 file changed, 18 insertions(+)
```

```diff
diff --git a/apps/web/components/reading/TableBlock.css b/apps/web/components/reading/TableBlock.css
index 2d1ae6a..01b42a5 100644
--- a/apps/web/components/reading/TableBlock.css
+++ b/apps/web/components/reading/TableBlock.css
@@ -184,6 +184,24 @@
   font-weight: var(--typography-font-weights-regular, 400);
 }
 
+/* CLAUDE-AUTOFIX CL-063 CF-06144 | issue 967 | In these 14 tables the whole header row is plain in the PDF (ArialNarrow regular, checked with the PDF fonts): Tables 10.2.3.3. (1 to 10) and 9.36.6.3.-C to -F. */
+.table-block[id="nbc.divB.part10.sect2.subsect3.art3.table1"] .table-block__header-cell,
+.table-block[id="nbc.divB.part10.sect2.subsect3.art3.table2"] .table-block__header-cell,
+.table-block[id="nbc.divB.part10.sect2.subsect3.art3.table3"] .table-block__header-cell,
+.table-block[id="nbc.divB.part10.sect2.subsect3.art3.table4"] .table-block__header-cell,
+.table-block[id="nbc.divB.part10.sect2.subsect3.art3.table5"] .table-block__header-cell,
+.table-block[id="nbc.divB.part10.sect2.subsect3.art3.table6"] .table-block__header-cell,
+.table-block[id="nbc.divB.part10.sect2.subsect3.art3.table7"] .table-block__header-cell,
+.table-block[id="nbc.divB.part10.sect2.subsect3.art3.table8"] .table-block__header-cell,
+.table-block[id="nbc.divB.part10.sect2.subsect3.art3.table9"] .table-block__header-cell,
+.table-block[id="nbc.divB.part10.sect2.subsect3.art3.table10"] .table-block__header-cell,
+.table-block[id="nbc.divBV2.part9.sect36.subsect6.art3.tableC"] .table-block__header-cell,
+.table-block[id="nbc.divBV2.part9.sect36.subsect6.art3.tableD"] .table-block__header-cell,
+.table-block[id="nbc.divBV2.part9.sect36.subsect6.art3.tableE"] .table-block__header-cell,
+.table-block[id="nbc.divBV2.part9.sect36.subsect6.art3.tableF"] .table-block__header-cell {
+  font-weight: var(--typography-font-weights-regular, 400);
+}
+
 .table-block__wrapper {
   display: block;
   width: 100%;
```

## 12. CL-063 - Show 73 header cells in plain type in the 13 tables where the PDF prints them plain (CL-063 per-cell).

- **Tag:** `webfix/CL-063-CF-00274`  **Commit:** `8c61162ecc625699afb093fd389fd756ea59af94` (2026-11-12 09:05, branch `ai-fix/session_1`)
- **Lead issue:** CF-00274 - Formatting, A.A-1.4.1.2.(1).Tbl1#Row1.Col1
- **Issues expected to clear:** **68** (observed in a later comparison: 67)
- **Basis of the count:** latest_19: 113 parked header-cell issues had plain text confirmed by the PDF fonts; of these 73 are in cells without a footnote marker, superscript, equation or link and with the flagged text covering the whole cell (13 tables). The 40 left out are partial or glyph cells.
- **New issues:** None caused. latest_20: 67 of 67 linked issues gone. 5 issues had been credited to this fix by mistake (tables with spanned columns: the issue column number differs from the data cell position); they are back to pending and listed for a second per-cell rule (GWB-A/B/C in Table 9.23.13.7., Table 9.36.6.3.-G, Table A-9.32.4.1.-B).
- **Issues that stay:** Header cells that mix bold and plain text, cells with footnote markers in tables where the PDF is mixed, and body-row cells stay manual.
- **Ledger cluster:** CL-063, 561 issue(s) in the ledger
- **What was wrong:** PDF: TDGR / WHMIS / British Columbia Building Code headers plain | before: bold | after: plain
- **Root cause:** The website renders every header cell bold; in these 13 tables some header cells (word cells such as TDGR, WHMIS, Room, Fuel Type) are plain in the PDF (ArialNarrow regular, confirmed with the PDF fonts of the flagged text) while the other header cells are bold.
- **Files:** `apps/web/components/reading/TableBlock.css`
- **Patch:** `web-fixes/CL-063-CF-00274.patch`

```
 apps/web/components/reading/TableBlock.css | 77 ++++++++++++++++++++++++++++++
 1 file changed, 77 insertions(+)
```

```diff
diff --git a/apps/web/components/reading/TableBlock.css b/apps/web/components/reading/TableBlock.css
index 01b42a5..63f5f97 100644
--- a/apps/web/components/reading/TableBlock.css
+++ b/apps/web/components/reading/TableBlock.css
@@ -202,6 +202,83 @@
   font-weight: var(--typography-font-weights-regular, 400);
 }
 
+/* CLAUDE-AUTOFIX CL-063 CF-00274 | issue 51 | These 73 header cells in 13 tables are plain in the PDF (ArialNarrow regular, checked with the PDF fonts) while the other header cells of the same tables are bold. Cells are addressed by table id, header row and position on the page; each was checked live. */
+.table-block[id="nbc.divA.part1.appendix.appnote7.div5.table1"] thead > tr:nth-child(1) > .table-block__header-cell:nth-child(1),
+.table-block[id="nbc.divA.part1.appendix.appnote7.div5.table1"] thead > tr:nth-child(1) > .table-block__header-cell:nth-child(2),
+.table-block[id="nbc.divA.part1.appendix.appnote7.div5.table1"] thead > tr:nth-child(1) > .table-block__header-cell:nth-child(3),
+.table-block[id="nbc.divA.part1.appendix.appnote7.div5.table1"] thead > tr:nth-child(2) > .table-block__header-cell:nth-child(1),
+.table-block[id="nbc.divA.part1.appendix.appnote7.div5.table1"] thead > tr:nth-child(2) > .table-block__header-cell:nth-child(2),
+.table-block[id="nbc.divB.part10.sect3.subsect1.art3.table1"] thead > tr:nth-child(1) > .table-block__header-cell:nth-child(1),
+.table-block[id="nbc.divB.part10.sect3.subsect1.art3.table1"] thead > tr:nth-child(3) > .table-block__header-cell:nth-child(1),
+.table-block[id="nbc.divB.part10.sect3.subsect1.art3.table1"] thead > tr:nth-child(3) > .table-block__header-cell:nth-child(3),
+.table-block[id="nbc.divBV2.part9.appendix.appnote129a.table1"] thead > tr:nth-child(2) > .table-block__header-cell:nth-child(1),
+.table-block[id="nbc.divBV2.part9.appendix.appnote129a.table1"] thead > tr:nth-child(2) > .table-block__header-cell:nth-child(2),
+.table-block[id="nbc.divBV2.part9.appendix.appnote129a.table1"] thead > tr:nth-child(2) > .table-block__header-cell:nth-child(3),
+.table-block[id="nbc.divBV2.part9.appendix.appnote129a.table1"] thead > tr:nth-child(2) > .table-block__header-cell:nth-child(4),
+.table-block[id="nbc.divBV2.part9.appendix.appnote199a.tableA"] thead > tr:nth-child(1) > .table-block__header-cell:nth-child(1),
+.table-block[id="nbc.divBV2.part9.appendix.appnote199a.tableA"] thead > tr:nth-child(1) > .table-block__header-cell:nth-child(2),
+.table-block[id="nbc.divBV2.part9.appendix.appnote199a.tableA"] thead > tr:nth-child(2) > .table-block__header-cell:nth-child(1),
+.table-block[id="nbc.divBV2.part9.appendix.appnote199a.tableA"] thead > tr:nth-child(3) > .table-block__header-cell:nth-child(1),
+.table-block[id="nbc.divBV2.part9.appendix.appnote199a.tableA"] thead > tr:nth-child(3) > .table-block__header-cell:nth-child(2),
+.table-block[id="nbc.divBV2.part9.appendix.appnote199a.tableA"] thead > tr:nth-child(3) > .table-block__header-cell:nth-child(3),
+.table-block[id="nbc.divBV2.part9.appendix.appnote199a.tableB"] thead > tr:nth-child(1) > .table-block__header-cell:nth-child(1),
+.table-block[id="nbc.divBV2.part9.appendix.appnote199a.tableB"] thead > tr:nth-child(1) > .table-block__header-cell:nth-child(2),
+.table-block[id="nbc.divBV2.part9.appendix.appnote199a.tableB"] thead > tr:nth-child(1) > .table-block__header-cell:nth-child(3),
+.table-block[id="nbc.divBV2.part9.appendix.appnote199a.tableB"] thead > tr:nth-child(2) > .table-block__header-cell:nth-child(1),
+.table-block[id="nbc.divBV2.part9.appendix.appnote199a.tableB"] thead > tr:nth-child(2) > .table-block__header-cell:nth-child(5),
+.table-block[id="nbc.divBV2.part9.appendix.appnote199a.tableB"] thead > tr:nth-child(3) > .table-block__header-cell:nth-child(1),
+.table-block[id="nbc.divBV2.part9.appendix.appnote199a.tableB"] thead > tr:nth-child(3) > .table-block__header-cell:nth-child(4),
+.table-block[id="nbc.divBV2.part9.appendix.appnote199a.tableB"] thead > tr:nth-child(3) > .table-block__header-cell:nth-child(5),
+.table-block[id="nbc.divBV2.part9.appendix.appnote199a.tableB"] thead > tr:nth-child(3) > .table-block__header-cell:nth-child(6),
+.table-block[id="nbc.divBV2.part9.appendix.appnote199a.tableB"] thead > tr:nth-child(3) > .table-block__header-cell:nth-child(7),
+.table-block[id="nbc.divBV2.part9.sect23.subsect13.art11.table3"] thead > tr:nth-child(3) > .table-block__header-cell:nth-child(1),
+.table-block[id="nbc.divBV2.part9.sect23.subsect13.art11.table3"] thead > tr:nth-child(3) > .table-block__header-cell:nth-child(2),
+.table-block[id="nbc.divBV2.part9.sect23.subsect13.art11.table3"] thead > tr:nth-child(3) > .table-block__header-cell:nth-child(3),
+.table-block[id="nbc.divBV2.part9.sect23.subsect13.art11.table3"] thead > tr:nth-child(3) > .table-block__header-cell:nth-child(4),
+.table-block[id="nbc.divBV2.part9.sect23.subsect13.art11.table3"] thead > tr:nth-child(3) > .table-block__header-cell:nth-child(5),
+.table-block[id="nbc.divBV2.part9.sect23.subsect13.art11.table3"] thead > tr:nth-child(3) > .table-block__header-cell:nth-child(6),
+.table-block[id="nbc.divBV2.part9.sect23.subsect13.art11.table3"] thead > tr:nth-child(3) > .table-block__header-cell:nth-child(7),
+.table-block[id="nbc.divBV2.part9.sect23.subsect13.art11.table3"] thead > tr:nth-child(3) > .table-block__header-cell:nth-child(8),
+.table-block[id="nbc.divBV2.part9.sect23.subsect13.art11.table3"] thead > tr:nth-child(3) > .table-block__header-cell:nth-child(9),
+.table-block[id="nbc.divBV2.part9.sect23.subsect13.art11.table3"] thead > tr:nth-child(3) > .table-block__header-cell:nth-child(10),
+.table-block[id="nbc.divBV2.part9.sect23.subsect13.art11.table4"] thead > tr:nth-child(3) > .table-block__header-cell:nth-child(1),
+.table-block[id="nbc.divBV2.part9.sect23.subsect13.art11.table4"] thead > tr:nth-child(3) > .table-block__header-cell:nth-child(2),
+.table-block[id="nbc.divBV2.part9.sect23.subsect13.art11.table4"] thead > tr:nth-child(3) > .table-block__header-cell:nth-child(3),
+.table-block[id="nbc.divBV2.part9.sect23.subsect13.art11.table4"] thead > tr:nth-child(3) > .table-block__header-cell:nth-child(4),
+.table-block[id="nbc.divBV2.part9.sect23.subsect13.art11.table4"] thead > tr:nth-child(3) > .table-block__header-cell:nth-child(5),
+.table-block[id="nbc.divBV2.part9.sect23.subsect13.art11.table4"] thead > tr:nth-child(3) > .table-block__header-cell:nth-child(6),
+.table-block[id="nbc.divBV2.part9.sect23.subsect13.art11.table4"] thead > tr:nth-child(3) > .table-block__header-cell:nth-child(7),
+.table-block[id="nbc.divBV2.part9.sect23.subsect13.art11.table4"] thead > tr:nth-child(3) > .table-block__header-cell:nth-child(8),
+.table-block[id="nbc.divBV2.part9.sect23.subsect13.art11.table4"] thead > tr:nth-child(3) > .table-block__header-cell:nth-child(9),
+.table-block[id="nbc.divBV2.part9.sect23.subsect13.art11.table4"] thead > tr:nth-child(3) > .table-block__header-cell:nth-child(10),
+.table-block[id="nbc.divBV2.part9.sect23.subsect13.art7.table1"] thead > tr:nth-child(3) > .table-block__header-cell:nth-child(4),
+.table-block[id="nbc.divBV2.part9.sect23.subsect13.art7.table1"] thead > tr:nth-child(3) > .table-block__header-cell:nth-child(5),
+.table-block[id="nbc.divBV2.part9.sect23.subsect13.art7.table1"] thead > tr:nth-child(3) > .table-block__header-cell:nth-child(6),
+.table-block[id="nbc.divBV2.part9.sect23.subsect13.art7.table1"] thead > tr:nth-child(3) > .table-block__header-cell:nth-child(7),
+.table-block[id="nbc.divBV2.part9.sect23.subsect13.art7.table1"] thead > tr:nth-child(3) > .table-block__header-cell:nth-child(8),
+.table-block[id="nbc.divBV2.part9.sect23.subsect13.art7.table1"] thead > tr:nth-child(3) > .table-block__header-cell:nth-child(9),
+.table-block[id="nbc.divBV2.part9.sect32.subsect3.art5.table1"] thead > tr:nth-child(3) > .table-block__header-cell:nth-child(1),
+.table-block[id="nbc.divBV2.part9.sect32.subsect3.art5.table1"] thead > tr:nth-child(3) > .table-block__header-cell:nth-child(2),
+.table-block[id="nbc.divBV2.part9.sect32.subsect3.art5.table1"] thead > tr:nth-child(3) > .table-block__header-cell:nth-child(3),
+.table-block[id="nbc.divBV2.part9.sect32.subsect3.art5.table1"] thead > tr:nth-child(3) > .table-block__header-cell:nth-child(4),
+.table-block[id="nbc.divBV2.part9.sect32.subsect3.art5.table1"] thead > tr:nth-child(3) > .table-block__header-cell:nth-child(5),
+.table-block[id="nbc.divBV2.part9.sect32.subsect3.art6.table1"] thead > tr:nth-child(1) > .table-block__header-cell:nth-child(1),
+.table-block[id="nbc.divBV2.part9.sect32.subsect3.art6.table1"] thead > tr:nth-child(1) > .table-block__header-cell:nth-child(2),
+.table-block[id="nbc.divBV2.part9.sect32.subsect3.art6.table1"] thead > tr:nth-child(2) > .table-block__header-cell:nth-child(1),
+.table-block[id="nbc.divBV2.part9.sect32.subsect3.art6.table1"] thead > tr:nth-child(2) > .table-block__header-cell:nth-child(2),
+.table-block[id="nbc.divBV2.part9.sect32.subsect3.art8.table1"] thead > tr:nth-child(1) > .table-block__header-cell:nth-child(1),
+.table-block[id="nbc.divBV2.part9.sect32.subsect3.art8.table1"] thead > tr:nth-child(3) > .table-block__header-cell:nth-child(1),
+.table-block[id="nbc.divBV2.part9.sect32.subsect3.art8.table1"] thead > tr:nth-child(3) > .table-block__header-cell:nth-child(2),
+.table-block[id="nbc.divBV2.part9.sect32.subsect3.art8.table1"] thead > tr:nth-child(3) > .table-block__header-cell:nth-child(3),
+.table-block[id="nbc.divBV2.part9.sect32.subsect3.art8.table1"] thead > tr:nth-child(3) > .table-block__header-cell:nth-child(4),
+.table-block[id="nbc.divBV2.part9.sect32.subsect3.art8.table1"] thead > tr:nth-child(3) > .table-block__header-cell:nth-child(5),
+.table-block[id="nbc.divBV2.part9.sect32.subsect3.art8.table1"] thead > tr:nth-child(3) > .table-block__header-cell:nth-child(6),
+.table-block[id="nbc.divBV2.part9.sect36.subsect6.art3.tableG"] thead > tr:nth-child(1) > .table-block__header-cell:nth-child(2),
+.table-block[id="nbc.divBV2.part9.sect36.subsect6.art3.tableG"] thead > tr:nth-child(2) > .table-block__header-cell:nth-child(3),
+.table-block[id="nbc.divBV2.part9.sect36.subsect6.art3.tableH"] thead > tr:nth-child(1) > .table-block__header-cell:nth-child(3) {
+  font-weight: var(--typography-font-weights-regular, 400);
+}
+
 .table-block__wrapper {
   display: block;
   width: 100%;
```

## 13. CL-063 - Show GWB-A, GWB-B and GWB-C plain in the Table 9.23.13.7 header as in the PDF (CL-063 spanned-column cells).

- **Tag:** `webfix/CL-063-CF-04859`  **Commit:** `977b08645a6ad6aa3bdd6a736c4f18b93e9e3fc0` (2026-11-12 13:01, branch `ai-fix/session_1`)
- **Lead issue:** CF-04859 - Formatting, B.9.23.13.7.Tbl1#Row3.Col4
- **Issues expected to clear:** **?** (to be confirmed by the next comparison)
- **Basis of the count:** -
- **New issues:** -
- **Issues that stay:** -
- **Ledger cluster:** CL-063, 561 issue(s) in the ledger
- **What was wrong:** PDF: GWB- A/B/C plain | before: GWB-A/B/C bold, GWB-D..WSP-E plain | after: GWB-A..WSP-E all plain
- **Root cause:** CL-063 per-cell: the CF-00274 rule for art7.table1 row 3 covered cells 4-9 only; with three row-spanned header cells (HWP, Storey, DWB) above, GWB-A/B/C are data cells 1-3 of row 3 and were missed.
- **Files:** `apps/web/components/reading/TableBlock.css`
- **Patch:** `web-fixes/CL-063-CF-04859.patch`

```
 apps/web/components/reading/TableBlock.css | 4 ++++
 1 file changed, 4 insertions(+)
```

```diff
diff --git a/apps/web/components/reading/TableBlock.css b/apps/web/components/reading/TableBlock.css
index 63f5f97..4bd54f1 100644
--- a/apps/web/components/reading/TableBlock.css
+++ b/apps/web/components/reading/TableBlock.css
@@ -251,6 +251,10 @@
 .table-block[id="nbc.divBV2.part9.sect23.subsect13.art11.table4"] thead > tr:nth-child(3) > .table-block__header-cell:nth-child(8),
 .table-block[id="nbc.divBV2.part9.sect23.subsect13.art11.table4"] thead > tr:nth-child(3) > .table-block__header-cell:nth-child(9),
 .table-block[id="nbc.divBV2.part9.sect23.subsect13.art11.table4"] thead > tr:nth-child(3) > .table-block__header-cell:nth-child(10),
+/* CLAUDE-AUTOFIX CL-063 CF-04859 | issue 2626 | GWB-A, GWB-B and GWB-C are plain in the PDF (ArialNarrow regular); they are cells 1-3 of header row 3 because HWP, Storey and DWB span down from the rows above. */
+.table-block[id="nbc.divBV2.part9.sect23.subsect13.art7.table1"] thead > tr:nth-child(3) > .table-block__header-cell:nth-child(1),
+.table-block[id="nbc.divBV2.part9.sect23.subsect13.art7.table1"] thead > tr:nth-child(3) > .table-block__header-cell:nth-child(2),
+.table-block[id="nbc.divBV2.part9.sect23.subsect13.art7.table1"] thead > tr:nth-child(3) > .table-block__header-cell:nth-child(3),
 .table-block[id="nbc.divBV2.part9.sect23.subsect13.art7.table1"] thead > tr:nth-child(3) > .table-block__header-cell:nth-child(4),
 .table-block[id="nbc.divBV2.part9.sect23.subsect13.art7.table1"] thead > tr:nth-child(3) > .table-block__header-cell:nth-child(5),
 .table-block[id="nbc.divBV2.part9.sect23.subsect13.art7.table1"] thead > tr:nth-child(3) > .table-block__header-cell:nth-child(6),
```

## 14. CL-063 - Show step numbers 3 and 4 plain in the Table 9.36.6.3.-G header as in the PDF (CL-063 spanned-column cells).

- **Tag:** `webfix/CL-063-CF-06098`  **Commit:** `de3c2f36f6c03089f499553f943440f6c545bca8` (2026-11-12 13:02, branch `ai-fix/session_1`)
- **Lead issue:** CF-06098 - Formatting, B.9.36.6.3.Tbl7#Row2.Col3
- **Issues expected to clear:** **?** (to be confirmed by the next comparison)
- **Basis of the count:** -
- **New issues:** -
- **Issues that stay:** -
- **Ledger cluster:** CL-063, 561 issue(s) in the ledger
- **What was wrong:** PDF: Step 3, 4, 5 plain (ArialNarrow regular); whole header plain | before: 3 and 4 bold, 5 plain | after: 3, 4, 5 plain. Not changed (other issues/pre-existing): Total Volume, Step, Airtightness Levels and AL-* header cells still bold; 3 and 4 are left-aligned on the website, centred in the PDF.
- **Root cause:** CL-063 per-cell: the CF-00274 rule for tableG header row 2 covered cell 3 (5) only; Total Volume and Energy Performance Metrics span down from row 1, so Step 3 and 4 are cells 1-2 of row 2 and were missed.
- **Files:** `apps/web/components/reading/TableBlock.css`
- **Patch:** `web-fixes/CL-063-CF-06098.patch`

```
 apps/web/components/reading/TableBlock.css | 3 +++
 1 file changed, 3 insertions(+)
```

```diff
diff --git a/apps/web/components/reading/TableBlock.css b/apps/web/components/reading/TableBlock.css
index 4bd54f1..de2fc09 100644
--- a/apps/web/components/reading/TableBlock.css
+++ b/apps/web/components/reading/TableBlock.css
@@ -278,6 +278,9 @@
 .table-block[id="nbc.divBV2.part9.sect32.subsect3.art8.table1"] thead > tr:nth-child(3) > .table-block__header-cell:nth-child(5),
 .table-block[id="nbc.divBV2.part9.sect32.subsect3.art8.table1"] thead > tr:nth-child(3) > .table-block__header-cell:nth-child(6),
 .table-block[id="nbc.divBV2.part9.sect36.subsect6.art3.tableG"] thead > tr:nth-child(1) > .table-block__header-cell:nth-child(2),
+/* CLAUDE-AUTOFIX CL-063 CF-06098 | issue 3233 | Step numbers 3 and 4 are plain in the PDF (ArialNarrow regular); they are cells 1-2 of header row 2 because Total Volume and Energy Performance Metrics span down from row 1. */
+.table-block[id="nbc.divBV2.part9.sect36.subsect6.art3.tableG"] thead > tr:nth-child(2) > .table-block__header-cell:nth-child(1),
+.table-block[id="nbc.divBV2.part9.sect36.subsect6.art3.tableG"] thead > tr:nth-child(2) > .table-block__header-cell:nth-child(2),
 .table-block[id="nbc.divBV2.part9.sect36.subsect6.art3.tableG"] thead > tr:nth-child(2) > .table-block__header-cell:nth-child(3),
 .table-block[id="nbc.divBV2.part9.sect36.subsect6.art3.tableH"] thead > tr:nth-child(1) > .table-block__header-cell:nth-child(3) {
   font-weight: var(--typography-font-weights-regular, 400);
```

## 15. CL-036 - Label the inline header notes of Tables 9.36.2.7.-A/-B/-D as (1), (2), (3) as in the PDF instead of (fn1) (CL-036; also fixes CF-05802, CF-05803, CF-05812, CF-05825, CF-05826).

- **Tag:** `webfix/CL-036-CF-05801`  **Commit:** `bce14b39f0792d38f132467895f6efda54677759` (2026-11-12 14:32, branch `ai-fix/session_1`)
- **Lead issue:** CF-05801 - Punctuation, B.9.36.2.7.Tbl1#Row1.Col2
- **Issues expected to clear:** **?** (to be confirmed by the next comparison)
- **Basis of the count:** -
- **New issues:** -
- **Issues that stay:** -
- **Ledger cluster:** CL-036, 6 issue(s) in the ledger
- **What was wrong:** PDF: small (1)/(2)/(3) markers | before: (fn1)/(fn2)/(fn3) | after: (1)/(2)/(3) as in the PDF. Pre-existing, not touched: table titles 9.36.2.7.(1)/(2)/(11), Table -D notes listed twice, Table -B missing 'Maximum Overall Thermal Transmittance' row.
- **Root cause:** Website getNoteLabel (apps/web/lib/text-parsing.ts) only maps ids ending noteN to (N); the inline header notes of Tables 9.36.2.7.-A/-B/-D have ids ending fnN, so the label falls back to '(fnN)' instead of the PDF's '(N)'. JSON is correct (no space, right ids).
- **Files:** `apps/web/lib/text-parsing.ts`
- **Patch:** `web-fixes/CL-036-CF-05801.patch`

```
 apps/web/lib/text-parsing.ts | 3 ++-
 1 file changed, 2 insertions(+), 1 deletion(-)
```

```diff
diff --git a/apps/web/lib/text-parsing.ts b/apps/web/lib/text-parsing.ts
index aed72e4..cb92def 100644
--- a/apps/web/lib/text-parsing.ts
+++ b/apps/web/lib/text-parsing.ts
@@ -327,7 +327,8 @@ function toRenderableEquation(
 
 function getNoteLabel(noteId: string): string {
   const normalized = noteId.trim();
-  const match = normalized.match(/(?:title)?note(\d+)$/i);
+  // CLAUDE-AUTOFIX CF-05801 | issue 9972 | Inline header notes with ids ending fnN (Tables 9.36.2.7.-A/-B/-D) are labelled (N) as in the PDF, not (fnN).
+  const match = normalized.match(/(?:(?:title)?note|fn)(\d+)$/i);
   if (match) {
     return `(${match[1]})`;
   }
```

## 16. CL-063 - Table note marks in body cells print plain, as in the PDF (note-mark links take the weight of the surrounding text).

- **Tag:** `webfix/CL-063-CF-10334`  **Commit:** `9f0c237f2f4989095102bba29a70e5a5b0e04aae` (2026-11-13 22:36, branch `ai-fix/session_1`)
- **Lead issue:** CF-10334 - Formatting, B.A-9.36.2.4.(1).Tbl4#Row8.Col1
- **Issues expected to clear:** **65** (to be confirmed by the next comparison)
- **Basis of the count:** latest_31_new: 65 'n: plain in PDF, bold on website' issues on table-note marks in body cells (Part 3, 4 and 9 appendix tables), each checked in the live DOM (link weight 700 -> 400).
- **New issues:** None expected: only body-cell note links change (107 links); header-cell marks keep the bold of their cell.
- **Issues that stay:** Note marks in header cells where the PDF prints them plain are handled per cell (CL-063).
- **Ledger cluster:** CL-063, 561 issue(s) in the ledger
- **What was wrong:** PDF: Air Cavities bold, (2)(3) plain superscripts | before: (2)(3) bold links | after: (2)(3) plain, Air Cavities still bold
- **Root cause:** NoteReference.css gave every table-note link (.note-reference__link) font-weight bold, so note marks in plain body cells printed bold; the PDF prints them plain (bold only inside bold text).
- **Files:** `apps/web/components/reading/NoteReference.css`
- **Patch:** `web-fixes/CL-063-CF-10334.patch`

```
 apps/web/components/reading/NoteReference.css | 3 ++-
 1 file changed, 2 insertions(+), 1 deletion(-)
```

```diff
diff --git a/apps/web/components/reading/NoteReference.css b/apps/web/components/reading/NoteReference.css
index c9d3661..3c1fa62 100644
--- a/apps/web/components/reading/NoteReference.css
+++ b/apps/web/components/reading/NoteReference.css
@@ -15,7 +15,8 @@
   color: var(--typography-color-link, #1a5a96);
   text-decoration: none;
   cursor: pointer;
-  font-weight: var(--typography-font-weights-bold, 700);
+  /* CLAUDE-AUTOFIX CF-10334 | issue 1734 | Note marks take the weight of the text around them (plain in body cells, bold in bold header cells), as in the PDF. */
+  font-weight: inherit;
   transition: color 0.2s ease;
 }
```

## 17. CL-063 - Footnote marks, superscripts and subscripts in 74 header cells, and 33 whole header cells, print plain where the PDF does.

- **Tag:** `webfix/CL-063-CF-09424`  **Commit:** `34b00d70b3ff7a8ba2340f049775e8539f3ee2e5` (2026-11-13 22:44, branch `ai-fix/session_1`)
- **Lead issue:** CF-09424 - Formatting, AppD.Tbl2#Row2.Col3
- **Issues expected to clear:** **114** (to be confirmed by the next comparison)
- **Basis of the count:** latest_31_new: 114 'plain in PDF, bold on website' issues in 107 header cells (74 cells: only glyphs flagged, all of them; 33 cells: the whole cell text flagged), each matched by text in the live page.
- **New issues:** None expected: live weight snapshot of all 150 tables on the 21 pages shows only the 145 targeted elements changed.
- **Issues that stay:** Cells where the PDF mixes bold and plain words or only some marks are plain (spec tables 1, A-9.10.15.4 etc.) stay manual.
- **Ledger cluster:** CL-063, 561 issue(s) in the ledger
- **What was wrong:** PDF: header words bold, subscripts L1/L2 plain | before: subscripts bold | after: subscripts plain, words bold
- **Root cause:** The website renders every header cell bold including its glyphs; in these cells the PDF prints the footnote marks/superscripts/subscripts (or the whole cell) plain. Per-cell list, as in the earlier CL-063 fixes.
- **Files:** `apps/web/components/reading/TableBlock.css`
- **Patch:** `web-fixes/CL-063-CF-09424.patch`

```
 apps/web/components/reading/TableBlock.css | 111 +++++++++++++++++++++++++++++
 1 file changed, 111 insertions(+)
```

```diff
diff --git a/apps/web/components/reading/TableBlock.css b/apps/web/components/reading/TableBlock.css
index de2fc09..11c7a9b 100644
--- a/apps/web/components/reading/TableBlock.css
+++ b/apps/web/components/reading/TableBlock.css
@@ -286,6 +286,117 @@
   font-weight: var(--typography-font-weights-regular, 400);
 }
 
+/* CLAUDE-AUTOFIX CL-063 CF-09424 | issue 5565 | In these 74 header cells (46 tables) every footnote marker, superscript and subscript is plain in the PDF while the words stay bold; in these 33 header cells (10 tables) the whole cell is plain in the PDF. Each cell was matched by its text in the live page (latest_31 issues). */
+.table-block[id="nbc.divB.appendixC.table2"] thead > tr:nth-child(2) > :nth-child(3) :is(sup, sub, .cross-reference-link),
+.table-block[id="nbc.divB.appendixC.table2"] thead > tr:nth-child(2) > :nth-child(4) :is(sup, sub, .cross-reference-link),
+.table-block[id="nbc.divB.appendixD.appsect1.subsect7.article1.table1"] thead > tr:nth-child(2) > :nth-child(2) :is(sup, sub, .cross-reference-link),
+.table-block[id="nbc.divB.appendixD.appsect1.subsect7.article1.table1"] thead > tr:nth-child(2) > :nth-child(3) :is(sup, sub, .cross-reference-link),
+.table-block[id="nbc.divB.appendixD.appsect1.subsect7.article1.table1"] thead > tr:nth-child(2) > :nth-child(4) :is(sup, sub, .cross-reference-link),
+.table-block[id="nbc.divB.appendixD.appsect2.subsect3.article4.table4"] thead > tr:nth-child(2) > :nth-child(1) :is(sup, sub, .cross-reference-link),
+.table-block[id="nbc.divB.appendixD.appsect2.subsect3.article4.table4"] thead > tr:nth-child(3) > :nth-child(1) :is(sup, sub, .cross-reference-link),
+.table-block[id="nbc.divB.appendixD.appsect2.subsect8.article2.table1"] thead > tr:nth-child(1) > :nth-child(1) :is(sup, sub, .cross-reference-link),
+.table-block[id="nbc.divB.appendixD.appsect2.subsect8.article2.table1"] thead > tr:nth-child(3) > :nth-child(1) :is(sup, sub, .cross-reference-link),
+.table-block[id="nbc.divB.appendixD.appsect2.subsect8.article2.table1"] thead > tr:nth-child(3) > :nth-child(2) :is(sup, sub, .cross-reference-link),
+.table-block[id="nbc.divB.appendixD.appsect3.subsect1.article1.table1"] thead > tr:nth-child(2) > :nth-child(2) :is(sup, sub, .cross-reference-link),
+.table-block[id="nbc.divB.part3.appendix.appnote107.table1"] thead > tr:nth-child(1) > :nth-child(1) :is(sup, sub, .cross-reference-link),
+.table-block[id="nbc.divB.part3.appendix.appnote107.table1"] thead > tr:nth-child(1) > :nth-child(2) :is(sup, sub, .cross-reference-link),
+.table-block[id="nbc.divB.part3.appendix.appnote107.table3"] thead > tr:nth-child(1) > :nth-child(2) :is(sup, sub, .cross-reference-link),
+.table-block[id="nbc.divB.part3.appendix.appnote107.table4"] thead > tr:nth-child(1) > :nth-child(1) :is(sup, sub, .cross-reference-link),
+.table-block[id="nbc.divB.part4.sect1.subsect6.art10.table1"] thead > tr:nth-child(3) > :nth-child(1) :is(sup, sub, .cross-reference-link),
+.table-block[id="nbc.divB.part4.sect1.subsect6.art10.table1"] thead > tr:nth-child(3) > :nth-child(2) :is(sup, sub, .cross-reference-link),
+.table-block[id="nbc.divB.part4.sect1.subsect6.art10.table1"] thead > tr:nth-child(3) > :nth-child(3) :is(sup, sub, .cross-reference-link),
+.table-block[id="nbc.divB.part4.sect1.subsect6.art10.table1"] thead > tr:nth-child(3) > :nth-child(4) :is(sup, sub, .cross-reference-link),
+.table-block[id="nbc.divB.part4.sect1.subsect6.art2.table2"] thead > tr:nth-child(1) > :nth-child(2) :is(sup, sub, .cross-reference-link),
+.table-block[id="nbc.divB.part4.sect1.subsect6.art2.table2"] thead > tr:nth-child(3) > :nth-child(1) :is(sup, sub, .cross-reference-link),
+.table-block[id="nbc.divB.part4.sect1.subsect8.art4.table2"] thead > tr:nth-child(2) > :nth-child(1) :is(sup, sub, .cross-reference-link),
+.table-block[id="nbc.divB.part4.sect1.subsect8.art5.table1"] thead > tr:nth-child(1) > :nth-child(2) :is(sup, sub, .cross-reference-link),
+.table-block[id="nbc.divB.part4.sect1.subsect8.art5.table1"] thead > tr:nth-child(2) > :nth-child(2) :is(sup, sub, .cross-reference-link),
+.table-block[id="nbc.divBV2.part9.appendix.appnote118.table1"] thead > tr:nth-child(1) > :nth-child(2) :is(sup, sub, .cross-reference-link),
+.table-block[id="nbc.divBV2.part9.appendix.appnote120.table1"] thead > tr:nth-child(1) > :nth-child(2) :is(sup, sub, .cross-reference-link),
+.table-block[id="nbc.divBV2.part9.appendix.appnote120.table2"] thead > tr:nth-child(1) > :nth-child(2) :is(sup, sub, .cross-reference-link),
+.table-block[id="nbc.divBV2.part9.appendix.appnote120.table2"] thead > tr:nth-child(1) > :nth-child(3) :is(sup, sub, .cross-reference-link),
+.table-block[id="nbc.divBV2.part9.appendix.appnote170.div2.table1"] thead > tr:nth-child(1) > :nth-child(2) :is(sup, sub, .cross-reference-link),
+.table-block[id="nbc.divBV2.part9.appendix.appnote232.div2.table1"] thead > tr:nth-child(3) > :nth-child(4) :is(sup, sub, .cross-reference-link),
+.table-block[id="nbc.divBV2.part9.appendix.appnote232.div2.table2"] thead > tr:nth-child(4) > :nth-child(3) :is(sup, sub, .cross-reference-link),
+.table-block[id="nbc.divBV2.part9.appendix.appnote237.table1"] thead > tr:nth-child(4) > :nth-child(4) :is(sup, sub, .cross-reference-link),
+.table-block[id="nbc.divBV2.part9.appendix.appnote237.table2"] thead > tr:nth-child(4) > :nth-child(3) :is(sup, sub, .cross-reference-link),
+.table-block[id="nbc.divBV2.part9.appendix.appnote237.table3"] thead > tr:nth-child(4) > :nth-child(3) :is(sup, sub, .cross-reference-link),
+.table-block[id="nbc.divBV2.part9.appendix.appnote257.table1"] thead > tr:nth-child(1) > :nth-child(1) :is(sup, sub, .cross-reference-link),
+.table-block[id="nbc.divBV2.part9.appendix.appnote257.table1"] thead > tr:nth-child(1) > :nth-child(2) :is(sup, sub, .cross-reference-link),
+.table-block[id="nbc.divBV2.part9.appendix.appnote257.table1"] thead > tr:nth-child(3) > :nth-child(1) :is(sup, sub, .cross-reference-link),
+.table-block[id="nbc.divBV2.part9.appendix.appnote82.table1"] thead > tr:nth-child(1) > :nth-child(2) :is(sup, sub, .cross-reference-link),
+.table-block[id="nbc.divBV2.part9.appendix.appnote82.table3"] thead > tr:nth-child(1) > :nth-child(2) :is(sup, sub, .cross-reference-link),
+.table-block[id="nbc.divBV2.part9.sect15.subsect3.art4.table1"] thead > tr:nth-child(1) > :nth-child(3) :is(sup, sub, .cross-reference-link),
+.table-block[id="nbc.divBV2.part9.sect15.subsect3.art4.table1"] thead > tr:nth-child(2) > :nth-child(1) :is(sup, sub, .cross-reference-link),
+.table-block[id="nbc.divBV2.part9.sect15.subsect3.art4.table1"] thead > tr:nth-child(2) > :nth-child(2) :is(sup, sub, .cross-reference-link),
+.table-block[id="nbc.divBV2.part9.sect15.subsect4.art2.table1"] thead > tr:nth-child(2) > :nth-child(1) :is(sup, sub, .cross-reference-link),
+.table-block[id="nbc.divBV2.part9.sect29.subsect6.art1.table1"] thead > tr:nth-child(1) > :nth-child(2) :is(sup, sub, .cross-reference-link),
+.table-block[id="nbc.divBV2.part9.sect3.subsect1.art7.table1"] thead > tr:nth-child(3) > :nth-child(1) :is(sup, sub, .cross-reference-link),
+.table-block[id="nbc.divBV2.part9.sect36.subsect2.art7.table1"] thead > tr:nth-child(1) > :nth-child(2) :is(sup, sub, .cross-reference-link),
+.table-block[id="nbc.divBV2.part9.sect36.subsect2.art7.table1"] thead > tr:nth-child(1) > :nth-child(3) :is(sup, sub, .cross-reference-link),
+.table-block[id="nbc.divBV2.part9.sect36.subsect2.art7.table2"] thead > tr:nth-child(1) > :nth-child(2) :is(sup, sub, .cross-reference-link),
+.table-block[id="nbc.divBV2.part9.sect36.subsect2.art7.table2"] thead > tr:nth-child(3) > :nth-child(1) :is(sup, sub, .cross-reference-link),
+.table-block[id="nbc.divBV2.part9.sect36.subsect2.art7.table4"] thead > tr:nth-child(1) > :nth-child(3) :is(sup, sub, .cross-reference-link),
+.table-block[id="nbc.divBV2.part9.sect36.subsect2.art8.table3"] thead > tr:nth-child(1) > :nth-child(1) :is(sup, sub, .cross-reference-link),
+.table-block[id="nbc.divBV2.part9.sect36.subsect2.art8.table3"] thead > tr:nth-child(1) > :nth-child(2) :is(sup, sub, .cross-reference-link),
+.table-block[id="nbc.divBV2.part9.spectables1.table2"] thead > tr:nth-child(1) > :nth-child(3) :is(sup, sub, .cross-reference-link),
+.table-block[id="nbc.divBV2.part9.spectables1.table2"] thead > tr:nth-child(1) > :nth-child(4) :is(sup, sub, .cross-reference-link),
+.table-block[id="nbc.divBV2.part9.spectables2.table1"] thead > tr:nth-child(3) > :nth-child(1) :is(sup, sub, .cross-reference-link),
+.table-block[id="nbc.divBV2.part9.spectables2.table11"] thead > tr:nth-child(1) > :nth-child(3) :is(sup, sub, .cross-reference-link),
+.table-block[id="nbc.divBV2.part9.spectables2.table11"] thead > tr:nth-child(1) > :nth-child(4) :is(sup, sub, .cross-reference-link),
+.table-block[id="nbc.divBV2.part9.spectables2.table12"] thead > tr:nth-child(1) > :nth-child(3) :is(sup, sub, .cross-reference-link),
+.table-block[id="nbc.divBV2.part9.spectables2.table12"] thead > tr:nth-child(1) > :nth-child(4) :is(sup, sub, .cross-reference-link),
+.table-block[id="nbc.divBV2.part9.spectables2.table13"] thead > tr:nth-child(1) > :nth-child(3) :is(sup, sub, .cross-reference-link),
+.table-block[id="nbc.divBV2.part9.spectables2.table13"] thead > tr:nth-child(1) > :nth-child(4) :is(sup, sub, .cross-reference-link),
+.table-block[id="nbc.divBV2.part9.spectables2.table14"] thead > tr:nth-child(1) > :nth-child(3) :is(sup, sub, .cross-reference-link),
+.table-block[id="nbc.divBV2.part9.spectables2.table14"] thead > tr:nth-child(1) > :nth-child(4) :is(sup, sub, .cross-reference-link),
+.table-block[id="nbc.divBV2.part9.spectables2.table15"] thead > tr:nth-child(1) > :nth-child(3) :is(sup, sub, .cross-reference-link),
+.table-block[id="nbc.divBV2.part9.spectables2.table16"] thead > tr:nth-child(1) > :nth-child(2) :is(sup, sub, .cross-reference-link),
+.table-block[id="nbc.divBV2.part9.spectables2.table16"] thead > tr:nth-child(1) > :nth-child(3) :is(sup, sub, .cross-reference-link),
+.table-block[id="nbc.divBV2.part9.spectables2.table17"] thead > tr:nth-child(1) > :nth-child(2) :is(sup, sub, .cross-reference-link),
+.table-block[id="nbc.divBV2.part9.spectables2.table17"] thead > tr:nth-child(1) > :nth-child(3) :is(sup, sub, .cross-reference-link),
+.table-block[id="nbc.divBV2.part9.spectables2.table18"] thead > tr:nth-child(1) > :nth-child(2) :is(sup, sub, .cross-reference-link),
+.table-block[id="nbc.divBV2.part9.spectables2.table18"] thead > tr:nth-child(1) > :nth-child(3) :is(sup, sub, .cross-reference-link),
+.table-block[id="nbc.divBV2.part9.spectables2.table19"] thead > tr:nth-child(1) > :nth-child(2) :is(sup, sub, .cross-reference-link),
+.table-block[id="nbc.divBV2.part9.spectables2.table2"] thead > tr:nth-child(3) > :nth-child(1) :is(sup, sub, .cross-reference-link),
+.table-block[id="nbc.divBV2.part9.spectables2.table3"] thead > tr:nth-child(3) > :nth-child(1) :is(sup, sub, .cross-reference-link),
+.table-block[id="nbc.divBV2.part9.spectables2.table4"] thead > tr:nth-child(2) > :nth-child(1) :is(sup, sub, .cross-reference-link),
+.table-block[id="nbc.divB.appendixC.table3"] thead > tr:nth-child(2) > :nth-child(1),
+.table-block[id="nbc.divB.appendixC.table3"] thead > tr:nth-child(2) > :nth-child(2),
+.table-block[id="nbc.divB.appendixC.table3"] thead > tr:nth-child(2) > :nth-child(3),
+.table-block[id="nbc.divB.appendixC.table3"] thead > tr:nth-child(2) > :nth-child(4),
+.table-block[id="nbc.divB.appendixC.table3"] thead > tr:nth-child(2) > :nth-child(5),
+.table-block[id="nbc.divBV2.part9.appendix.appnote118a.table1"] thead > tr:nth-child(2) > :nth-child(1),
+.table-block[id="nbc.divBV2.part9.appendix.appnote118a.table1"] thead > tr:nth-child(2) > :nth-child(2),
+.table-block[id="nbc.divBV2.part9.appendix.appnote199a.tableA"] thead > tr:nth-child(2) > :nth-child(4),
+.table-block[id="nbc.divBV2.part9.sect23.subsect13.art11.table1"] thead > tr:nth-child(3) > :nth-child(1),
+.table-block[id="nbc.divBV2.part9.sect23.subsect13.art11.table1"] thead > tr:nth-child(3) > :nth-child(2),
+.table-block[id="nbc.divBV2.part9.sect23.subsect13.art11.table1"] thead > tr:nth-child(3) > :nth-child(3),
+.table-block[id="nbc.divBV2.part9.sect23.subsect13.art11.table1"] thead > tr:nth-child(3) > :nth-child(4),
+.table-block[id="nbc.divBV2.part9.sect23.subsect13.art11.table1"] thead > tr:nth-child(3) > :nth-child(5),
+.table-block[id="nbc.divBV2.part9.sect23.subsect13.art11.table1"] thead > tr:nth-child(3) > :nth-child(6),
+.table-block[id="nbc.divBV2.part9.sect23.subsect13.art11.table1"] thead > tr:nth-child(3) > :nth-child(7),
+.table-block[id="nbc.divBV2.part9.sect23.subsect13.art11.table1"] thead > tr:nth-child(3) > :nth-child(8),
+.table-block[id="nbc.divBV2.part9.sect23.subsect13.art11.table1"] thead > tr:nth-child(3) > :nth-child(9),
+.table-block[id="nbc.divBV2.part9.sect23.subsect13.art11.table1"] thead > tr:nth-child(3) > :nth-child(10),
+.table-block[id="nbc.divBV2.part9.sect23.subsect13.art11.table2"] thead > tr:nth-child(3) > :nth-child(1),
+.table-block[id="nbc.divBV2.part9.sect23.subsect13.art11.table2"] thead > tr:nth-child(3) > :nth-child(2),
+.table-block[id="nbc.divBV2.part9.sect23.subsect13.art11.table2"] thead > tr:nth-child(3) > :nth-child(3),
+.table-block[id="nbc.divBV2.part9.sect23.subsect13.art11.table2"] thead > tr:nth-child(3) > :nth-child(4),
+.table-block[id="nbc.divBV2.part9.sect23.subsect13.art11.table2"] thead > tr:nth-child(3) > :nth-child(5),
+.table-block[id="nbc.divBV2.part9.sect23.subsect13.art11.table2"] thead > tr:nth-child(3) > :nth-child(6),
+.table-block[id="nbc.divBV2.part9.sect23.subsect13.art11.table2"] thead > tr:nth-child(3) > :nth-child(7),
+.table-block[id="nbc.divBV2.part9.sect23.subsect13.art11.table2"] thead > tr:nth-child(3) > :nth-child(8),
+.table-block[id="nbc.divBV2.part9.sect23.subsect13.art11.table2"] thead > tr:nth-child(3) > :nth-child(9),
+.table-block[id="nbc.divBV2.part9.sect23.subsect13.art11.table2"] thead > tr:nth-child(3) > :nth-child(10),
+.table-block[id="nbc.divBV2.part9.sect23.subsect13.art7.table1"] thead > tr:nth-child(3) > :nth-child(10),
+.table-block[id="nbc.divBV2.part9.sect23.subsect6.art1.table1"] thead > tr:nth-child(1) > :nth-child(1),
+.table-block[id="nbc.divBV2.part9.sect36.subsect6.art3.tableA"] thead > tr:nth-child(1) > :nth-child(1),
+.table-block[id="nbc.divBV2.part9.sect36.subsect6.art3.tableB"] thead > tr:nth-child(1) > :nth-child(1),
+.table-block[id="nbc.divBV2.part9.sect37.subsect1.art3.table1"] thead > tr:nth-child(1) > :nth-child(1) {
+  font-weight: var(--typography-font-weights-regular, 400);
+}
+
 .table-block__wrapper {
   display: block;
   width: 100%;
```

## 18. CL-064 - The table number and title print plain in the 13 tables where the PDF does (9.26.3.1., 9.36.6.3.-B, D-2.6.1.-B ...).

- **Tag:** `webfix/CL-064-CF-05368`  **Commit:** `9c4e9f7b9636de651fd1b323328ec70f0ca90490` (2026-11-13 22:50, branch `ai-fix/session_1`)
- **Lead issue:** CF-05368 - Formatting, B.9.26.3.1.Tbl1
- **Issues expected to clear:** **13** (to be confirmed by the next comparison)
- **Basis of the count:** latest_31_new: 13 'table caption plain in PDF, bold on website' issues; PDF fonts (ArialMT) confirmed for number and title of each table.
- **New issues:** None expected: the table number line, which the PDF also prints plain, changes too; nothing else changed in a 157-table weight snapshot.
- **Issues that stay:** Captions that are partly bold in the PDF (Tables 9.23.6.1., 9.23.11.4.-A/-B) stay manual.
- **Ledger cluster:** CL-064, 120 issue(s) in the ledger
- **What was wrong:** PDF: Table 9.26.3.1. / Roofing Types and Slope Limits plain, Forming Part bold | before: number and title bold | after: number and title plain, Forming Part bold
- **Root cause:** TableBlock.css prints every table number and title bold; in these 13 BC-amended tables the PDF prints both in ArialMT regular (the Forming Part line stays bold except 9.36.6.3.-C..-G).
- **Files:** `apps/web/components/reading/TableBlock.css`
- **Patch:** `web-fixes/CL-064-CF-05368.patch`

```
 apps/web/components/reading/TableBlock.css | 16 ++++++++++++++++
 1 file changed, 16 insertions(+)
```

```diff
diff --git a/apps/web/components/reading/TableBlock.css b/apps/web/components/reading/TableBlock.css
index 11c7a9b..7e7dd0a 100644
--- a/apps/web/components/reading/TableBlock.css
+++ b/apps/web/components/reading/TableBlock.css
@@ -397,6 +397,22 @@
   font-weight: var(--typography-font-weights-regular, 400);
 }
 
+/* CLAUDE-AUTOFIX CL-064 CF-05368 | issue 10433 | In these 13 tables the PDF prints the table number and title in plain type (ArialMT, checked with the PDF fonts): Tables 9.8.4.2., 9.10.13.1., 9.10.14.4.-B, 9.23.16.7.-B, 9.26.3.1., 9.29.6.1., 9.36.6.3.-B, -D to -G, A-9.11.1.4.-D and D-2.6.1.-B. */
+.table-block[id="nbc.divBV2.part9.sect8.subsect4.art2.table1"] :is(.table-block__number, .table-block__title),
+.table-block[id="nbc.divBV2.part9.sect10.subsect13.art1.table1"] :is(.table-block__number, .table-block__title),
+.table-block[id="nbc.divBV2.part9.sect10.subsect14.art4.table2"] :is(.table-block__number, .table-block__title),
+.table-block[id="nbc.divBV2.part9.sect23.subsect16.art7.table2"] :is(.table-block__number, .table-block__title),
+.table-block[id="nbc.divBV2.part9.sect26.subsect3.art1.table1"] :is(.table-block__number, .table-block__title),
+.table-block[id="nbc.divBV2.part9.sect29.subsect6.art1.table1"] :is(.table-block__number, .table-block__title),
+.table-block[id="nbc.divBV2.part9.sect36.subsect6.art3.tableB"] :is(.table-block__number, .table-block__title),
+.table-block[id="nbc.divBV2.part9.sect36.subsect6.art3.tableD"] :is(.table-block__number, .table-block__title),
+.table-block[id="nbc.divBV2.part9.sect36.subsect6.art3.tableE"] :is(.table-block__number, .table-block__title),
+.table-block[id="nbc.divBV2.part9.sect36.subsect6.art3.tableF"] :is(.table-block__number, .table-block__title),
+.table-block[id="nbc.divBV2.part9.sect36.subsect6.art3.tableG"] :is(.table-block__number, .table-block__title),
+.table-block[id="nbc.divBV2.part9.appendix.appnote82.table4"] :is(.table-block__number, .table-block__title),
+.table-block[id="nbc.divB.appendixD.appsect2.subsect6.article1.table2"] :is(.table-block__number, .table-block__title) {
+  font-weight: var(--typography-font-weights-regular, 400);
+}
 .table-block__wrapper {
   display: block;
   width: 100%;
```

## 19. CL-071 - List labels print as text the way the PDF shows them ((a), (1), 1., (i), A., a)) for 26 PDF-checked lists, instead of CSS markers a. / 1.

- **Tag:** `webfix/CL-071-CF-03869`  **Commit:** `1d8b17dd3c45cc6b3e157fb1671a2fa70c8de139` (2026-11-13 22:59, branch `ai-fix/session_1`)
- **Lead issue:** CF-03869 - Incorrect Content, B.A-6.3.1.5
- **Issues expected to clear:** **52** (to be confirmed by the next comparison)
- **Basis of the count:** latest_31_new: 52 'missing on website: (a) / (1) / 1.' list-label issues (Notes A-3.8.2.5, A-5.4.1.1.(3), A-6.3.1.5, A-9.4.4.4.(1) references, A-9.10.13.2.(1), A-9.10.19.3.(1), A-9.15.3.4.(2), A-9.23.4.2, Appendix D-1.7.4 sample calculations).
- **New issues:** None expected: only the 26 allow-listed lists (checked against the PDF text) get text labels; other lists keep their CSS markers.
- **Issues that stay:** Lists the website draws as bullets where the PDF prints (a) (Notes A-4.1.8.19/21, note (1) of Tables 9.8.4.1/2) are a data/XSL question (bulleted list type) and stay manual.
- **Ledger cluster:** CL-071, 53 issue(s) in the ledger
- **What was wrong:** PDF: (a) (b) (c) | before: a. b. c. (CSS markers) | after: (a) (b) (c) as text, hanging like before
- **Root cause:** StructuredListBlock drew numbered/alphabetic/roman/reference list labels as CSS markers (a. 1. i.), which are not text and differ from the PDF labels ((a), (1), (i), A., a)).
- **Files:** `apps/web/components/reading/StructuredListBlock.css`, `apps/web/components/reading/StructuredListBlock.tsx`
- **Patch:** `web-fixes/CL-071-CF-03869.patch`

```
 .../web/components/reading/StructuredListBlock.css | 17 ++++
 .../web/components/reading/StructuredListBlock.tsx | 97 ++++++++++++++++++++--
 2 files changed, 106 insertions(+), 8 deletions(-)
```

```diff
diff --git a/apps/web/components/reading/StructuredListBlock.css b/apps/web/components/reading/StructuredListBlock.css
index 4216c54..a3a7b02 100644
--- a/apps/web/components/reading/StructuredListBlock.css
+++ b/apps/web/components/reading/StructuredListBlock.css
@@ -14,6 +14,23 @@
   list-style-type: none;
 }
 
+/* CLAUDE-AUTOFIX CF-03869 | issue 2161 | List labels are text ("(a)", "(1)", "1.") as in the PDF, hung in the left margin like the CSS markers they replace. */
+.structuredList--labelled {
+  list-style-type: none;
+  padding-left: 2.25rem;
+}
+
+.structuredList--labelled > li {
+  position: relative;
+}
+
+.structuredList__label {
+  position: absolute;
+  right: 100%;
+  margin-right: 0.5rem;
+  white-space: nowrap;
+}
+
 .structuredList--bulleted li,
 .structuredList--numbered li,
 .structuredList--alphabetic li,
diff --git a/apps/web/components/reading/StructuredListBlock.tsx b/apps/web/components/reading/StructuredListBlock.tsx
index c1fcd75..bd9429d 100644
--- a/apps/web/components/reading/StructuredListBlock.tsx
+++ b/apps/web/components/reading/StructuredListBlock.tsx
@@ -2,6 +2,67 @@ import React from 'react';
 import type { StructuredList } from '@bc-building-code/bcbc-parser';
 import './StructuredListBlock.css';
 
+// CLAUDE-AUTOFIX CF-03869 | issue 2161 | The PDF prints the labels of these lists as text ("(a)", "(1)", "1.", "(i)", "A.", "a)"), so the website writes them as text instead of drawing CSS markers; each list was checked against the PDF and is found by the start of its first item. Lists not listed here (e.g. the Appendix D clause lists the PDF labels "a)", "i)") keep the CSS markers.
+const TEXT_LABELS: Array<[string, string]> = [
+  // "(1)", "(2)": Notes A-3.8.2.5., A-5.4.1.1.(3), A-9.10.13.2.(1) and the A-9.25.5.2. references.
+  ['be not less than 2 600 mm wide', '(n)'],
+  ['at ambient temperatures with no temperature', '(n)'],
+  ["the manufacturer's or vendor's name", '(n)'],
+  ['“Exposure Guidelines for Residential', '(n)'],
+  // "1.", "2.": Appendix C snow loads and seismic hazard steps, Notes A-9.10.15.4.(2), A-9.10.19.3.(1), A-9.23.10.2. and A-9.36.2.4.(1) example.
+  ['The depth of snow on the ground', 'n.'],
+  ['Go to the 2020 National Building Code', 'n.'],
+  ['Calculate the total area of the exposing', 'n.'],
+  ['establish grade, which is the lowest', 'n.'],
+  ['Determine the mid-point of the centre line', 'n.'],
+  ['Determine the thermal resistance of each continuous', 'n.'],
+  // "(a)", "(b)": Note A-6.3.1.5., the Appendix D-1.7.4. sample calculations, Notes A-9.15.3.4.(2) and A-9.23.4.2.
+  ['Air-handling equipment should be accessible', '(a)'],
+  ['The minimum equivalent thickness of Type S', '(a)'],
+  ['Since gypsum board is used', '(a)'],
+  ['According to [REF:internal:nbc.divB.appendixD.appsect2.subsect1.article1.table1', '(a)'],
+  ['Determine for each storey the span', '(a)'],
+  ['sum_{1} = 6 + 6 = 12 m', '(a)'],
+  ['For a 3.5 kPa specified snow load', '(a)'],
+  // "A.", "B.": Note A-9.36.2.4.(1); "a)", "b)": Article D-2.6.6.; "(i)", "(ii)": Note A-9.36.2.4.(1) example.
+  ['calculate the effective thermal resistance', 'A.'],
+  ['1.0 [EQ:inline:eg02535a]', 'a)'],
+  ['along a line that goes through the framing', '(i)'],
+];
+
+function listLabel(type: string, items: Array<{ content?: string }>, index: number): string | null {
+  const first = (items[0]?.content ?? '').trim();
+  const entry = TEXT_LABELS.find(([prefix]) => first.startsWith(prefix));
+  // Every reference list in the PDF is labelled (1), (2) ...
+  const format = entry ? entry[1] : type === 'bibliography' ? '(n)' : null;
+  const letter = String.fromCharCode(97 + index);
+  const roman = ['i', 'ii', 'iii', 'iv', 'v', 'vi', 'vii', 'viii', 'ix', 'x'][index] ?? String(index + 1);
+  switch (format) {
+    case '(a)':
+      return `(${letter})`;
+    case 'a)':
+      return `${letter})`;
+    case 'A.':
+      return `${letter.toUpperCase()}.`;
+    case '(i)':
+      return `(${roman})`;
+    case '(n)':
+      return `(${index + 1})`;
+    case 'n.':
+      return `${index + 1}.`;
+    default:
+      return null;
+  }
+}
+
+function ListItemLabel({ label }: { label: string | null }) {
+  return label ? (
+    <>
+      <span className="structuredList__label">{label}</span>{' '}
+    </>
+  ) : null;
+}
+
 export interface StructuredListBlockProps {
   list: StructuredList;
   interactive?: boolean;
@@ -23,25 +84,42 @@ export const StructuredListBlock: React.FC<StructuredListBlockProps> = ({
       );
     case 'numbered':
       return (
-        <ol className="structuredList structuredList--numbered">
+        <ol
+          className={`structuredList structuredList--numbered${listLabel(list.type, list.items, 0) ? ' structuredList--labelled' : ''}`}
+        >
           {list.items.map((item, index) => (
-            <li key={item.id || `${list.type}-${index}`}>{renderText(item.content, index)}</li>
+            <li key={item.id || `${list.type}-${index}`}>
+              <ListItemLabel label={listLabel(list.type, list.items, index)} />
+              {renderText(item.content, index)}
+            </li>
           ))}
         </ol>
       );
     case 'alphabetic':
       return (
-        <ol className="structuredList structuredList--alphabetic" type="a">
+        <ol
+          className={`structuredList structuredList--alphabetic${listLabel(list.type, list.items, 0) ? ' structuredList--labelled' : ''}`}
+          type="a"
+        >
           {list.items.map((item, index) => (
-            <li key={item.id || `${list.type}-${index}`}>{renderText(item.content, index)}</li>
+            <li key={item.id || `${list.type}-${index}`}>
+              <ListItemLabel label={listLabel(list.type, list.items, index)} />
+              {renderText(item.content, index)}
+            </li>
           ))}
         </ol>
       );
     case 'roman':
       return (
-        <ol className="structuredList structuredList--roman" type="i">
+        <ol
+          className={`structuredList structuredList--roman${listLabel(list.type, list.items, 0) ? ' structuredList--labelled' : ''}`}
+          type="i"
+        >
           {list.items.map((item, index) => (
-            <li key={item.id || `${list.type}-${index}`}>{renderText(item.content, index)}</li>
+            <li key={item.id || `${list.type}-${index}`}>
+              <ListItemLabel label={listLabel(list.type, list.items, index)} />
+              {renderText(item.content, index)}
+            </li>
           ))}
         </ol>
       );
@@ -98,9 +176,12 @@ export const StructuredListBlock: React.FC<StructuredListBlockProps> = ({
           {list.header ? (
             <p className="structuredList__bibliography-header"><strong>{list.header}</strong></p>
           ) : null}
-          <ol className="structuredList structuredList--numbered">
+          <ol className="structuredList structuredList--numbered structuredList--labelled">
             {list.items.map((item, index) => (
-              <li key={item.id || `bibliography-${index}`}>{renderText(item.content)}</li>
+              <li key={item.id || `bibliography-${index}`}>
+                <ListItemLabel label={listLabel('bibliography', list.items, index)} />
+                {renderText(item.content)}
+              </li>
             ))}
           </ol>
         </div>
```

## 20. CL-063 - 13 header cells of Tables 10.3.1.3., 9.32.3.5., 9.32.3.8. and 9.36.6.3.-A/-B/-G print in regular weight (defined terms italic only), as in the PDF.

- **Tag:** `webfix/CL-063-CF-10691`  **Commit:** `432c91c7d4926c106f7ee0fcd5356ccd448a7f07` (2026-11-13 23:05, branch `ai-fix/session_1`)
- **Lead issue:** CF-10691 - Formatting, B.9.36.6.3.Tbl1#Row1.Col3
- **Issues expected to clear:** **31** (to be confirmed by the next comparison)
- **Basis of the count:** latest_31_new: 31 issues ('plain in PDF, bold on website' words and 'italic in PDF, bold italic on website' terms) that together cover the whole text of 13 header cells.
- **New issues:** None expected: 24 elements changed in a live snapshot, all inside the 13 cells.
- **Issues that stay:** Header cells only partly flagged (Table 9.36.6.3.-H, 9.23.6.1., 10.3.1.3. row 1) stay manual.
- **Ledger cluster:** CL-063, 561 issue(s) in the ledger
- **What was wrong:** PDF: Performance Requirement of Building (italic) Envelope, all regular weight | before: bold, Building bold italic | after: regular, Building italic
- **Root cause:** The website renders every header cell bold; in these 13 header cells the PDF prints the words plain and the defined terms italic (not bold italic). Flagged plain words + flagged italic terms cover the whole cell text.
- **Files:** `apps/web/components/reading/TableBlock.css`
- **Patch:** `web-fixes/CL-063-CF-10691.patch`

```
 apps/web/components/reading/TableBlock.css | 17 +++++++++++++++++
 1 file changed, 17 insertions(+)
```

```diff
diff --git a/apps/web/components/reading/TableBlock.css b/apps/web/components/reading/TableBlock.css
index 7e7dd0a..4fc08aa 100644
--- a/apps/web/components/reading/TableBlock.css
+++ b/apps/web/components/reading/TableBlock.css
@@ -413,6 +413,23 @@
 .table-block[id="nbc.divB.appendixD.appsect2.subsect6.article1.table2"] :is(.table-block__number, .table-block__title) {
   font-weight: var(--typography-font-weights-regular, 400);
 }
+/* CLAUDE-AUTOFIX CL-063 CF-10691 | issue 2637 | These 13 header cells (Tables 10.3.1.3., 9.32.3.5., 9.32.3.8., 9.36.6.3.-A, -B and -G) are not bold in the PDF: their words are plain and the defined terms in them italic only; each cell was matched by its text in the live page. */
+.table-block[id="nbc.divB.part10.sect3.subsect1.art3.table1"] thead > tr:nth-child(2) > :nth-child(1),
+.table-block[id="nbc.divB.part10.sect3.subsect1.art3.table1"] thead > tr:nth-child(2) > :nth-child(2),
+.table-block[id="nbc.divB.part10.sect3.subsect1.art3.table1"] thead > tr:nth-child(3) > :nth-child(2),
+.table-block[id="nbc.divB.part10.sect3.subsect1.art3.table1"] thead > tr:nth-child(3) > :nth-child(4),
+.table-block[id="nbc.divBV2.part9.sect32.subsect3.art5.table1"] thead > tr:nth-child(1) > :nth-child(1),
+.table-block[id="nbc.divBV2.part9.sect32.subsect3.art8.table1"] thead > tr:nth-child(2) > :nth-child(1),
+.table-block[id="nbc.divBV2.part9.sect36.subsect6.art3.tableA"] thead > tr:nth-child(1) > :nth-child(2),
+.table-block[id="nbc.divBV2.part9.sect36.subsect6.art3.tableA"] thead > tr:nth-child(1) > :nth-child(3),
+.table-block[id="nbc.divBV2.part9.sect36.subsect6.art3.tableA"] thead > tr:nth-child(1) > :nth-child(4),
+.table-block[id="nbc.divBV2.part9.sect36.subsect6.art3.tableB"] thead > tr:nth-child(1) > :nth-child(2),
+.table-block[id="nbc.divBV2.part9.sect36.subsect6.art3.tableB"] thead > tr:nth-child(1) > :nth-child(3),
+.table-block[id="nbc.divBV2.part9.sect36.subsect6.art3.tableB"] thead > tr:nth-child(1) > :nth-child(4),
+.table-block[id="nbc.divBV2.part9.sect36.subsect6.art3.tableG"] thead > tr:nth-child(1) > :nth-child(1) {
+  font-weight: var(--typography-font-weights-regular, 400);
+}
+
 .table-block__wrapper {
   display: block;
   width: 100%;
```

## 21. CL-072 - The 6 figures of Note A-9.32.3.4. are numbered by Sentence as in the PDF (A-9.32.3.4.(2) ... (6)) instead of -A to -F.

- **Tag:** `webfix/CL-072-CF-08312`  **Commit:** `8cd8fb93d20df1038f721223def49203c250fe1b` (2026-11-13 23:12, branch `ai-fix/session_1`)
- **Lead issue:** CF-08312 - Incorrect Content, B.A-9.32.3.4
- **Issues expected to clear:** **6** (to be confirmed by the next comparison)
- **Basis of the count:** latest_31_new: CF-08312 to CF-08317 (figure numbers -A..-F vs PDF (2)..(6)).
- **New issues:** None expected: only the 6 figure labels of Note A-9.32.3.4. changed in a before/after label scan of the Part 9 appendix.
- **Issues that stay:** Figure D-2.11.4.(4) label (CF-09693) is a different case.
- **Ledger cluster:** CL-072, 63 issue(s) in the ledger
- **What was wrong:** PDF: Figure A-9.32.3.4.(2) ... (6) | before: Figure A-9.32.3.4.-A ... -F | after: Figure A-9.32.3.4.(2) ... (6)
- **Root cause:** ReadingView buildAppendixNoteItemNumberMap numbers unnumbered figures of an appendix Note as <note>-A, -B ...; the PDF numbers the 6 figures of Note A-9.32.3.4. by Sentence ((2), (3), (4), (5)(b)(i), (5)(b)(ii), (6)). The JSON has no figure number.
- **Files:** `apps/web/components/reading/ReadingView.tsx`
- **Patch:** `web-fixes/CL-072-CF-08312.patch`

```
 apps/web/components/reading/ReadingView.tsx | 21 +++++++++++++++++++++
 1 file changed, 21 insertions(+)
```

```diff
diff --git a/apps/web/components/reading/ReadingView.tsx b/apps/web/components/reading/ReadingView.tsx
index cfac496..4ae7890 100644
--- a/apps/web/components/reading/ReadingView.tsx
+++ b/apps/web/components/reading/ReadingView.tsx
@@ -1339,6 +1339,18 @@ export const ReadingView: React.FC<ReadingViewProps> = ({
     return 'Note';
   };
 
+  // CLAUDE-AUTOFIX CF-08312 | issue 5261 | Figure numbers the PDF prints for appendix Notes whose figures are numbered by Sentence (in figure order).
+  const APPENDIX_NOTE_FIGURE_NUMBERS: Record<string, string[]> = {
+    'A-9.32.3.4.': [
+      'A-9.32.3.4.(2)',
+      'A-9.32.3.4.(3)',
+      'A-9.32.3.4.(4)',
+      'A-9.32.3.4.(5)(b)(i)',
+      'A-9.32.3.4.(5)(b)(ii)',
+      'A-9.32.3.4.(6)',
+    ],
+  };
+
   const toAlphabetOrdinalUpper = (value: number): string => {
     if (value <= 0 || Number.isNaN(value)) return String(value);
 
@@ -1415,6 +1427,15 @@ export const ReadingView: React.FC<ReadingViewProps> = ({
 
     appendBlockNumbers(note);
 
+    // CLAUDE-AUTOFIX CF-08312 | issue 5261 | The PDF numbers the 6 figures of Note A-9.32.3.4. by the Sentence they illustrate, not -A to -F.
+    const pdfFigureNumbers = APPENDIX_NOTE_FIGURE_NUMBERS[noteNumber];
+    if (pdfFigureNumbers) {
+      Array.from(figureNumberById.keys()).forEach((id, index) => {
+        if (pdfFigureNumbers[index]) figureNumberById.set(id, pdfFigureNumbers[index]);
+      });
+      figureIndex = 0;
+    }
+
     // Single table/figure in a note uses the bare note number (no letter suffix)
     if (tableIndex === 1) {
       for (const id of tableNumberById.keys()) {
```

## 22. CL-073 - A table number that already ends with a period gets no second period (Table A-Table 9.11.1.4., A-9.23.13., A-4.1.6.9. ...), as in the PDF.

- **Tag:** `webfix/CL-073-CF-08042`  **Commit:** `000af8b47edecc122787a47d2f5ed088b7bdb5f5` (2026-11-13 23:16, branch `ai-fix/session_1`)
- **Lead issue:** CF-08042 - Punctuation, B.A-Table 9.11.1.4
- **Issues expected to clear:** **1** (to be confirmed by the next comparison)
- **Basis of the count:** latest_31_new: CF-08042 ('after 9.11.1.4: PDF none / website .'). The same fix removes the double period from 6 more appendix table labels that were not reported separately.
- **New issues:** None expected: label scan of 11 appendix pages shows only the 7 double-period labels changed.
- **Issues that stay:** CF-08176 / CF-08391: the PDF prints these appendix tables with no label at all (website single-table label rule; title from data) - stays manual.
- **Ledger cluster:** CL-073, 21 issue(s) in the ledger
- **What was wrong:** PDF: Table A-Table 9.11.1.4. | before: Table A-Table 9.11.1.4.. | after: Table A-Table 9.11.1.4.
- **Root cause:** TableBlock getTableNumberDisplay always appended a period to a table number unless it ended with ')' or a letter suffix; numbers built from appendix Note numbers already end with '.', giving 'Table A-Table 9.11.1.4..'.
- **Files:** `apps/web/components/reading/TableBlock.tsx`
- **Patch:** `web-fixes/CL-073-CF-08042.patch`

```
 apps/web/components/reading/TableBlock.tsx | 2 ++
 1 file changed, 2 insertions(+)
```

```diff
diff --git a/apps/web/components/reading/TableBlock.tsx b/apps/web/components/reading/TableBlock.tsx
index bcf97bb..716a478 100644
--- a/apps/web/components/reading/TableBlock.tsx
+++ b/apps/web/components/reading/TableBlock.tsx
@@ -821,7 +821,9 @@ const getTableNumberDisplay = (tableNumber: string): string => {
     return normalized.endsWith('.') || normalized.endsWith(')') ? normalized : `${normalized}.`;
   }
 
+  // CLAUDE-AUTOFIX CF-08042 | issue 5106 | A number that already ends with a period (e.g. from Note A-Table 9.11.1.4. or A-9.23.13.) gets no second period, as in the PDF.
   const omitTrailingDot =
+    normalized.endsWith('.') ||
     normalized.endsWith(')') ||
     /^[A-Za-z]-\d+$/i.test(normalized) ||
     /\.-[A-Z]$/i.test(normalized); // letter suffix e.g. 3.2.3.1.-A
```

## 23. CL-073 - A Note reference followed by the sentence period prints one period, as in the PDF (See Note A-Table 9.6.1.3., See Note A-9.4.1.1.).

- **Tag:** `webfix/CL-073-CF-04057`  **Commit:** `697905d0938cf429b9518ced099ce771e1b9ed45` (2026-11-13 23:23, branch `ai-fix/session_1`)
- **Lead issue:** CF-04057 - Punctuation, B.9.6.1.3.Tbl1
- **Issues expected to clear:** **1** (to be confirmed by the next comparison)
- **Basis of the count:** latest_31_new: CF-04057 ('after 9.6.1.3: PDF none / website .'); also removes the double period in the see-also of Article 9.4.1.1. (not reported separately).
- **New issues:** None expected: 1070 links on 10 pages compared, only the 2 double-period Note links changed.
- **Issues that stay:** -
- **Ledger cluster:** CL-073, 21 issue(s) in the ledger
- **What was wrong:** PDF: (1) See Note A-Table 9.6.1.3. | before: See Note A-Table 9.6.1.3.. | after: See Note A-Table 9.6.1.3.
- **Root cause:** For a part-appendix Note reference the CrossReferenceLink re-resolves the label from the appendix data ('Note A-Table 9.6.1.3.'), ignoring the parser's trimming of the label's period when the source text already has the sentence period, so the page showed 'A-Table 9.6.1.3..'.
- **Files:** `apps/web/components/reading/CrossReferenceLink.tsx`, `apps/web/lib/text-parsing.ts`
- **Patch:** `web-fixes/CL-073-CF-04057.patch`

```
 apps/web/components/reading/CrossReferenceLink.tsx | 6 +++++-
 apps/web/lib/text-parsing.ts                       | 2 ++
 2 files changed, 7 insertions(+), 1 deletion(-)
```

```diff
diff --git a/apps/web/components/reading/CrossReferenceLink.tsx b/apps/web/components/reading/CrossReferenceLink.tsx
index 582844d..7ddaa33 100644
--- a/apps/web/components/reading/CrossReferenceLink.tsx
+++ b/apps/web/components/reading/CrossReferenceLink.tsx
@@ -19,6 +19,8 @@ interface CrossReferenceLinkProps {
   interactive?: boolean;
   preserveDisplayText?: boolean;
   currentDivision?: string;
+  // CLAUDE-AUTOFIX CF-04057 | issue 10373 | True when the source text puts a period right after the reference ("(See Note A-9.4.1.1.)").
+  followedByPeriod?: boolean;
 }
 
 type ApplicationNoteMeta = {
@@ -46,6 +48,7 @@ export const CrossReferenceLink: React.FC<CrossReferenceLinkProps> = ({
   interactive = true,
   preserveDisplayText = false,
   currentDivision,
+  followedByPeriod = false,
 }) => {
   const { openReference, navigateReference } = useCrossReferenceContext();
   const searchParams = useSearchParams();
@@ -292,7 +295,8 @@ export const CrossReferenceLink: React.FC<CrossReferenceLinkProps> = ({
   const effectiveDisplayText = standardsDisplayText
     || spectableDisplayText
     || (appnoteDisplayText
-      ? `${appnoteDisplayText}${trailingClauseQualifier ? ` ${trailingClauseQualifier}` : ''}`
+      // CLAUDE-AUTOFIX CF-04057 | issue 10373 | A resolved Note label ending with a period drops it when the text supplies the period, so the page does not show "Note A-9.4.1.1..", as in the PDF.
+      ? `${followedByPeriod && !trailingClauseQualifier && appnoteDisplayText.endsWith('.') ? appnoteDisplayText.slice(0, -1) : appnoteDisplayText}${trailingClauseQualifier ? ` ${trailingClauseQualifier}` : ''}`
       : resolvedDisplayText);
 
   if (!interactive || isNonLinkExternalReference) {
diff --git a/apps/web/lib/text-parsing.ts b/apps/web/lib/text-parsing.ts
index aed72e4..c6dfff6 100644
--- a/apps/web/lib/text-parsing.ts
+++ b/apps/web/lib/text-parsing.ts
@@ -1472,6 +1472,8 @@ export function parseTextWithMarkers(
               format: marker.format as InternalRefFormat,
               interactive,
               preserveDisplayText: Boolean(marker.crossRefLabel || spectableTableNoteLabel),
+              // CLAUDE-AUTOFIX CF-04057 | issue 10373 | Tell the link when the text already supplies the closing period, so a resolved Note label does not add a second one.
+              followedByPeriod: /^\s*\./.test(sanitizedText.slice(marker.end + crossRefDisplay.consumed)),
               currentDivision:
                 renderContext?.kind !== 'table'
                   ? renderContext?.referenceId.match(/\.div([A-Za-z])/i)?.[1]?.toUpperCase()
```

## 24. CL-083 - No "Forming Part of ..." line under Appendix C and D tables (32 tables), as in the PDF.

- **Tag:** `webfix/CL-083-CF-08737`  **Commit:** `405477a48d411fb315fa2be2e15d7fed0a03f6ca` (2026-11-14 04:38, branch `ai-fix/session_1`)
- **Lead issue:** CF-08737 - Incorrect Content, AppC.Tbl1
- **Issues expected to clear:** **32** (to be confirmed by the next comparison)
- **Basis of the count:** base_32 fresh analysis (2026-11-14), issues of this root cause
- **New issues:** none (page text before/after compared)
- **Issues that stay:** -
- **Ledger cluster:** CL-083, 32 issue(s) in the ledger
- **What was wrong:** 
- **Root cause:** The Forming Part of caption is built by the website (TableBlock.tsx formatFormingPartText) from the forming_part target ids only: it writes Sentence before every item (no plural Sentences X and (2)), writes Article N. for tables in appendix Notes (PDF: Note A-...), and ignores display_type; the XSL cannot set this wording. Website change (parked with CL-004/CL-005, user rule: XML/XSL only).
- **Files:** `apps/web/components/reading/TableBlock.tsx`
- **Patch:** `web-fixes/CL-083-CF-08737.patch`

```
 apps/web/components/reading/TableBlock.tsx | 5 ++++-
 1 file changed, 4 insertions(+), 1 deletion(-)
```

```diff
diff --git a/apps/web/components/reading/TableBlock.tsx b/apps/web/components/reading/TableBlock.tsx
index 716a478..4e88dcf 100644
--- a/apps/web/components/reading/TableBlock.tsx
+++ b/apps/web/components/reading/TableBlock.tsx
@@ -1542,7 +1542,10 @@ export const TableBlock: React.FC<TableBlockProps> = ({
   const tableNumber = tableNumberOverride ?? getResolvedTableNumber(rawTable, appendixSiblingTableCount);
   const tableNumberDisplay = tableNumber ? getTableNumberDisplay(tableNumber) : null;
   const tableNotesHeading = tableNumberDisplay ? `Notes to ${tableNumberDisplay}:` : 'Table notes';
-  const formattedFormingPartText = formatFormingPartText(formingPartEntries);
+  // CLAUDE-AUTOFIX CL-083 CF-08737 | issue 1457 | The PDF prints no "Forming Part of ..." line under any Appendix C or D table (checked PDF pp. 1560-1640), so none is shown there.
+  const formattedFormingPartText = /^nbc\.divB\.appendix[CD]\./.test(rawTable.id ?? '')
+    ? null
+    : formatFormingPartText(formingPartEntries);
   const formingPartText = LOWERCASE_FORMING_PART_TABLE_IDS.has(rawTable.id)
     ? formattedFormingPartText?.replace(/^Forming Part/, 'Forming part') ?? null
     : formattedFormingPartText;
```

## 25. CL-084 - Table references separated only by a line break keep their "Table" word (Table 1.3.1.2 "Table 5.9.1.1. Table 9.26.2.1.-B", A-9.36.2.8.(1)), as in the PDF.

- **Tag:** `webfix/CL-084-CF-10036`  **Commit:** `4864f5233055ecdc89c7db2c448d650b0b328bad` (2026-11-14 04:49, branch `ai-fix/session_1`)
- **Lead issue:** CF-10036 - Reference, B.1.3.1.2.Tbl1#Row200.Col4
- **Issues expected to clear:** **16** (to be confirmed by the next comparison)
- **Basis of the count:** base_32 fresh analysis (2026-11-14), issues of this root cause
- **New issues:** none (page text before/after compared)
- **Issues that stay:** -
- **Ledger cluster:** CL-084, 16 issue(s) in the ledger
- **What was wrong:** 
- **Root cause:** 
- **Files:** `apps/web/lib/text-parsing.ts`
- **Patch:** `web-fixes/CL-084-CF-10036.patch`

```
 apps/web/lib/text-parsing.ts | 3 ++-
 1 file changed, 2 insertions(+), 1 deletion(-)
```

```diff
diff --git a/apps/web/lib/text-parsing.ts b/apps/web/lib/text-parsing.ts
index c6dfff6..a144074 100644
--- a/apps/web/lib/text-parsing.ts
+++ b/apps/web/lib/text-parsing.ts
@@ -253,7 +253,8 @@ function avoidDuplicateLeadingReferenceType(precedingText: string, displayText:
       if (sameType) {
         // Verify the prior ref is in a list context (comma/or/and separated)
         // Line breaks (from <lb/>) separate refs visually; they are not list separators.
-        const trailingAfterLastRef = /\[REF:[^\]]+\][^\S\n]*(?:,\s*)?(?:(?:and|or)\s*)?$/i;
+        // CLAUDE-AUTOFIX CL-084 CF-10036 | issue 79 | Only a real separator ("," / and / or) makes a list; refs separated by whitespace alone (table-cell line breaks) keep their "Table" word, as in the PDF.
+        const trailingAfterLastRef = /\[REF:[^\]]+\][^\S\n]*(?:,\s*(?:(?:and|or)\s*)?|(?:and|or)\s*)$/i;
         if (trailingAfterLastRef.test(precedingText)) {
           return displayText.slice(displayMatch[0].length);
         }
```

## 26. CL-085 - Sentences added by later Ministerial Orders (empty original revision) are not shown at an earlier date, as in the PDF (no bare "2)", "7)", "12)").

- **Tag:** `webfix/CL-085-CF-00039`  **Commit:** `d815c8502246a772df68a0be1153a2ce333835c4` (2026-11-14 04:58, branch `ai-fix/session_1`)
- **Lead issue:** CF-00039 - Extra / Injected Content, A.1.3.3.2.(2)
- **Issues expected to clear:** **7** (to be confirmed by the next comparison)
- **Basis of the count:** base_32 fresh analysis (2026-11-14), issues of this root cause
- **New issues:** none (page text before/after compared)
- **Issues that stay:** -
- **Ledger cluster:** CL-085, 7 issue(s) in the ledger
- **What was wrong:** PDF: Article 1.3.3.2. has only Sentence 1 | website: an extra empty Sentence 2) after it
- **Root cause:** Ministerial Order BA 2024 03 (bc-mo-2024-03-001, effective 2024-08-27) inserts Sentence 2 into Article 1.3.3.2.: 'Parts 3, 4, 5 and 6 of Division B apply to buildings designed and constructed in accordance with Subsection 3.2.10.' The PDF being compared does not contain it. The sentence text is only inside revision-history/revision/content, so the page shows an empty Sentence 2).
- **Files:** `apps/web/lib/revision-resolver.ts`
- **Patch:** `web-fixes/CL-085-CF-00039.patch`

```
 apps/web/lib/revision-resolver.ts | 14 ++++++++++++++
 1 file changed, 14 insertions(+)
```

```diff
diff --git a/apps/web/lib/revision-resolver.ts b/apps/web/lib/revision-resolver.ts
index 36b69ef..e09b223 100644
--- a/apps/web/lib/revision-resolver.ts
+++ b/apps/web/lib/revision-resolver.ts
@@ -55,6 +55,18 @@ function getApplicableRevision(
   return sorted.find((rev) => (rev.effective_date || '') <= effectiveDate) || sorted[sorted.length - 1];
 }
 
+// CLAUDE-AUTOFIX CL-085 CF-00039 | issue 1815 | A Sentence whose revision in force is an empty "original" (added by a later Ministerial Order) is not shown at that date, as in the PDF.
+function isAddedByLaterRevision(node: ContentNode, effectiveDate?: string): boolean {
+  if (!effectiveDate || !Array.isArray(node.revisions) || node.revisions.length < 2) return false;
+  const revision = getApplicableRevision(node.revisions, effectiveDate);
+  if (!revision || revision.type !== 'original' || revision.deleted) return false;
+  const metaKeys = new Set(['type', 'effective_date', 'revision_id', 'revision_type', 'sequence', 'status', 'change_summary', 'note']);
+  return Object.entries(revision).every(
+    ([key, value]) =>
+      metaKeys.has(key) || value === '' || value == null || (Array.isArray(value) && value.length === 0)
+  );
+}
+
 function hasEquationPlaceholder(text: unknown): boolean {
   return typeof text === 'string' && /\[EQ:(?:display|inline)(?::[^\]]*)?\]/i.test(text);
 }
@@ -231,6 +243,8 @@ function resolveClause(node: ContentNode, effectiveDate?: string): ContentNode |
 }
 
 function resolveSentence(node: ContentNode, effectiveDate?: string): ContentNode | null {
+  // CLAUDE-AUTOFIX CL-085 CF-00039 | issue 1815 | Not yet in force at this date (empty original revision).
+  if (isAddedByLaterRevision(node, effectiveDate)) return null;
   const resolved = applyRevision(node, effectiveDate);
   if (!resolved) return null;
   const includeEquationContent = !hasEquationPlaceholder(resolved.text);
```

## 27. CL-086 - Unlabelled references in table cells show the full Sentence number (9.32.3.9.(2), not "(2)") and the table letter (Table 9.32.3.10.-B), as in the PDF.

- **Tag:** `webfix/CL-086-CF-10034`  **Commit:** `da658ffbf2b25609bdf010b974f0e42cab1fdc04` (2026-11-14 05:04, branch `ai-fix/session_1`)
- **Lead issue:** CF-10034 - Reference, B.1.3.1.2.Tbl1#Row190.Col4
- **Issues expected to clear:** **9** (to be confirmed by the next comparison)
- **Basis of the count:** base_32 fresh analysis (2026-11-14), issues of this root cause
- **New issues:** none (page text before/after compared)
- **Issues that stay:** -
- **Ledger cluster:** CL-086, 9 issue(s) in the ledger
- **What was wrong:** 
- **Root cause:** 
- **Files:** `apps/web/lib/text-parsing.ts`
- **Patch:** `web-fixes/CL-086-CF-10034.patch`

```
 apps/web/lib/text-parsing.ts | 12 +++++++++++-
 1 file changed, 11 insertions(+), 1 deletion(-)
```

```diff
diff --git a/apps/web/lib/text-parsing.ts b/apps/web/lib/text-parsing.ts
index a144074..41eeaea 100644
--- a/apps/web/lib/text-parsing.ts
+++ b/apps/web/lib/text-parsing.ts
@@ -676,11 +676,21 @@ function getCrossReferenceDisplayText(
     renderContext?.kind !== 'table'
       ? renderContext?.referenceId.match(/\.div([A-Za-z])/i)?.[1]?.toUpperCase()
       : undefined;
-  const fallback = formatInternalReference(
+  let fallback = formatInternalReference(
     referenceId,
     shouldExpandShortArticleRef ? 'medium' : format,
     currentDivision
   );
+  // CLAUDE-AUTOFIX CL-086 CF-10034 | issue 77 | In a table cell an unlabelled Sentence "number" ref shows its full number (9.32.3.9.(2), not "(2)") and the 2nd+ table of an article keeps its letter (Table 9.32.3.10.-B), as in the PDF.
+  if (renderContext?.kind === 'table' && parsedReference?.kind === 'section') {
+    if (format === 'number' && parsedReference.sentence && !parsedReference.clause) {
+      fallback = formatInternalReference(referenceId, 'medium').replace(/^Sentence /, '');
+    }
+    const tableIndex = Number(referenceId.match(/\.table(\d+)$/i)?.[1] ?? 0);
+    if (tableIndex > 1 && /\.$/.test(fallback)) {
+      fallback = `${fallback}-${String.fromCharCode(64 + tableIndex)}`;
+    }
+  }
   const qualifierMatch = fallback.startsWith('Note ')
     ? remaining.match(/^(\s*\([^)]+\))/)
     : null;
```

## 28. CL-087 - Note references in "number" format, or after the word "Notes" in the text, show only the note number (A-3.1.11.5.(3) and (4); See Notes A-3.1.6.4.(4) and ...), as in the PDF.

- **Tag:** `webfix/CL-087-CF-10062`  **Commit:** `2e0993b30997278c8fbadd709647b69ec3deffe8` (2026-11-14 05:09, branch `ai-fix/session_1`)
- **Lead issue:** CF-10062 - Note Reference, B.1.3.1.2.Tbl1#Row360.Col4
- **Issues expected to clear:** **2** (to be confirmed by the next comparison)
- **Basis of the count:** base_32 fresh analysis (2026-11-14), issues of this root cause
- **New issues:** none (page text before/after compared)
- **Issues that stay:** -
- **Ledger cluster:** CL-087, 2 issue(s) in the ledger
- **What was wrong:** 
- **Root cause:** 
- **Files:** `apps/web/components/reading/CrossReferenceLink.tsx`
- **Patch:** `web-fixes/CL-087-CF-10062.patch`

```
 apps/web/components/reading/CrossReferenceLink.tsx | 6 ++++--
 1 file changed, 4 insertions(+), 2 deletions(-)
```

```diff
diff --git a/apps/web/components/reading/CrossReferenceLink.tsx b/apps/web/components/reading/CrossReferenceLink.tsx
index 7ddaa33..6b27e34 100644
--- a/apps/web/components/reading/CrossReferenceLink.tsx
+++ b/apps/web/components/reading/CrossReferenceLink.tsx
@@ -183,7 +183,9 @@ export const CrossReferenceLink: React.FC<CrossReferenceLinkProps> = ({
         : matchedNote.title && matchedNote.title.trim()
           ? `${noteLabel} ${matchedNote.title.trim()}`
           : noteLabel;
-      const nextText = format === 'long' ? longLabel : noteLabel;
+      // CLAUDE-AUTOFIX CL-087 CF-10062 | issue 116 | A "number" Note ref, or one whose "Note" word the text already gives ("See Notes ..."), shows only the number A-x.x.x.x., as in the PDF.
+      const omitNoteWord = format === 'number' || !/^Note\b/i.test(displayText.trim());
+      const nextText = omitNoteWord ? prefixedNumber : format === 'long' ? longLabel : noteLabel;
 
       if (active) {
         setAppnoteDisplayText(nextText);
@@ -194,7 +196,7 @@ export const CrossReferenceLink: React.FC<CrossReferenceLinkProps> = ({
     return () => {
       active = false;
     };
-  }, [currentDivision, effectiveDate, fetchAppendix, format, parsedReference, referenceId, shouldResolveAppnoteDisplayText, version]);
+  }, [currentDivision, displayText, effectiveDate, fetchAppendix, format, parsedReference, referenceId, shouldResolveAppnoteDisplayText, version]);
 
   useEffect(() => {
     let active = true;
```

## 29. CL-088 - An unlabelled reference to the 2nd+ figure of an appendix Article keeps its letter (Figures D-2.6.1.-A and D-2.6.1.-B), as in the PDF.

- **Tag:** `webfix/CL-088-CF-10660`  **Commit:** `f4abfbdb444f2f53d5d7c1fa24c0a928e179c9c9` (2026-11-14 05:12, branch `ai-fix/session_1`)
- **Lead issue:** CF-10660 - Incorrect Content, AppD.Tbl25
- **Issues expected to clear:** **1** (to be confirmed by the next comparison)
- **Basis of the count:** base_32 fresh analysis (2026-11-14), issues of this root cause
- **New issues:** none (page text before/after compared)
- **Issues that stay:** -
- **Ledger cluster:** CL-088, 1 issue(s) in the ledger
- **What was wrong:** PDF: Figures D-2.6.1.-A and D-2.6.1.-B | website: same (CL-088 fix live)
- **Root cause:** 
- **Files:** `apps/web/lib/text-parsing.ts`
- **Patch:** `web-fixes/CL-088-CF-10660.patch`

```
 apps/web/lib/text-parsing.ts | 6 ++++++
 1 file changed, 6 insertions(+)
```

```diff
diff --git a/apps/web/lib/text-parsing.ts b/apps/web/lib/text-parsing.ts
index 41eeaea..765acd6 100644
--- a/apps/web/lib/text-parsing.ts
+++ b/apps/web/lib/text-parsing.ts
@@ -776,6 +776,12 @@ function formatInternalReference(referenceId: string, format?: InternalRefFormat
 
     if (figure) {
       const figureNumber = baseNumber || appendixLetter || '';
+      // CLAUDE-AUTOFIX CL-088 CF-10660 | issue 1721 | The 2nd+ figure of an appendix Article keeps its letter (Figure D-2.6.1.-B), as in the PDF.
+      const figureIndex = Number(figure);
+      if (article && figureIndex > 1) {
+        const figureSuffix = `-${String.fromCharCode(64 + figureIndex)}`;
+        return isShortNumeric ? `${figureNumber}.${figureSuffix}` : `Figure ${figureNumber}.${figureSuffix}`;
+      }
       return isShortNumeric ? figureNumber : `Figure ${figureNumber}.`;
     }
```

## 30. CL-089 - Untitled worked-example tables in appendix Notes get no invented "Table A-..." caption (A-9.36.2.11.(2) to (4), A-9.36.2.4.(1), A-9.36.1.1.(1), A-9.23.4.4.), as in the PDF.

- **Tag:** `webfix/CL-089-CF-08525`  **Commit:** `78c965ff81185b03805d42f929cc67000bec46c2` (2026-11-14 05:16, branch `ai-fix/session_1`)
- **Lead issue:** CF-08525 - Incorrect Content, B.A-9.36.2.11.(2)
- **Issues expected to clear:** **12** (to be confirmed by the next comparison)
- **Basis of the count:** base_32 fresh analysis (2026-11-14), issues of this root cause
- **New issues:** none (page text before/after compared)
- **Issues that stay:** -
- **Ledger cluster:** CL-089, 12 issue(s) in the ledger
- **What was wrong:** PDF: calculation lines (e.g. 36.74 W/K - 35.32 W/K = 1.42 W/K) | website: same lines rendered as display equations (MathML) at the same place
- **Root cause:** NBC base Notes A-9.36.2.11.(2)-(4) (and A-9.36.2.4.(1) step 4) hold display equations as <equation type=display><text>..</text></equation> without xml:id; canonical-to-json.xsl wrote them with an empty id so the website could not show them
- **Files:** `apps/web/components/reading/TableBlock.tsx`
- **Patch:** `web-fixes/CL-089-CF-08525.patch`

```
 apps/web/components/reading/TableBlock.tsx | 7 ++++++-
 1 file changed, 6 insertions(+), 1 deletion(-)
```

```diff
diff --git a/apps/web/components/reading/TableBlock.tsx b/apps/web/components/reading/TableBlock.tsx
index 4e88dcf..1dbe454 100644
--- a/apps/web/components/reading/TableBlock.tsx
+++ b/apps/web/components/reading/TableBlock.tsx
@@ -1539,7 +1539,12 @@ export const TableBlock: React.FC<TableBlockProps> = ({
     return true;
   });
   const formingPartEntries = rawTable.formingPart ?? rawTable.forming_part;
-  const tableNumber = tableNumberOverride ?? getResolvedTableNumber(rawTable, appendixSiblingTableCount);
+  // CLAUDE-AUTOFIX CL-089 CF-08525 | issue 737 | Untitled worked-example tables in appendix Notes have no "Table A-..." caption in the PDF, so none is invented.
+  const isUntitledExampleTable =
+    /\.example\d+\.table\d+$/i.test(rawTable.id ?? '') && !(typeof resolvedTitle === 'string' && resolvedTitle.trim());
+  const tableNumber = isUntitledExampleTable
+    ? null
+    : tableNumberOverride ?? getResolvedTableNumber(rawTable, appendixSiblingTableCount);
   const tableNumberDisplay = tableNumber ? getTableNumberDisplay(tableNumber) : null;
   const tableNotesHeading = tableNumberDisplay ? `Notes to ${tableNumberDisplay}:` : 'Table notes';
   // CLAUDE-AUTOFIX CL-083 CF-08737 | issue 1457 | The PDF prints no "Forming Part of ..." line under any Appendix C or D table (checked PDF pp. 1560-1640), so none is shown there.
```

## 31. CL-090 - Tables of appendix Notes read "Forming Part of Note A-3.2.6.6.(1)" / "Note A-9.23.13.2.(3)" instead of "Article 3."/"Article 9.", and Tables A-9.23.13.7.(3)/(4) have no such line, as in the PDF.

- **Tag:** `webfix/CL-090-CF-01778`  **Commit:** `3e39c53ab5c7ec9009c41b14d3b7a212b6f58b15` (2026-11-14 05:21, branch `ai-fix/session_1`)
- **Lead issue:** CF-01778 - Incorrect Content, B.A-3.2.6.6.(1).Tbl1
- **Issues expected to clear:** **8** (to be confirmed by the next comparison)
- **Basis of the count:** base_32 fresh analysis (2026-11-14), issues of this root cause
- **New issues:** none (page text before/after compared)
- **Issues that stay:** -
- **Ledger cluster:** CL-090, 8 issue(s) in the ledger
- **What was wrong:** 
- **Root cause:** Triage: raw markup on the website side (capture or render problem)
- **Files:** `apps/web/components/reading/TableBlock.tsx`
- **Patch:** `web-fixes/CL-090-CF-01778.patch`

```
 apps/web/components/reading/TableBlock.tsx | 22 ++++++++++++++++++++--
 1 file changed, 20 insertions(+), 2 deletions(-)
```

```diff
diff --git a/apps/web/components/reading/TableBlock.tsx b/apps/web/components/reading/TableBlock.tsx
index 1dbe454..7eb5bef 100644
--- a/apps/web/components/reading/TableBlock.tsx
+++ b/apps/web/components/reading/TableBlock.tsx
@@ -771,6 +771,13 @@ const LOWERCASE_FORMING_PART_TABLE_IDS = new Set<string>([
   'nbc.divBV2.part9.sect32.subsect3.art8.table1',
 ]);
 
+// CLAUDE-AUTOFIX CL-090 CF-01778 | issue 1392 | Appendix Note tables that print no "Forming Part of ..." line in the PDF (pp. 733-734).
+const NO_FORMING_PART_TABLE_IDS = new Set<string>([
+  'nbc.divBV2.part9.appendix.appnote134b.table1',
+  'nbc.divBV2.part9.appendix.appnote134c.table1',
+  'nbc.divBV2.part9.appendix.appnote134c.table2',
+]);
+
 const formatFormingPartText = (formingPart: FormingPartReference[] | undefined): string | null => {
   if (!formingPart || formingPart.length === 0) {
     return null;
@@ -1548,9 +1555,20 @@ export const TableBlock: React.FC<TableBlockProps> = ({
   const tableNumberDisplay = tableNumber ? getTableNumberDisplay(tableNumber) : null;
   const tableNotesHeading = tableNumberDisplay ? `Notes to ${tableNumberDisplay}:` : 'Table notes';
   // CLAUDE-AUTOFIX CL-083 CF-08737 | issue 1457 | The PDF prints no "Forming Part of ..." line under any Appendix C or D table (checked PDF pp. 1560-1640), so none is shown there.
-  const formattedFormingPartText = /^nbc\.divB\.appendix[CD]\./.test(rawTable.id ?? '')
+  // CLAUDE-AUTOFIX CL-090 CF-01778 | issue 1392 | A table forming part of an appendix Note reads "Forming Part of Note A-3.2.6.6.(1)" (note number, not "Article 3."); Tables A-9.23.13.7.(3) and (4)-A/-B have no such line in the PDF.
+  const appnoteFormingPartNumber =
+    formingPartEntries?.length === 1 &&
+    /\.appendix\.appnote[A-Za-z0-9]+$/.test(formingPartEntries[0]?.target ?? '') &&
+    typeof rawTable.number === 'string' &&
+    /^A-/.test(rawTable.number)
+      ? rawTable.number.replace(/([.)])-[A-Z]\.?$/, '$1')
+      : null;
+  const formattedFormingPartText = /^nbc\.divB\.appendix[CD]\./.test(rawTable.id ?? '') ||
+    NO_FORMING_PART_TABLE_IDS.has(rawTable.id ?? '')
     ? null
-    : formatFormingPartText(formingPartEntries);
+    : appnoteFormingPartNumber
+      ? `Forming Part of Note ${appnoteFormingPartNumber}`
+      : formatFormingPartText(formingPartEntries);
   const formingPartText = LOWERCASE_FORMING_PART_TABLE_IDS.has(rawTable.id)
     ? formattedFormingPartText?.replace(/^Forming Part/, 'Forming part') ?? null
     : formattedFormingPartText;
```

## 32. CL-091 - Unlabelled Subclause references keep their Clause letter ("(b)(ii)" in attribution tables, "Subclause (1)(b)(ii)" in text), as in the PDF.

- **Tag:** `webfix/CL-091-CF-06891`  **Commit:** `b84d9a5b235dce2f8cdee4473f9f6c96c81ec45b` (2026-11-14 05:27, branch `ai-fix/session_1`)
- **Lead issue:** CF-06891 - Incorrect Content, B.9.38.1.1.Tbl1#Row4346.Col2
- **Issues expected to clear:** **8** (to be confirmed by the next comparison)
- **Basis of the count:** base_32 fresh analysis (2026-11-14), issues of this root cause
- **New issues:** none (page text before/after compared)
- **Issues that stay:** -
- **Ledger cluster:** CL-091, 8 issue(s) in the ledger
- **What was wrong:** 
- **Root cause:** 
- **Files:** `apps/web/lib/text-parsing.ts`
- **Patch:** `web-fixes/CL-091-CF-06891.patch`

```
 apps/web/lib/text-parsing.ts | 8 ++++++++
 1 file changed, 8 insertions(+)
```

```diff
diff --git a/apps/web/lib/text-parsing.ts b/apps/web/lib/text-parsing.ts
index 765acd6..8b9b266 100644
--- a/apps/web/lib/text-parsing.ts
+++ b/apps/web/lib/text-parsing.ts
@@ -840,6 +840,14 @@ function formatInternalReference(referenceId: string, format?: InternalRefFormat
 
   if (subclause) {
     const number = toRoman(asNumber(subclause) ?? Number.NaN);
+    // CLAUDE-AUTOFIX CL-091 CF-06891 | issue 561 | An unlabelled Subclause ref keeps its Clause (and, in "medium" format, its Sentence): "(b)(ii)", "Subclause (1)(b)(ii)", as in the PDF.
+    const clauseLetter = clause ? toAlphabetOrdinal(asNumber(clause) ?? Number.NaN) : '';
+    if (format === 'shortNum' && clauseLetter) {
+      return `(${clauseLetter})(${number})`;
+    }
+    if (format === 'medium' && sentence && clauseLetter) {
+      return `Subclause (${sentence})(${clauseLetter})(${number})`;
+    }
     return isShortNumeric ? `(${number})` : withDivisionSuffix(`Subclause (${number})`);
   }
```

## 33. CL-092 - "Forming Part of" captions with 3 or more references use commas and put "and" only before the last one (Sentences 9.3.2.8.(1), 9.23.4.5.(1) and 9.23.12.3.(1) and (3)), as in the PDF.

- **Tag:** `webfix/CL-092-CF-10562`  **Commit:** `ed85233e4a514e1b7b1eb79596e20b794daf65a2` (2026-11-14 05:31, branch `ai-fix/session_1`)
- **Lead issue:** CF-10562 - Incorrect Content, B.9.Spec2.Tbl19
- **Issues expected to clear:** **2** (to be confirmed by the next comparison)
- **Basis of the count:** base_32 fresh analysis (2026-11-14), issues of this root cause
- **New issues:** none (page text before/after compared)
- **Issues that stay:** -
- **Ledger cluster:** CL-092, 2 issue(s) in the ledger
- **What was wrong:** 
- **Root cause:** 
- **Files:** `apps/web/components/reading/TableBlock.tsx`
- **Patch:** `web-fixes/CL-092-CF-10562.patch`

```
 apps/web/components/reading/TableBlock.tsx | 14 ++++++++++----
 1 file changed, 10 insertions(+), 4 deletions(-)
```

```diff
diff --git a/apps/web/components/reading/TableBlock.tsx b/apps/web/components/reading/TableBlock.tsx
index 7eb5bef..e58f9f4 100644
--- a/apps/web/components/reading/TableBlock.tsx
+++ b/apps/web/components/reading/TableBlock.tsx
@@ -740,17 +740,23 @@ const formatFormingPartItems = (items: FormingPartItem[]): string => {
       joinWithAnd([`${group.article}.${group.tails[0]}`, ...group.tails.slice(1)])
     );
     const hasGroupWithSeveralItems = groups.some((group) => group.tails.length > 1);
+    // CLAUDE-AUTOFIX CL-092 CF-10562 | issue 1451 | With 3 or more numbers the PDF separates them with commas and puts "and" (", and" after a group that has its own "and") only before the last one.
     const body =
       groupTexts.length === 1
         ? groupTexts[0]
-        : hasGroupWithSeveralItems
-          ? groupTexts.join(' and ')
-          : joinWithAnd(groupTexts);
+        : groupTexts.length >= 3
+          ? `${groupTexts.slice(0, -1).join(', ')}${groupTexts[groupTexts.length - 2].includes(' and ') ? ', and ' : ' and '}${groupTexts[groupTexts.length - 1]}`
+          : hasGroupWithSeveralItems
+            ? groupTexts.join(' and ')
+            : joinWithAnd(groupTexts);
     return `${pretext} ${body}`;
   });
 
+  // CLAUDE-AUTOFIX CL-092 CF-10540 | issue 1398 | Runs (Sentences ..., Clause ..., Article ...) are separated by commas; "and" comes only before the last run, as in the PDF.
   return texts.reduce((text, next, index) =>
-    index === 0 ? next : `${text}${texts[index - 1].includes(' and ') ? ', and ' : ' and '}${next}`
+    index === 0
+      ? next
+      : `${text}${index < texts.length - 1 ? ', ' : texts[index - 1].includes(' and ') ? ', and ' : ' and '}${next}`
   );
 };
```

## 34. CL-093 - Word equations given only as plain text (Ss = smooth normalized SL + bZ; height of water, mm = DRWP/10, Pa) are shown as text, not typeset as maths, as in the PDF.

- **Tag:** `webfix/CL-093-CF-09340`  **Commit:** `b4f8f3b25a0a7d0f6902403051e5236ba9b5b487` (2026-11-14 05:35, branch `ai-fix/session_1`)
- **Lead issue:** CF-09340 - Skipped, AppC.Eq1
- **Issues expected to clear:** **2** (to be confirmed by the next comparison)
- **Basis of the count:** base_32 fresh analysis (2026-11-14), issues of this root cause
- **New issues:** none (page text before/after compared)
- **Issues that stay:** -
- **Ledger cluster:** CL-093, 2 issue(s) in the ledger
- **What was wrong:** 
- **Root cause:** 
- **Files:** `apps/web/components/reading/EquationBlock.tsx`
- **Patch:** `web-fixes/CL-093-CF-09340.patch`

```
 apps/web/components/reading/EquationBlock.tsx | 16 +++++++++++++++-
 1 file changed, 15 insertions(+), 1 deletion(-)
```

```diff
diff --git a/apps/web/components/reading/EquationBlock.tsx b/apps/web/components/reading/EquationBlock.tsx
index 1b9f633..18fe514 100644
--- a/apps/web/components/reading/EquationBlock.tsx
+++ b/apps/web/components/reading/EquationBlock.tsx
@@ -60,7 +60,19 @@ export const EquationBlock: React.FC<EquationBlockProps> = ({
     resolvedMathml.trim().length > 0 &&
     !isMalformedMathml(resolvedMathml);
 
-  const showLatex = !hasMathml && latexForRender.trim().length > 0;
+  // CLAUDE-AUTOFIX CL-093 CF-09340 | issue 1281 | A word equation given only as plain text ("Ss = smooth normalized SL + bZ") is printed as text, as in the PDF, not typeset as maths (which ran the words together in italic).
+  const plainWordEquation =
+    !hasMathml &&
+    !repairedLatex &&
+    Boolean(equation.plainText) &&
+    latexForRender === equation.plainText &&
+    !latexForRender.includes('\\') &&
+    /[a-z]{2,} [a-z]{2,}/.test(latexForRender)
+      ? latexForRender.split(/(_\{[^}]*\})/).map((part, index) =>
+        part.startsWith('_{') ? <sub key={index}>{part.slice(2, -1)}</sub> : part
+      )
+      : null;
+  const showLatex = !hasMathml && !plainWordEquation && latexForRender.trim().length > 0;
   const shouldShowDescription =
     variant === 'standalone' &&
     equation.description &&
@@ -104,6 +116,8 @@ export const EquationBlock: React.FC<EquationBlockProps> = ({
           aria-label={equation.plainText || equation.description || `Equation ${equation.id}`}
         >
         </MathJax>
+      ) : plainWordEquation ? (
+        <span className="equation-block__plain-text">{plainWordEquation}</span>
       ) : showLatex ? (
         <MathJax
           renderMode="pre"
```

## 35. CL-094 - Symbol lists given as "AFUE= annual fuel ..." text in the notes to Tables 9.36.3.10. and 9.36.4.2. now show each symbol and its meaning, as in the PDF.

- **Tag:** `webfix/CL-094-CF-06000`  **Commit:** `302d24ef30987a481fe733ea5547d7d500c6d866` (2026-11-14 05:38, branch `ai-fix/session_1`)
- **Lead issue:** CF-06000 - Incorrect Content, B.9.36.3.10.Tbl1
- **Issues expected to clear:** **2** (to be confirmed by the next comparison)
- **Basis of the count:** base_32 fresh analysis (2026-11-14), issues of this root cause
- **New issues:** none (page text before/after compared)
- **Issues that stay:** -
- **Ledger cluster:** CL-094, 2 issue(s) in the ledger
- **What was wrong:** 
- **Root cause:** 
- **Files:** `apps/web/components/reading/StructuredListBlock.tsx`
- **Patch:** `web-fixes/CL-094-CF-06000.patch`

```
 .../web/components/reading/StructuredListBlock.tsx | 25 ++++++++++++++--------
 1 file changed, 16 insertions(+), 9 deletions(-)
```

```diff
diff --git a/apps/web/components/reading/StructuredListBlock.tsx b/apps/web/components/reading/StructuredListBlock.tsx
index bd9429d..68ca405 100644
--- a/apps/web/components/reading/StructuredListBlock.tsx
+++ b/apps/web/components/reading/StructuredListBlock.tsx
@@ -127,15 +127,22 @@ export const StructuredListBlock: React.FC<StructuredListBlockProps> = ({
     case 'symbol':
       return (
         <dl className={`structuredList structuredList--${list.type}`}>
-          {list.items.map((item, index) => (
-            <div
-              key={item.id || `${list.type}-${index}`}
-              className="structuredList__row structuredList__row--variable"
-            >
-              <dt className="structuredList__term">{renderText(item.symbol ?? '')}</dt>
-              <dd className="structuredList__description">{renderText(item.description ?? '')}</dd>
-            </div>
-          ))}
+          {list.items.map((item, index) => {
+            // CLAUDE-AUTOFIX CL-094 CF-06000 | issue 1810 | Items given only as "AFUE= annual fuel ..." text (table notes to Tables 9.36.3.10. and 9.36.4.2.) are split at "=" so the symbol and its meaning show, as in the PDF.
+            const rawContent = (item as { content?: string }).content;
+            const splitAt = item.symbol === undefined && item.description === undefined && rawContent ? rawContent.indexOf('=') : -1;
+            const symbol = splitAt > 0 ? rawContent!.slice(0, splitAt).trim() : item.symbol ?? '';
+            const description = splitAt > 0 ? rawContent!.slice(splitAt) : item.description ?? '';
+            return (
+              <div
+                key={item.id || `${list.type}-${index}`}
+                className="structuredList__row structuredList__row--variable"
+              >
+                <dt className="structuredList__term">{renderText(symbol)}</dt>
+                <dd className="structuredList__description">{renderText(description)}</dd>
+              </div>
+            );
+          })}
         </dl>
       );
     case 'definition':
```

## 36. CL-095 - A functional-statement/objective pair with a stray comma before the closing bracket renders as "[ F80 - OP2.3 ]" instead of raw [REF:...] markers (Table 9.38.1.1.), as in the PDF.

- **Tag:** `webfix/CL-095-CF-10189`  **Commit:** `1fa1e308890a0266cd81e2fd04978113589c5f12` (2026-11-14 05:41, branch `ai-fix/session_1`)
- **Lead issue:** CF-10189 - Incorrect Content, B.9.38.1.1.Tbl1#Row5213.Col2
- **Issues expected to clear:** **1** (to be confirmed by the next comparison)
- **Basis of the count:** base_32 fresh analysis (2026-11-14), issues of this root cause
- **New issues:** none (page text before/after compared)
- **Issues that stay:** -
- **Ledger cluster:** CL-095, 1 issue(s) in the ledger
- **What was wrong:** 
- **Root cause:** 
- **Files:** `apps/web/lib/text-parsing.ts`
- **Patch:** `web-fixes/CL-095-CF-10189.patch`

```
 apps/web/lib/text-parsing.ts | 3 ++-
 1 file changed, 2 insertions(+), 1 deletion(-)
```

```diff
diff --git a/apps/web/lib/text-parsing.ts b/apps/web/lib/text-parsing.ts
index 8b9b266..3659e8d 100644
--- a/apps/web/lib/text-parsing.ts
+++ b/apps/web/lib/text-parsing.ts
@@ -1325,7 +1325,8 @@ export function parseTextWithMarkers(
   // Use non-greedy match to capture everything between [[ and ]],
   // while also supporting spaced forms like:
   // [ [REF:functional-statement:fs03] - [REF:sub-objective:nbc-obj-os1.2] ]
-  const doubleBracketRegex = /\[\s*\[([\s\S]*?)\]\s*\]/g;
+  // CLAUDE-AUTOFIX CL-095 CF-10189 | issue 571 | A stray comma before the closing bracket ("... nbc-obj-op2.3] ,]", Table 9.38.1.1.) no longer leaves the raw [REF:...] markers on the page.
+  const doubleBracketRegex = /\[\s*\[([\s\S]*?)\]\s*,?\s*\]/g;
 
   while ((match = doubleBracketRegex.exec(sanitizedText)) !== null) {
     const content = match[1];
```

## 37. CL-083 - Update the TableBlock test to the CL-083 rule - Appendix C/D tables have no "Forming Part of" line, as in the PDF.

- **Tag:** `webfix/CL-083-CF-08741`  **Commit:** `eb9b41c52decd3022577daf46089d7ef6fbf9b71` (2026-11-14 05:45, branch `ai-fix/session_1`)
- **Lead issue:** CF-08741 - Incorrect Content, AppC.Tbl2
- **Issues expected to clear:** **?** (to be confirmed by the next comparison)
- **Basis of the count:** -
- **New issues:** -
- **Issues that stay:** -
- **Ledger cluster:** CL-083, 32 issue(s) in the ledger
- **What was wrong:** 
- **Root cause:** The Forming Part of caption is built by the website (TableBlock.tsx formatFormingPartText) from the forming_part target ids only: it writes Sentence before every item (no plural Sentences X and (2)), writes Article N. for tables in appendix Notes (PDF: Note A-...), and ignores display_type; the XSL cannot set this wording. Website change (parked with CL-004/CL-005, user rule: XML/XSL only).
- **Files:** `apps/web/components/reading/TableBlock.test.tsx`
- **Patch:** `web-fixes/CL-083-CF-08741.patch`

```
 apps/web/components/reading/TableBlock.test.tsx | 3 ++-
 1 file changed, 2 insertions(+), 1 deletion(-)
```

```diff
diff --git a/apps/web/components/reading/TableBlock.test.tsx b/apps/web/components/reading/TableBlock.test.tsx
index 03cb1de..50ed507 100644
--- a/apps/web/components/reading/TableBlock.test.tsx
+++ b/apps/web/components/reading/TableBlock.test.tsx
@@ -753,7 +753,8 @@ describe('TableBlock', () => {
     render(<TableBlock table={table} />);
 
     expect(screen.getByText('Table C-1')).toBeInTheDocument();
-    expect(screen.getByText('Forming Part of Appendix C')).toBeInTheDocument();
+    // CLAUDE-AUTOFIX CL-083 CF-08737 | issue 1457 | The PDF prints no "Forming Part of ..." line under Appendix C/D tables.
+    expect(screen.queryByText('Forming Part of Appendix C')).not.toBeInTheDocument();
     expect(screen.getByText('Wind Speeds')).toBeInTheDocument();
   });
```

## 38. CL-096 - The bibliography lead-in "References:" in Note A-9.4.4.4.(1) is plain text, not bold, as in the PDF.

- **Tag:** `webfix/CL-096-CF-10780`  **Commit:** `bdaded1cb84ee70a87df3400f3f6743eabd2247f` (2026-11-14 14:04, branch `ai-fix/session_1`)
- **Lead issue:** CF-10780 - Formatting, B.A-9.4.4.4.(1)
- **Issues expected to clear:** **1** (to be confirmed by the next comparison)
- **Basis of the count:** base_32 fresh analysis (2026-11-14), issues of this root cause
- **New issues:** none (page text before/after compared)
- **Issues that stay:** -
- **Ledger cluster:** CL-096, 1 issue(s) in the ledger
- **What was wrong:** PDF: 'References:' plain (p.1380) | before: bold | after: plain, list unchanged
- **Root cause:** 
- **Files:** `apps/web/components/reading/StructuredListBlock.tsx`
- **Patch:** `web-fixes/CL-096-CF-10780.patch`

```
 apps/web/components/reading/StructuredListBlock.tsx | 3 ++-
 1 file changed, 2 insertions(+), 1 deletion(-)
```

```diff
diff --git a/apps/web/components/reading/StructuredListBlock.tsx b/apps/web/components/reading/StructuredListBlock.tsx
index 68ca405..8545606 100644
--- a/apps/web/components/reading/StructuredListBlock.tsx
+++ b/apps/web/components/reading/StructuredListBlock.tsx
@@ -180,8 +180,9 @@ export const StructuredListBlock: React.FC<StructuredListBlockProps> = ({
     case 'bibliography':
       return (
         <div className="structuredList structuredList--bibliography">
+          {/* CLAUDE-AUTOFIX CL-096 CF-10780 | issue 503 | The bibliography lead-in "References:" is plain text in the PDF (p. 1380), not bold. */}
           {list.header ? (
-            <p className="structuredList__bibliography-header"><strong>{list.header}</strong></p>
+            <p className="structuredList__bibliography-header">{list.header}</p>
           ) : null}
           <ol className="structuredList structuredList--numbered structuredList--labelled">
             {list.items.map((item, index) => (
```

## 39. CL-097 - The design-review list of Note A-4.1.8.19.(2) is labelled (a) to (e), as in the PDF.

- **Tag:** `webfix/CL-097-CF-02954`  **Commit:** `4604bb418ca34ab9dcc6809f91734335d8b93487` (2026-11-14 14:50, branch `ai-fix/session_1`)
- **Lead issue:** CF-02954 - Incorrect Content, B.A-4.1.8.19.(2)
- **Issues expected to clear:** **4** (to be confirmed by the next comparison)
- **Basis of the count:** base_32 fresh analysis (2026-11-14), issues of this root cause
- **New issues:** none (page text before/after compared)
- **Issues that stay:** -
- **Ledger cluster:** CL-097, 4 issue(s) in the ledger
- **What was wrong:** PDF: (a) site-specific spectra, (b) ... (e) | before: a. b. c. (ol lower-alpha) | after: (a)...(e) as PDF
- **Root cause:** 6a44a89 made the list lettered (XML list type=alphabetic), which is right. The website draws alphabetic lists with CSS markers 'a.'; the PDF prints '(a)'. Text labels '(a)' come only from the website list TEXT_LABELS in StructuredListBlock.tsx (1d8b17d), which does not include this list.
- **Files:** `apps/web/components/reading/StructuredListBlock.tsx`
- **Patch:** `web-fixes/CL-097-CF-02954.patch`

```
 apps/web/components/reading/StructuredListBlock.tsx | 2 ++
 1 file changed, 2 insertions(+)
```

```diff
diff --git a/apps/web/components/reading/StructuredListBlock.tsx b/apps/web/components/reading/StructuredListBlock.tsx
index 8545606..ec49cbc 100644
--- a/apps/web/components/reading/StructuredListBlock.tsx
+++ b/apps/web/components/reading/StructuredListBlock.tsx
@@ -24,6 +24,8 @@ const TEXT_LABELS: Array<[string, string]> = [
   ['Determine for each storey the span', '(a)'],
   ['sum_{1} = 6 + 6 = 12 m', '(a)'],
   ['For a 3.5 kPa specified snow load', '(a)'],
+  // CLAUDE-AUTOFIX CL-097 CF-02954 | issue 1551 | The design-review list of Note A-4.1.8.19.(2) is labelled (a) to (e), as in the PDF (p. 629).
+  ['site-specific spectra,', '(a)'],
   // "A.", "B.": Note A-9.36.2.4.(1); "a)", "b)": Article D-2.6.6.; "(i)", "(ii)": Note A-9.36.2.4.(1) example.
   ['calculate the effective thermal resistance', 'A.'],
   ['1.0 [EQ:inline:eg02535a]', 'a)'],
```

## 40. CL-098 - The untitled table in Note A-9.23.13. gets no invented "Table A-9.23.13." caption, as in the PDF.

- **Tag:** `webfix/CL-098-CF-10784`  **Commit:** `d73dfb67d595d2d3698357ebc51a1f295fbf12e6` (2026-11-14 14:52, branch `ai-fix/session_1`)
- **Lead issue:** CF-10784 - Incorrect Content, B.A-9.23.13
- **Issues expected to clear:** **2** (to be confirmed by the next comparison)
- **Basis of the count:** base_32 fresh analysis (2026-11-14), issues of this root cause
- **New issues:** none (page text before/after compared)
- **Issues that stay:** -
- **Ledger cluster:** CL-098, 2 issue(s) in the ledger
- **What was wrong:** PDF: table directly after 'in the following table:' with no caption (p.1445) | before: 'Table A-9.23.13.' caption | after: no caption, table unchanged
- **Root cause:** BC amendment bc-379 (Part 9.FIN_3) gives the Note's table a <title> 'Seismic Force Modification Factors' that the PDF does not print; the website then labels it 'Table A-9.23.13.'. Pre-existing (same as CF-08176).
- **Files:** `apps/web/components/reading/TableBlock.tsx`
- **Patch:** `web-fixes/CL-098-CF-10784.patch`

```
 apps/web/components/reading/TableBlock.tsx | 3 ++-
 1 file changed, 2 insertions(+), 1 deletion(-)
```

```diff
diff --git a/apps/web/components/reading/TableBlock.tsx b/apps/web/components/reading/TableBlock.tsx
index e58f9f4..1674601 100644
--- a/apps/web/components/reading/TableBlock.tsx
+++ b/apps/web/components/reading/TableBlock.tsx
@@ -1553,8 +1553,9 @@ export const TableBlock: React.FC<TableBlockProps> = ({
   });
   const formingPartEntries = rawTable.formingPart ?? rawTable.forming_part;
   // CLAUDE-AUTOFIX CL-089 CF-08525 | issue 737 | Untitled worked-example tables in appendix Notes have no "Table A-..." caption in the PDF, so none is invented.
+  // CLAUDE-AUTOFIX CL-098 CF-10784 | issue 551 | An untitled table placed directly in a Note (A-9.23.13.) has no "Table A-..." caption in the PDF either.
   const isUntitledExampleTable =
-    /\.example\d+\.table\d+$/i.test(rawTable.id ?? '') && !(typeof resolvedTitle === 'string' && resolvedTitle.trim());
+    /\.(?:example\d+|appnote\d+)\.table\d+$/i.test(rawTable.id ?? '') && !(typeof resolvedTitle === 'string' && resolvedTitle.trim());
   const tableNumber = isUntitledExampleTable
     ? null
     : tableNumberOverride ?? getResolvedTableNumber(rawTable, appendixSiblingTableCount);
```

## 41. CL-099 - Table cells keep the PDF's em and en dashes instead of turning them into hyphens.

- **Tag:** `webfix/CL-099-CF-04628`  **Commit:** `672cf25845c17b9b0852f258d0aeba582a8b9442` (2026-11-14 19:32, branch `ai-fix/session_1`)
- **Lead issue:** CF-04628 - Incorrect Content, B.9.20.13.1.Tbl1
- **Issues expected to clear:** **3** (to be confirmed by the next comparison)
- **Basis of the count:** base_32 fresh analysis (2026-11-14), issues of this root cause
- **New issues:** none (page text before/after compared)
- **Issues that stay:** -
- **Ledger cluster:** CL-099, 3 issue(s) in the ledger
- **What was wrong:** PDF: em dashes in empty cells | before: hyphens | after: em dashes as in PDF (shots/CF-04628-compare.png)
- **Root cause:** JSON has the PDF's en/em dash; the website table renderer replaces every em/en dash in table cells with a hyphen
- **Files:** `apps/web/components/reading/TableBlock.test.tsx`, `apps/web/components/reading/TableBlock.tsx`
- **Patch:** `web-fixes/CL-099-CF-04628.patch`

```
 apps/web/components/reading/TableBlock.test.tsx | 5 +++--
 apps/web/components/reading/TableBlock.tsx      | 8 +++-----
 2 files changed, 6 insertions(+), 7 deletions(-)
```

```diff
diff --git a/apps/web/components/reading/TableBlock.test.tsx b/apps/web/components/reading/TableBlock.test.tsx
index 50ed507..a20f0f2 100644
--- a/apps/web/components/reading/TableBlock.test.tsx
+++ b/apps/web/components/reading/TableBlock.test.tsx
@@ -777,7 +777,8 @@ describe('TableBlock', () => {
     expect(screen.getByText('Data')).toBeInTheDocument();
   });
 
-  it('normalizes em dash table values to hyphen', () => {
+  // CLAUDE-AUTOFIX CL-099 CF-04628 | issue 6746 | Table cells keep the PDF's em dash (PDF Table 3.1.3.1. prints '—', not '-').
+  it('keeps em dash table values as printed in the PDF', () => {
     const table: Table = {
       id: 'test-table-dash',
       type: 'table',
@@ -793,7 +794,7 @@ describe('TableBlock', () => {
 
     render(<TableBlock table={table} />);
 
-    expect(screen.getByText('-')).toBeInTheDocument();
+    expect(screen.getByText('—')).toBeInTheDocument();
   });
 
   it('applies explicit colspan in raw table structure', () => {
diff --git a/apps/web/components/reading/TableBlock.tsx b/apps/web/components/reading/TableBlock.tsx
index 1674601..fc61638 100644
--- a/apps/web/components/reading/TableBlock.tsx
+++ b/apps/web/components/reading/TableBlock.tsx
@@ -138,11 +138,9 @@ const renderFormattedText = (
     // Legacy placeholders used in some table content
     .replace(/<>/g, '<italic>')
     .replace(/<\/>/g, '</italic>')
-    // Normalize dash markers used in tables and common mojibake variants.
-    .replace(/â€”/g, '-')
-    .replace(/â€“/g, '-')
-    .replace(/—/g, '-')
-    .replace(/–/g, '-');
+    // CLAUDE-AUTOFIX CL-099 CF-04628 | issue 6746 | Keep the PDF's em/en dashes in table cells (only repair mojibake to the right dash).
+    .replace(/â€”/g, '—')
+    .replace(/â€“/g, '–');
 
   const tokenRegex = /(<italic>[\s\S]*?<\/italic>|<bold>[\s\S]*?<\/bold>|\^\{[\s\S]*?\}|_\{[\s\S]*?\})/gi;
   const nodes: React.ReactNode[] = [];
```

## 42. CL-100 - A wide table whose first header cell spans several columns no longer draws that cell twice (Table 3.2.3.1.-C "Exposing Building Face").

- **Tag:** `webfix/CL-100-CF-01199`  **Commit:** `b7e3f6c071881b1f314fedf16fdb6168431692c1` (2026-11-14 19:35, branch `ai-fix/session_1`)
- **Lead issue:** CF-01199 - Incorrect Content, B.3.2.3.1.Tbl3
- **Issues expected to clear:** **1** (to be confirmed by the next comparison)
- **Basis of the count:** base_32 fresh analysis (2026-11-14), issues of this root cause
- **New issues:** none (page text before/after compared)
- **Issues that stay:** -
- **Ledger cluster:** CL-100, 1 issue(s) in the ledger
- **What was wrong:** PDF: Exposing Building Face once over 2 columns | before: drawn twice (pinned overlay, clipped) and Max. Area cut | after: once, Max. Area, m2 complete (shots/CF-01199-compare.png); the colspan-30 headers 'Area of Unprotected Openings...' / 'Limiting Distance, m' are centred off-screen to the right (not changed)
- **Root cause:** The Forming Part of caption is built by the website (TableBlock.tsx formatFormingPartText) from the forming_part target ids only: it writes Sentence before every item (no plural Sentences X and (2)), writes Article N. for tables in appendix Notes (PDF: Note A-...), and ignores display_type; the XSL cannot set this wording. Website change (parked with CL-004/CL-005, user rule: XML/XSL only).
- **Files:** `apps/web/components/reading/TableBlock.tsx`
- **Patch:** `web-fixes/CL-100-CF-01199.patch`

```
 apps/web/components/reading/TableBlock.tsx | 8 ++++++++
 1 file changed, 8 insertions(+)
```

```diff
diff --git a/apps/web/components/reading/TableBlock.tsx b/apps/web/components/reading/TableBlock.tsx
index fc61638..342c80c 100644
--- a/apps/web/components/reading/TableBlock.tsx
+++ b/apps/web/components/reading/TableBlock.tsx
@@ -1693,6 +1693,14 @@ export const TableBlock: React.FC<TableBlockProps> = ({
   // for height matching.
   const pinnedHeaderFirstColRows = useMemo(() => {
     if (!usesSplitScrollLayout) return [];
+    // CLAUDE-AUTOFIX CL-100 CF-01199 | issue 6654 | A first header cell spanning several columns (Table 3.2.3.1.-C "Exposing Building Face") cannot be pinned into column 0 without being drawn twice, so no overlay then.
+    let col0Covered = 0;
+    for (const row of displayHeaderRows) {
+      if (col0Covered > 0) { col0Covered -= 1; continue; }
+      const first = row.cells[0];
+      if (first && typeof first.colspan === 'number' && first.colspan > 1) return [];
+      col0Covered = first && typeof first.rowspan === 'number' && first.rowspan > 1 ? first.rowspan - 1 : 0;
+    }
     let col0ActiveRowspan = 0;
     return displayHeaderRows.map((row) => {
       const isCol0Covered = col0ActiveRowspan > 0;
```

## 43. CL-101 - Appendix D figures and the Note A-9.36.2.4.(1) example figures show the figure numbers printed in the PDF.

- **Tag:** `webfix/CL-101-CF-09752`  **Commit:** `784fe49bf2a1c630c36e5a8492c993c0005130f7` (2026-11-14 19:39, branch `ai-fix/session_1`)
- **Lead issue:** CF-09752 - Skipped, AppD.Fig3
- **Issues expected to clear:** **5** (to be confirmed by the next comparison)
- **Basis of the count:** base_32 fresh analysis (2026-11-14), issues of this root cause
- **New issues:** none (page text before/after compared)
- **Issues that stay:** -
- **Ledger cluster:** CL-101, 5 issue(s) in the ledger
- **What was wrong:** PDF: Figure D-2.6.1.-B | before: Figure D-2 | after: Figure D-2.6.1.-B (page text)
- **Root cause:** 
- **Files:** `apps/web/components/reading/FigureBlock.tsx`
- **Patch:** `web-fixes/CL-101-CF-09752.patch`

```
 apps/web/components/reading/FigureBlock.tsx | 17 ++++++++++++++++-
 1 file changed, 16 insertions(+), 1 deletion(-)
```

```diff
diff --git a/apps/web/components/reading/FigureBlock.tsx b/apps/web/components/reading/FigureBlock.tsx
index 710d46f..d6baf6b 100644
--- a/apps/web/components/reading/FigureBlock.tsx
+++ b/apps/web/components/reading/FigureBlock.tsx
@@ -71,6 +71,20 @@ function extractFigureNumberFromId(id: string): string | undefined {
   return `${part}.${section}.${subsection}.${article}.-${toAlphabetOrdinalUpper(figureIndex)}`;
 }
 
+// CLAUDE-AUTOFIX CL-101 CF-09752 | issue 6265 | Figure numbers the PDF prints that cannot be derived from the id (Appendix D: D-2.6.1.-B, D-2.11.4.(4) ...; Note A-9.36.2.4.(1) examples: 1-1, 2-1); the JSON has no figure number.
+const PDF_FIGURE_NUMBERS: Record<string, string> = {
+  'nbc.divB.appendixD.appsect2.subsect3.article10.figure1': 'D-2.3.10.',
+  'nbc.divB.appendixD.appsect2.subsect6.article1.figure1': 'D-2.6.1.-A',
+  'nbc.divB.appendixD.appsect2.subsect6.article1.figure2': 'D-2.6.1.-B',
+  'nbc.divB.appendixD.appsect2.subsect6.article4.figure1': 'D-2.6.4.-A',
+  'nbc.divB.appendixD.appsect2.subsect6.article4.figure2': 'D-2.6.4.-B',
+  'nbc.divB.appendixD.appsect2.subsect11.article3.figure1': 'D-2.11.3.-A',
+  'nbc.divB.appendixD.appsect2.subsect11.article3.figure2': 'D-2.11.3.-B',
+  'nbc.divB.appendixD.appsect2.subsect11.article4.figure1': 'D-2.11.4.(4)',
+  'nbc.divBV2.part9.appendix.appnote223.div2.example1.figure1': '1-1',
+  'nbc.divBV2.part9.appendix.appnote223.div3.example1.figure1': '2-1',
+};
+
 function getFigureNoteNumber(noteId: string): string {
   const noteMatch = noteId.match(/\.note(\d+)$/i);
   return noteMatch?.[1] || noteId.split('.').pop() || noteId;
@@ -214,7 +228,8 @@ export const FigureBlock: React.FC<FigureBlockProps> = ({
   const rawImageSrc = figure.imageUrl || figure.graphic?.src;
   const imagePath = resolveImagePath(rawImageSrc);
   const altText = figure.altText || figure.graphic?.alt_text || figure.title || 'Figure';
-  const figureNumber = extractFigureNumberFromId(figure.id) || figure.number;
+  // CLAUDE-AUTOFIX CL-101 CF-09752 | issue 6265 | The PDF's figure number wins where it is known (see PDF_FIGURE_NUMBERS).
+  const figureNumber = PDF_FIGURE_NUMBERS[figure.id] || extractFigureNumberFromId(figure.id) || figure.number;
   const figureLabel = figureNumber ? `Figure ${figureNumber}` : 'Figure';
   const hideLabel = figure.hide_label === true;
   const formingPartEntries = figure.formingPart ?? figure.forming_part;
```

